import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/my_app.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/features/notifications/calendar_listener.dart';
import 'package:studyapp_2024/features/notifications/chat_listener.dart';
import 'package:studyapp_2024/firebase_options.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

bool show = true;

// Create a FlutterSecureStorage instance
const FlutterSecureStorage secureStorage = FlutterSecureStorage();

// Function to store the API key securely
Future<void> storeApiKey(String apiKey) async {
  await secureStorage.write(key: 'api_key', value: apiKey);
}

// Function to retrieve the API key
Future<String?> getApiKey() async {
  return await secureStorage.read(key: 'api_key');
}

void main() async {
  //----- INITIALIZE FIREBASE -----//
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  //----- CHECKING FOR ANY GROUP MESSAGES & CALENDAR REMINDERS -----//
  ChatListener().startListening();
  CalendarListener().startListening();

  //----- INITIALIZE NOTIFICATIONS -----//
  await AwesomeNotifications().initialize(
    null,
    [
      NotificationChannel(
        channelGroupKey: 'basic_channel_group',
        channelKey: 'basic_channel',
        channelName: 'Basic Notifications',
        channelDescription: 'Basic notifications channel',
        ledColor: Colors.blue,
      ),
      NotificationChannel(
        channelGroupKey: 'chat_messages_group',
        channelKey: 'chat_messages',
        channelName: 'Chat Messages',
        channelDescription: 'Notifications for new chat messages',
        importance: NotificationImportance.High,
        ledColor: Colors.green,
      ),
      NotificationChannel(
        channelGroupKey: 'calendar_reminders_group',
        channelKey: 'calendar_reminders',
        channelName: 'Calendar Reminders',
        channelDescription: 'Notifications for calendar events reminders',
        importance: NotificationImportance.High,
        ledColor: Colors.orange,
      ),
    ],
    channelGroups: [
      NotificationChannelGroup(
        channelGroupKey: 'basic_channel_group',
        channelGroupName: 'Basic Group',
      ),
      NotificationChannelGroup(
        channelGroupKey: 'chat_messages_group',
        channelGroupName: 'Chat Messages Group',
      ),
      NotificationChannelGroup(
        channelGroupKey: 'calendar_reminders_group',
        channelGroupName: 'Calendar Reminders Group',
      ),
    ],
  );

  //----- REQUEST NOTIFICATION PERMISSION -----//
  bool isAllowedToSendNotification =
      await AwesomeNotifications().isNotificationAllowed();
  if (!isAllowedToSendNotification) {
    AwesomeNotifications().requestPermissionToSendNotifications();
  }

  //----- LOCAL PHONE STORAGE -----//
  final prefs = await SharedPreferences.getInstance();
  show = prefs.getBool('onboarding') ?? true;

  // Store the API key securely
  await storeApiKey("AIzaSyAG-nwizSxbYdTASnHYWFXKZrS1DkDvWiI");

  // Retrieve and print the stored API key
  String? apiKey = await getApiKey();
  print("Stored API Key: $apiKey"); // Should print the API key

  final FirebaseAuth auth = FirebaseAuth.instance;
  User? user = auth.currentUser;

  //----- RUN APP WITH RIVERPOD -----//
  runApp(
    ProviderScope(
      child: MyApp(user: user),
    ),
  );
}
