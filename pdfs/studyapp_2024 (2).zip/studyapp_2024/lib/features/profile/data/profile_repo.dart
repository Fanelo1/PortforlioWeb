import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfileRepo {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<Map<String, dynamic>?> loadUserData() async {
    User? user = _auth.currentUser;
    if (user != null) {
      try {
        DocumentSnapshot userData =
            await _firestore.collection('users').doc(user.uid).get();
        return userData.exists ? userData.data() as Map<String, dynamic> : null;
      } catch (e) {
        throw Exception('Failed to load user data');
      }
    }
    return null;
  }

  Future<void> updateUserProfile(
      {required String firstname,
      required String surname,
      required String phone}) async {
    User? user = _auth.currentUser;
    if (user != null) {
      try {
        await _firestore.collection('users').doc(user.uid).update({
          'Firstname': firstname,
          'Surname': surname,
          'Contact Number': phone,
        });
      } catch (e) {
        throw Exception('Failed to update profile details');
      }
    }
  }

  Future<String?> validateCurrentPassword(String currentPassword) async {
    User? user = _auth.currentUser;
    if (user == null) return 'User is not authenticated';
    if (currentPassword.isEmpty) return 'Please enter your current password';

    try {
      AuthCredential credential = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );
      await user.reauthenticateWithCredential(credential);
      return null; // Password is correct
    } catch (e) {
      return 'Current password is incorrect';
    }
  }

  Future<void> updatePassword(
      String currentPassword, String newPassword) async {
    User? user = _auth.currentUser;
    if (user == null) return;

    try {
      AuthCredential credential = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );
      await user.reauthenticateWithCredential(credential);
      await user.updatePassword(newPassword);
      await _firestore.collection('users').doc(user.uid).update({
        'Password': newPassword,
      });
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        throw Exception('The password provided is too weak');
      } else if (e.code == 'requires-recent-login') {
        throw Exception('Please reauthenticate to update your password');
      } else {
        throw Exception('Failed to update account password');
      }
    }
  }
}
