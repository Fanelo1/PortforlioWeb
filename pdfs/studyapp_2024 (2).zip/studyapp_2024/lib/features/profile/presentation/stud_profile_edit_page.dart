// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: StudProfileEdit CLASS (220024654, LK MAASDORP)
// PURPOSE: The profile edit page for the current student user

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/components/my_snackbar.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';
import 'package:studyapp_2024/components/phone_formatter.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/components/form_validations.dart';

class StudProfileEdit extends StatefulWidget {
  const StudProfileEdit({super.key});

  @override
  State<StudProfileEdit> createState() => _StudProfileEditState();
}

class _StudProfileEditState extends State<StudProfileEdit> {
  bool _togglePassword = false;
  bool _toggleCurrentPassword = false;

  //----- GLOBAL KEY FOR THE EDIT PROFILE FORM -----//
  final _formKey = GlobalKey<FormState>();

  //----- TEXTEDITINGCONTROLLERS -----//
  final _firstnameController = TextEditingController();
  final _surnameController = TextEditingController();
  final _phoneNumController = TextEditingController();
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmedPasswordController = TextEditingController();

  bool _isGoogleSignIn = false;

  @override
  void dispose() {
    _firstnameController.dispose();
    _surnameController.dispose();
    _phoneNumController.dispose();
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmedPasswordController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  //----- METHOD FOR RETRIEVING AND DISPLAYING THE CURRENT USER'S DATA -----//
  Future<void> _loadUserData() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        //----- CHECKING IF THE CURRENT USER IS SIGNED IN WITH GOOGLE -----//
        setState(() {
          _isGoogleSignIn = user.providerData
              .any((userInfo) => userInfo.providerId == 'google.com');
        });

        DocumentSnapshot userData = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (userData.exists) {
          setState(() {
            _firstnameController.text =
                userData['Firstname'] ?? 'Firstname not available';
            _surnameController.text =
                userData['Surname'] ?? 'Surname not available';
            _phoneNumController.text =
                userData['Contact Number'] ?? 'Contact Number not available';
          });
        }
      }
    } catch (e) {
      if (mounted) {
        const MySnackbar(message: 'Failed to load account details!')
            .showSnackBar(context);
      }
    }
  }

  //----- METHOD TO UPDATE EDITED PROFILE DETAILS -----//
  Future<void> _updateUserProfile() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .update({
          'Firstname': _firstnameController.text,
          'Surname': _surnameController.text,
          'Contact Number': _phoneNumController.text,
        });
      } catch (e) {
        if (mounted) {
          const MySnackbar(message: 'Failed to update Profile Details!')
              .showSnackBar(context);
        }
      }
    }
  }

// Validate current password
  Future<String?> validateCurrentPassword(String? currentPassword) async {
    User? user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      return 'User is not authenticated';
    }

    if (currentPassword == null || currentPassword.isEmpty) {
      return 'Please enter your current password';
    }

    try {
      AuthCredential credential = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );

      await user.reauthenticateWithCredential(credential);
      return null; // Password is correct
    } catch (e) {
      return 'Current password is incorrect';
    }
  }

  //----- METHOD TO UPDATE PASSWORD -----//
  Future<void> _updatePassword() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        // Reauthenticate with current password
        AuthCredential credential = EmailAuthProvider.credential(
          email: user.email!,
          password: _currentPasswordController.text,
        );

        await user.reauthenticateWithCredential(credential);

        // Check if the new password is provided
        if (_newPasswordController.text.isNotEmpty) {
          if (_newPasswordController.text ==
              _confirmedPasswordController.text) {
            await user.updatePassword(_newPasswordController.text);

            // Update password in Firestore
            await FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .update({
              'Password': _newPasswordController.text,
            });
          }
        } else {
          if (mounted) {
            const MySnackbar(
                    message:
                        'No new password provided, skipping password update')
                .showSnackBar(context);
          }
        }
      }
    } catch (e) {
      if (e is FirebaseAuthException) {
        if (mounted) {
          switch (e.code) {
            case 'weak-password':
              const MySnackbar(message: 'The password provided is too weak!')
                  .showSnackBar(context);
              break;
            case 'requires-recent-login':
              const MySnackbar(
                      message: 'Please reauthenticate to update your password.')
                  .showSnackBar(context);
              break;
            default:
              const MySnackbar(message: 'Failed to update account password!')
                  .showSnackBar(context);
          }
        }
      } else {
        if (mounted) {
          const MySnackbar(message: 'An unexpected error occurred!')
              .showSnackBar(context);
        }
      }
    }
  }

  //----- SHOW CONFIRMATION DIALOG ON BACK BUTTON PRESS -----//
  Future<bool> _onWillPop() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Go Back? Changes made will not be saved'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(true); // Return true when confirmed
                Navigator.pop(context);
              },
              child: const Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false); // Return false when declined
              },
              child: const Text('No'),
            ),
          ],
        );
      },
    );
    return result ?? false; // Ensure a boolean value is returned
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => _onWillPop(),
      child: Scaffold(
        appBar: MyAppBar(
          title: const Text(
            'Edit Profile',
          ),
          onBackButtonPressed: () async {
            bool shouldPop = await _onWillPop();
            if (shouldPop) {
              if (context.mounted) {
                Navigator.of(context).pop();
              }
            }
          },
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const SizedBox(height: 20),
                  const CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.blue,
                    child: Icon(
                      CupertinoIcons.person,
                      size: 40,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 20),
                  //----- FIRSTNAME TEXTFORMFIELD -----//
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _firstnameController,
                    decoration: formDecoration('First Name', Icons.person),
                    validator: validateFirstName,
                  ),

                  const SizedBox(height: 20),

                  //----- SURNAME TEXTFORMFIELD -----//
                  TextFormField(
                    keyboardType: TextInputType.text,
                    controller: _surnameController,
                    decoration: formDecoration('Surname', Icons.person),
                    validator: validateSurname,
                  ),

                  const SizedBox(height: 20),

                  //----- PHONENUMBER TEXTFORMFIELD -----//
                  TextFormField(
                    inputFormatters: [
                      PhoneFormatter(),
                      LengthLimitingTextInputFormatter(12),
                    ],
                    keyboardType: TextInputType.phone,
                    controller: _phoneNumController,
                    decoration: formDecoration('Contact Number', Icons.phone),
                    validator: validatePhoneNum,
                  ),

                  const SizedBox(height: 20),

                  //----- METHOD TO DISPLAY PASSWORD FIELDS TO USERS NOT AUTHENTICATED WITH GOOGLE SIGN-IN -----//
                  if (!_isGoogleSignIn) ...[
                    //----- CURRENT PASSWORD TEXTFORMFIELD -----//
                    TextFormField(
                      controller: _currentPasswordController,
                      decoration: formDecoration('Current Password', Icons.lock,
                          suffixIcon: _toggleCurrentPassword
                              ? Icons.visibility
                              : Icons.visibility_off, onPressed: () {
                        setState(() {
                          _toggleCurrentPassword = !_toggleCurrentPassword;
                        });
                      }),
                      validator: validatePassword,
                      obscureText: !_toggleCurrentPassword,
                      maxLength: 8,
                    ),
                    const SizedBox(height: 20),

                    //----- NEW PASSWORD TEXTFORMFIELD -----//
                    TextFormField(
                      controller: _newPasswordController,
                      decoration: formDecoration('New Password', Icons.lock,
                          suffixIcon: _togglePassword
                              ? Icons.visibility
                              : Icons.visibility_off, onPressed: () {
                        setState(() {
                          _togglePassword = !_togglePassword;
                        });
                      }),
                      obscureText: !_togglePassword,
                      maxLength: 8,
                      validator: (value) {
                        if (value != null && value.isNotEmpty) {
                          return validatePassword(
                              value); // Only validate if not empty
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 20),

                    //----- CONFIRM PASSWORD TEXTFORMFIELD -----//
                    TextFormField(
                      keyboardType: TextInputType.text,
                      controller: _confirmedPasswordController,
                      decoration: formDecoration('Confirm Password', Icons.lock,
                          suffixIcon: _togglePassword
                              ? Icons.visibility
                              : Icons.visibility_off, onPressed: () {
                        setState(() {
                          _togglePassword = !_togglePassword;
                        });
                      }),
                      obscureText: !_togglePassword,
                      validator: (value) {
                        if (_newPasswordController.text.isNotEmpty) {
                          return validateConfirmPassword(
                              _newPasswordController.text,
                              value); // Only validate if new password is provided
                        }
                        return null;
                      },
                      maxLength: 8,
                    ),

                    const SizedBox(height: 20),
                  ],

                  // Save Changes Button
                  MyButton(
                    buttonTitle: 'Save Changes',
                    onTap: () async {
                      if (_formKey.currentState!.validate()) {
                        // Only validate current password for non-Google sign-in users
                        if (!_isGoogleSignIn) {
                          String? currentPasswordValidationMessage =
                              await validateCurrentPassword(
                                  _currentPasswordController.text);

                          if (currentPasswordValidationMessage != null) {
                            if (context.mounted) {
                              // Use MySnackbar to display the validation message
                              MySnackbar(
                                      message: currentPasswordValidationMessage)
                                  .showSnackBar(context);
                            }
                            return; // Stop the update process if current password is incorrect
                          }
                        }

                        // Proceed with updating profile information
                        await _updateUserProfile();

                        // Update password if it's not Google sign-in and new password is provided
                        if (!_isGoogleSignIn &&
                            _newPasswordController.text.isNotEmpty) {
                          await _updatePassword();
                        }

                        if (context.mounted) {
                          Navigator.pop(context);
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) => MyDialogBox(
                              content: const Text(
                                'Changes been have saved!',
                                textAlign: TextAlign.center,
                              ),
                              icon: CupertinoIcons
                                  .person_crop_circle_badge_checkmark,
                              iconColor: Colors.green,
                              hideCloseButton: true,
                              buttons: [
                                MyButton(
                                  buttonTitle: 'Back to Profile',
                                  buttonType: ButtonType.filled,
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  color: Colors.blue,
                                ),
                              ],
                            ),
                          );
                        }
                      }
                    },
                    color: const Color.fromARGB(255, 119, 167, 206),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
} //END OF StudProfileEdit CLASS
