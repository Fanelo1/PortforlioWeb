// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: StudProfilePage CLASS (220024654, LK MAASDORP)
// PURPOSE: The profile page for the current student user

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/features/profile/presentation/stud_profile_edit_page.dart';

class StudProfilePage extends StatefulWidget {
  const StudProfilePage({super.key});

  @override
  State<StudProfilePage> createState() => _StudProfilePageState();
}

class _StudProfilePageState extends State<StudProfilePage> {
  final User? user = FirebaseAuth.instance.currentUser;

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _dobController = TextEditingController();
  final TextEditingController _contactController = TextEditingController();

  //----- METHOD THAT CHECKS IF THE CURRENT USER IS SIGNED IN AND RETRIEVE THEIR DETAILS -----//
  Future<DocumentSnapshot<Map<String, dynamic>>> getUserDetails() async {
    if (user != null) {
      try {
        return await FirebaseFirestore.instance
            .collection('users')
            .doc(user!.uid)
            .get();
      } catch (e) {
        throw Exception("Failed to retrieve user data");
      }
    } else {
      throw Exception("User is not signed in!");
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _dobController.dispose();
    _contactController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var paddingHorizontal = screenWidth * 0.05;
    var fontSize = screenWidth * 0.045;

    return Scaffold(
      appBar: MyAppBar(
        title: const Text('My Profile'),
        onLeadingIconPressed: () {
          Navigator.pop(context);
        },
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: paddingHorizontal),
        child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          future: getUserDetails(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(
                child: Text('Error: ${snapshot.error}'),
              );
            } else if (!snapshot.hasData || !snapshot.data!.exists) {
              return const Center(child: Text('No user data available.'));
            }

            //----- DISPLAYING CURRENT SIGNED IN USER'S DATA FROM FIRESTORE -----//
            Map<String, dynamic>? userData = snapshot.data!.data();
            _emailController.text =
                userData?['Email Address'] ?? 'Email Address not available';
            _dobController.text =
                userData?['Date Of Birth'] ?? 'Date of Birth not available';
            _contactController.text =
                userData?['Contact Number'] ?? 'Contact number not available';

            return SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),
                  const CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.blue,
                    child: Icon(
                      CupertinoIcons.person,
                      size: 40,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'SIGNED IN AS:',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.grey),
                  ),
                  Text(
                    '${userData?['Firstname'] ?? 'Fullname not available'} ${userData?['Surname'] ?? ''}',
                    style: TextStyle(fontSize: fontSize + 5),
                  ),

                  const SizedBox(height: 40),

                  //----- DISPLAYING THE USER'S DATA IN TEXTBOXES -----//
                  TextFormField(
                    controller: _emailController,
                    decoration: formDecoration('Email Address', Icons.mail),
                    readOnly: true,
                  ),

                  const SizedBox(height: 20),
                  //----- DISPLAYING THE USER'S DATA IN TEXTBOXES -----//
                  TextFormField(
                    controller: _dobController,
                    decoration:
                        formDecoration('Date of Birth', Icons.calendar_month),
                    readOnly: true,
                  ),

                  const SizedBox(height: 20),
                  //----- DISPLAYING THE USER'S DATA IN TEXTBOXES -----//
                  TextFormField(
                    controller: _contactController,
                    decoration: formDecoration('Contact Number', Icons.phone),
                    readOnly: true,
                  ),
                  const SizedBox(height: 50),

                  //----- EDIT PROFILE DETAILS BUTTON -----//
                  MyButton(
                    buttonTitle: 'Edit Profile',
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const StudProfileEdit()),
                      );
                      setState(() {});
                    },
                    color: Colors.blue,
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
