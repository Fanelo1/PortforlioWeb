import 'package:flutter/material.dart';

class ProfileState extends ChangeNotifier {
  bool _togglePassword = false;
  bool _toggleCurrentPassword = false;
  bool _isGoogleSignIn = false;

  final TextEditingController firstnameController = TextEditingController();
  final TextEditingController surnameController = TextEditingController();
  final TextEditingController phoneNumController = TextEditingController();
  final TextEditingController currentPasswordController =
      TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmedPasswordController =
      TextEditingController();

  bool get togglePassword => _togglePassword;
  bool get toggleCurrentPassword => _toggleCurrentPassword;
  bool get isGoogleSignIn => _isGoogleSignIn;

  void setGoogleSignIn(bool value) {
    _isGoogleSignIn = value;
    notifyListeners();
  }

  void togglePasswordVisibility() {
    _togglePassword = !_togglePassword;
    notifyListeners();
  }

  void toggleCurrentPasswordVisibility() {
    _toggleCurrentPassword = !_toggleCurrentPassword;
    notifyListeners();
  }

  @override
  void dispose() {
    firstnameController.dispose();
    surnameController.dispose();
    phoneNumController.dispose();
    currentPasswordController.dispose();
    newPasswordController.dispose();
    confirmedPasswordController.dispose();
    super.dispose();
  }
}
