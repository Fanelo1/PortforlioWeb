import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

class StorageList {
  final FirebaseStorage storage = FirebaseStorage.instance;

  Future<List<Reference>> fetchFiles(String path) async {
    print('Fetching files at path: $path');
    try {
      final ListResult result = await storage.ref(path).listAll();
      print('Files fetched successfully.');
      return result.items; // List of files in the specified path
    } catch (e) {
      print('Error fetching files: $e');
      return [];
    }
  }

  Future<List<Reference>> fetchFolders(String path) async {
    print('Fetching folders at path: $path');
    try {
      final ListResult result = await storage.ref(path).listAll();
      print('Folders fetched successfully.');
      return result.prefixes; // List of folders in the specified path
    } catch (e) {
      print('Error fetching folders: $e');
      return [];
    }
  }
}

class StorageListScreen extends StatefulWidget {
  const StorageListScreen({super.key});

  @override
  _StorageListScreenState createState() => _StorageListScreenState();
}

class _StorageListScreenState extends State<StorageListScreen> {
  final StorageList storageList = StorageList();
  late Future<List<Reference>> futureFolders;
  late Future<List<Reference>> futureFiles;

  String currentPath =
      'gs://studyappfirebase-1698b.appspot.com'; // Set your base path here

  @override
  void initState() {
    super.initState();
    print('Initializing storage list screen...');
    futureFolders = storageList.fetchFolders(currentPath);
    futureFiles = storageList.fetchFiles(currentPath);
  }

  Future<void> downloadFile(String fileUrl, String fileName) async {
    print('Attempting to download file: $fileName from $fileUrl');
    int retryCount = 0;
    const maxRetries = 3;

    while (retryCount < maxRetries) {
      try {
        final Dio dio = Dio();
        Directory appDocDir = await getApplicationDocumentsDirectory();
        String savePath = '${appDocDir.path}/$fileName';

        // Check if file already exists
        File file = File(savePath);
        if (await file.exists()) {
          print('File already exists. Overwriting: $savePath');
        } else {
          print('Saving file to: $savePath');
        }

        await dio.download(fileUrl, savePath,
            onReceiveProgress: (received, total) {
          print('Downloading... $received of $total bytes');
        });

        print('File downloaded to: $savePath');
        return; // Exit the loop on successful download
      } catch (e) {
        print('Error downloading file: $e');
        retryCount++;
        print('Retrying download... Attempt #$retryCount');
        await Future.delayed(const Duration(seconds: 2));
      }
    }
    print('Maximum retries exceeded. Download failed.');
  }

  Future<void> viewFile(String fileUrl) async {
    print('Attempting to view file at: $fileUrl');
    if (await canLaunchUrl(Uri.parse(fileUrl))) {
      await launchUrl(Uri.parse(fileUrl), mode: LaunchMode.externalApplication);
      print('File opened successfully.');
    } else {
      print('Could not launch $fileUrl');
    }
  }

  Future<void> fetchAndSetFiles(String folderPath) async {
    print('Fetching files in folder: $folderPath');
    setState(() {
      futureFiles = storageList.fetchFiles(folderPath);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Firebase Storage List')),
      body: FutureBuilder<List<Reference>>(
        future: futureFolders,
        builder: (context, folderSnapshot) {
          if (folderSnapshot.connectionState == ConnectionState.waiting) {
            print('Loading folders...');
            return const Center(child: CircularProgressIndicator());
          } else if (folderSnapshot.hasError) {
            print('Error in folder snapshot: ${folderSnapshot.error}');
            return Center(
                child: Text('Error fetching folders: ${folderSnapshot.error}'));
          } else if (!folderSnapshot.hasData || folderSnapshot.data!.isEmpty) {
            print('No folders found.');
            return const Center(child: Text('No folders found.'));
          }

          final folders = folderSnapshot.data!;
          print('Folders loaded: ${folders.length} folders found.');

          return Column(
            children: [
              Expanded(
                child: FutureBuilder<List<Reference>>(
                  future: futureFiles,
                  builder: (context, fileSnapshot) {
                    if (fileSnapshot.connectionState ==
                        ConnectionState.waiting) {
                      print('Loading files...');
                      return const Center(child: CircularProgressIndicator());
                    } else if (fileSnapshot.hasError) {
                      print('Error in file snapshot: ${fileSnapshot.error}');
                      return Center(
                          child: Text(
                              'Error fetching files: ${fileSnapshot.error}'));
                    } else if (!fileSnapshot.hasData ||
                        fileSnapshot.data!.isEmpty) {
                      print('No files found.');
                      return const Center(child: Text('No files found.'));
                    }

                    final files = fileSnapshot.data!;
                    print('Files loaded: ${files.length} files found.');

                    return ListView.builder(
                      itemCount: files.length,
                      itemBuilder: (context, index) {
                        print('Displaying file: ${files[index].name}');
                        return ListTile(
                          title: Text(files[index].name),
                          onTap: () async {
                            final fileUrl = await files[index].getDownloadURL();
                            await viewFile(fileUrl); // Open the file
                          },
                          trailing: IconButton(
                            icon: const Icon(Icons.download),
                            onPressed: () async {
                              try {
                                final fileUrl =
                                    await files[index].getDownloadURL();
                                await downloadFile(fileUrl,
                                    files[index].name); // Download the file
                              } catch (e) {
                                print('Error retrieving download URL: $e');
                              }
                            },
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
              const Divider(),
              Expanded(
                child: ListView.builder(
                  itemCount: folders.length,
                  itemBuilder: (context, index) {
                    print('Displaying folder: ${folders[index].name}');
                    return ListTile(
                      title: Text(folders[index].name),
                      onTap: () async {
                        String folderPath =
                            'gs://studyappfirebase-1698b.appspot.com/${folders[index].name}';
                        print('Navigating to folder: $folderPath');
                        await fetchAndSetFiles(folderPath);
                      },
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
