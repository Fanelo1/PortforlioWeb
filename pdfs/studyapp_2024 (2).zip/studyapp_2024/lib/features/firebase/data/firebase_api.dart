import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:http/http.dart' as http; // Import the http package
import 'package:studyapp_2024/features/firebase/state/firebase_state.dart';

class FirebaseApi {
  // Fetch download URLs for each item
  static Future<List<String>> _getDownloadLinks(List<Reference> refs) =>
      Future.wait(refs.map((ref) => ref.getDownloadURL()).toList());

  // Fetch list of files and folders from the specified path
  static Future<List<FirebaseFile>> listAll(String fullPath) async {
    final ref = FirebaseStorage.instance.refFromURL(fullPath);
    final result = await ref.listAll();

    // Get the download URLs
    final urls = await _getDownloadLinks(result.items);

    List<FirebaseFile> firebaseFiles = [];

    // Add folders to the list
    for (var folder in result.prefixes) {
      firebaseFiles.add(FirebaseFile(
        ref: folder,
        name: folder.name,
        url: '', // Folders don't have URLs
      ));
    }

    // Add files to the list
    firebaseFiles.addAll(urls
        .asMap()
        .map((index, url) {
          final ref = result.items[index];
          final name = ref.name;
          return MapEntry(index, FirebaseFile(ref: ref, name: name, url: url));
        })
        .values
        .toList());

    return firebaseFiles;
  }

  // Download file to the local storage
  static Future<void> downloadFile(Reference ref) async {
    try {
      final url = await ref.getDownloadURL(); // Get the download URL
      final response = await http.get(Uri.parse(url)); // Fetch file data

      if (response.statusCode == 200) {
        // Get a temporary directory for storing the file
        final directory = await getTemporaryDirectory();
        final file = File('${directory.path}/${ref.name}');
        await file.writeAsBytes(response.bodyBytes);

        print("File downloaded: ${file.path}");
      } else {
        print("Error downloading file: ${response.statusCode}");
      }
    } catch (e) {
      print("Error downloading file: $e");
    }
  }

  // Display PDF in-app by downloading to local storage first
  static Future<void> displayPdf(Reference ref, BuildContext context) async {
    try {
      final url = await ref.getDownloadURL(); // Get the download URL
      final response = await http.get(Uri.parse(url)); // Fetch file data

      if (response.statusCode == 200) {
        // Get a temporary directory for storing the PDF
        final directory = await getTemporaryDirectory();
        final pdfFile = File('${directory.path}/${ref.name}');
        await pdfFile.writeAsBytes(response.bodyBytes);

        // Open the PDF within the app using flutter_pdfview
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => PDFView(filePath: pdfFile.path),
          ),
        );
      } else {
        print("Error displaying PDF: ${response.statusCode}");
      }
    } catch (e) {
      print("Error displaying PDF: $e");
    }
  }
}
