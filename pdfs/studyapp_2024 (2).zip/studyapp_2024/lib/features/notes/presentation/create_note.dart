import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CreateNotePage extends StatefulWidget {
  final String folderId;
  final String folderName;
  final String noteId;
  final String userId;

  const CreateNotePage({
    super.key,
    required this.folderId,
    required this.folderName,
    required this.userId,
    required this.noteId,
  });

  @override
  _CreateNotePageState createState() => _CreateNotePageState();
}

class _CreateNotePageState extends State<CreateNotePage> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController sectionController = TextEditingController();
  final TextEditingController contentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.noteId.isNotEmpty) {
      _loadNoteData();
    }
  }

  Future<void> _loadNoteData() async {
    try {
      DocumentSnapshot noteSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .collection('folders')
          .doc(widget.folderId)
          .collection('notes')
          .doc(widget.noteId)
          .get();

      if (noteSnapshot.exists) {
        var data = noteSnapshot.data() as Map<String, dynamic>;
        titleController.text = data['title'] ?? '';
        sectionController.text = data['section'] ?? '';
        contentController.text = data['content'] ?? '';
        setState(() {});
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading note: $e')),
      );
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    sectionController.dispose();
    contentController.dispose();
    super.dispose();
  }

  Future<void> _addOrUpdateNote(BuildContext context) async {
    String title = titleController.text.trim();
    String section = sectionController.text.trim();
    String content = contentController.text.trim();

    if (title.isNotEmpty && section.isNotEmpty && content.isNotEmpty) {
      await _saveNote({
        'title': title,
        'section': section,
        'content': content,
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields.')),
      );
    }
  }

  Future<void> _saveNote(Map<String, dynamic> data) async {
    try {
      if (widget.noteId.isEmpty) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(widget.userId)
            .collection('folders')
            .doc(widget.folderId)
            .collection('notes')
            .add({
          ...data,
          'createdAt': FieldValue.serverTimestamp(),
          'modifiedAt': FieldValue.serverTimestamp(),
        });
      } else {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(widget.userId)
            .collection('folders')
            .doc(widget.folderId)
            .collection('notes')
            .doc(widget.noteId)
            .update({
          ...data,
          'modifiedAt': FieldValue.serverTimestamp(),
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Note saved successfully.')),
      );
      Navigator.of(context).pop();
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving note: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.noteId.isEmpty ? 'Create Note' : 'Edit Note'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTextForm(),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20.0),
            Center(
              child: ElevatedButton(
                onPressed: () => _addOrUpdateNote(context),
                child: const Text('Save Note'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Text form
  Widget _buildTextForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: titleController,
          decoration: const InputDecoration(
            labelText: 'Title',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8.0),
        TextField(
          controller: sectionController,
          decoration: const InputDecoration(
            labelText: 'Section',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8.0),
        TextField(
          controller: contentController,
          decoration: const InputDecoration(
            labelText: 'Content',
            border: OutlineInputBorder(),
          ),
          maxLines: 5,
        ),
      ],
    );
  }
}
