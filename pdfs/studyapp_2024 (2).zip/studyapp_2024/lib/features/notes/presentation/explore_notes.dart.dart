import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/firebase/data/firebase_api.dart';
import 'package:studyapp_2024/features/firebase/state/firebase_state.dart';
import 'package:studyapp_2024/features/notes/presentation/image_page.dart';
import 'package:studyapp_2024/features/notes/presentation/widgets/notes_loader.dart';

class ExploreNotes extends StatefulWidget {
  const ExploreNotes({super.key});

  @override
  _ExploreNotesState createState() => _ExploreNotesState();
}

class _ExploreNotesState extends State<ExploreNotes> {
  late Future<List<FirebaseFile>> futureFiles;
  String currentPath =
      'gs://studyappfirebase-1698b.appspot.com'; // Starting path

  @override
  void initState() {
    super.initState();
    futureFiles = FirebaseApi.listAll(currentPath);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Explore Notes'),
          centerTitle: true,
        ),
        body: FutureBuilder<List<FirebaseFile>>(
          future: futureFiles,
          builder: (context, snapshot) {
            switch (snapshot.connectionState) {
              case ConnectionState.waiting:
                return const Center(child: NotesLoader());
              default:
                if (snapshot.hasError) {
                  return const Center(child: Text('Some error occurred!'));
                } else {
                  final files = snapshot.data ?? [];
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      buildHeader(files.length),
                      const SizedBox(height: 12),
                      Expanded(
                        child: ListView.builder(
                          itemCount: files.length,
                          itemBuilder: (context, index) {
                            final file = files[index];
                            return buildFile(context, file);
                          },
                        ),
                      ),
                    ],
                  );
                }
            }
          },
        ),
      );

  Widget buildFile(BuildContext context, FirebaseFile file) => ListTile(
        leading: ClipOval(
          child: file.url.isEmpty
              ? const Icon(Icons.folder,
                  size: 40, color: Colors.yellow) // Folder icon
              : file.name.contains('.pdf')
                  ? const Icon(Icons.picture_as_pdf,
                      size: 40, color: Colors.red)
                  : file.name.contains('.doc')
                      ? const Icon(Icons.description,
                          size: 40, color: Colors.blue)
                      : Image.network(
                          file.url,
                          width: 52,
                          height: 52,
                          fit: BoxFit.cover,
                        ),
        ),
        title: Text(
          file.name,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            decoration: TextDecoration.underline,
            color: Colors.blue,
          ),
        ),
        onTap: () {
          if (file.url.isEmpty) {
            // If it's a folder, navigate to the new folder
            navigateToFolder(file.ref.fullPath);
          } else {
            // If it's a file, view it
            Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => ImagePage(file: file),
            ));
          }
        },
      );

  void navigateToFolder(String folderPath) {
    setState(() {
      currentPath = folderPath; // Update current path
      futureFiles =
          FirebaseApi.listAll(currentPath); // Fetch new files in the folder
    });
  }

  Widget buildHeader(int length) => ListTile(
        tileColor: Colors.blue,
        leading: const SizedBox(
          width: 52,
          height: 52,
          child: Icon(
            Icons.file_copy,
            color: Colors.white,
          ),
        ),
        title: Text(
          '$length Notes',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Colors.white,
          ),
        ),
      );
}
