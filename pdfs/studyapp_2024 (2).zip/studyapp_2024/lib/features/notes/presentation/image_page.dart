import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:path_provider/path_provider.dart';
import 'package:studyapp_2024/features/firebase/state/firebase_state.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path/path.dart' as path;
import 'package:device_info_plus/device_info_plus.dart';

class ImagePage extends StatefulWidget {
  final FirebaseFile file;

  const ImagePage({super.key, required this.file});

  @override
  _ImagePageState createState() => _ImagePageState();
}

class _ImagePageState extends State<ImagePage> {
  String? localFilePath;

  @override
  void initState() {
    super.initState();
    loadFile();
  }

  Future<void> loadFile() async {
    final isPdf = widget.file.name.endsWith('.pdf');
    final url = await widget.file.ref.getDownloadURL();

    if (isPdf) {
      final directory = await getTemporaryDirectory();
      final pdfFile = File('${directory.path}/${widget.file.name}');
      await pdfFile.writeAsBytes(
        (await widget.file.ref.getData())!,
        flush: true,
      );

      setState(() {
        localFilePath = pdfFile.path;
      });
    } else {
      setState(() {
        localFilePath = url;
      });
    }
  }

  Future<bool> _requestPermission(Permission permission) async {
    AndroidDeviceInfo build = await DeviceInfoPlugin().androidInfo;
    if (build.version.sdkInt >= 30) {
      // Request manageExternalStorage for Android 11+
      var result = await Permission.manageExternalStorage.request();
      return result.isGranted;
    } else {
      // Request storage permission for older Android versions
      var result = await permission.request();
      return result.isGranted;
    }
  }

  Future<void> downloadFileToStorage() async {
    if (await _requestPermission(Permission.storage)) {
      final directory = await getExternalStorageDirectory();
      final filePath = path.join(directory!.path, widget.file.name);
      final file = File(filePath);

      await file.writeAsBytes(
        (await widget.file.ref.getData())!,
        flush: true,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Downloaded ${widget.file.name} to storage')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content:
              const Text('Storage permission is needed to download files.'),
          action: SnackBarAction(
            label: 'Settings',
            onPressed: () {
              openAppSettings();
            },
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isImage = ['.jpeg', '.jpg', '.png'].any(widget.file.name.endsWith);
    final isPdf = widget.file.name.endsWith('.pdf');
    final isDoc = ['.doc', '.docx'].any(widget.file.name.endsWith);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.file.name),
        centerTitle: true,
        actions: [
          // IconButton(
          //   icon: const Icon(Icons.file_download),
          //   onPressed: downloadFileToStorage,
          // ),
        ],
      ),
      body: localFilePath == null
          ? const Center(child: CircularProgressIndicator())
          : isImage
              ? Image.network(localFilePath!,
                  height: double.infinity, fit: BoxFit.cover)
              : isPdf
                  ? PDFView(
                      filePath: localFilePath!,
                      onError: (error) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Error displaying PDF')),
                        );
                      },
                    )
                  : isDoc
                      ? Center(
                          child: TextButton(
                            onPressed: () async {
                              if (await canLaunch(localFilePath!)) {
                                await launch(localFilePath!);
                              }
                            },
                            child: Text("Open ${widget.file.name}"),
                          ),
                        )
                      : const Center(
                          child: Text(
                            'Cannot display this file type',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                        ),
    );
  }
}
