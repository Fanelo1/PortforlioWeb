import 'package:flutter/material.dart';

class ShortAnswerQuestion extends StatefulWidget {
  final String question;
  final Function(String) onAnswerSubmitted;

  const ShortAnswerQuestion({
    Key? key,
    required this.question,
    required this.onAnswerSubmitted,
  }) : super(key: key);

  @override
  _ShortAnswerQuestionState createState() => _ShortAnswerQuestionState();
}

class _ShortAnswerQuestionState extends State<ShortAnswerQuestion> {
  final TextEditingController _answerController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Card or ListTile for the question
        Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            title: Text(widget.question, style: const TextStyle(fontSize: 18)),
          ),
        ),
        // Card or ListTile for the answer input
        Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _answerController,
              decoration: const InputDecoration(
                hintText: 'Type your answer here...',
                border: InputBorder.none,
              ),
              onSubmitted: (value) {
                widget.onAnswerSubmitted(
                    value); // Submit the answer when the user presses enter
                _answerController
                    .clear(); // Clear the text field after submission
              },
            ),
          ),
        ),
      ],
    );
  }
}
