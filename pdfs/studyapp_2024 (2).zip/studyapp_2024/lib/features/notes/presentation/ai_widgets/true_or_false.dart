import 'package:flutter/material.dart';

class TrueFalseQuestion extends StatefulWidget {
  final String question;
  final Function(bool) onAnswerSelected;

  const TrueFalseQuestion({
    Key? key,
    required this.question,
    required this.onAnswerSelected,
  }) : super(key: key);

  @override
  _TrueFalseQuestionState createState() => _TrueFalseQuestionState();
}

class _TrueFalseQuestionState extends State<TrueFalseQuestion> {
  bool? selectedAnswer;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.question, style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 10),
        ListTile(
          title: const Text("True"),
          tileColor: selectedAnswer == true
              ? Colors.blue.withOpacity(0.3)
              : null, // Highlight if selected
          onTap: () {
            setState(() {
              selectedAnswer = true;
            });
            widget.onAnswerSelected(true);
          },
          trailing: selectedAnswer == true
              ? const Icon(Icons.check, color: Colors.blue)
              : null, // Optional check icon
        ),
        ListTile(
          title: const Text("False"),
          tileColor: selectedAnswer == false
              ? Colors.blue.withOpacity(0.3)
              : null, // Highlight if selected
          onTap: () {
            setState(() {
              selectedAnswer = false;
            });
            widget.onAnswerSelected(false);
          },
          trailing: selectedAnswer == false
              ? const Icon(Icons.check, color: Colors.blue)
              : null, // Optional check icon
        ),
      ],
    );
  }
}
