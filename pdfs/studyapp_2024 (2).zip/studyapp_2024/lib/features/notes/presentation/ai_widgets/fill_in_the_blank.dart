import 'package:flutter/material.dart';

class FillInTheBlankQuestion extends StatefulWidget {
  final String question;
  final String hintText; // Hint for the fill-in-the-blank
  final Function(String) onAnswerSubmitted;

  const FillInTheBlankQuestion({
    Key? key,
    required this.question,
    required this.hintText,
    required this.onAnswerSubmitted,
  }) : super(key: key);

  @override
  _FillInTheBlankQuestionState createState() => _FillInTheBlankQuestionState();
}

class _FillInTheBlankQuestionState extends State<FillInTheBlankQuestion> {
  final TextEditingController _answerController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Card or ListTile for the question
        Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            title: Text(widget.question, style: const TextStyle(fontSize: 18)),
          ),
        ),
        // Card or ListTile for the answer input
        Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _answerController,
              decoration: InputDecoration(
                hintText: widget.hintText, // Hint text for the blank
                border: InputBorder.none,
              ),
              onSubmitted: (value) {
                widget.onAnswerSubmitted(
                    value); // Submit the answer when the user presses enter
                _answerController
                    .clear(); // Clear the text field after submission
              },
            ),
          ),
        ),
      ],
    );
  }
}
