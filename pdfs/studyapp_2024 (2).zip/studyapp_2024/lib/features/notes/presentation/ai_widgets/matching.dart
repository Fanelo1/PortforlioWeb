import 'package:flutter/material.dart';

class MatchingQuestion extends StatefulWidget {
  final List<String> terms; // List of terms
  final List<String> descriptions; // List of descriptions
  final Function(Map<String, String>)
      onMatchesSubmitted; // Callback for submitted matches

  const MatchingQuestion({
    super.key,
    required this.terms,
    required this.descriptions,
    required this.onMatchesSubmitted,
  });

  @override
  _MatchingQuestionState createState() => _MatchingQuestionState();
}

class _MatchingQuestionState extends State<MatchingQuestion> {
  final Map<String, String> _matches = {}; // Map to hold term-description pairs
  final List<String> _selectedTerms = []; // List to track selected terms

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Card for Terms
        Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            title: const Text("Terms",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            subtitle: Column(
              children: widget.terms.map((term) {
                return ListTile(
                  title: Text(term),
                  onTap: () {
                    _selectTerm(term);
                  },
                );
              }).toList(),
            ),
          ),
        ),
        // Card for Descriptions
        Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            title: const Text("Descriptions",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            subtitle: Column(
              children: widget.descriptions.map((description) {
                return ListTile(
                  title: Text(description),
                  onTap: () {
                    _selectDescription(description);
                  },
                );
              }).toList(),
            ),
          ),
        ),
        // Card for Answers
        Card(
          margin: const EdgeInsets.symmetric(vertical: 8.0),
          child: ListTile(
            title: const Text("Matches",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            subtitle: Column(
              children: _matches.entries.map((entry) {
                return ListTile(
                  title: Text('${entry.key}: ${entry.value}'),
                );
              }).toList(),
            ),
          ),
        ),
        // Button to Submit Matches
        ElevatedButton(
          onPressed: () {
            widget.onMatchesSubmitted(_matches);
          },
          child: const Text("Submit Matches"),
        ),
      ],
    );
  }

  void _selectTerm(String term) {
    setState(() {
      if (_matches.containsKey(term)) {
        _matches.remove(term); // Remove if already matched
      } else {
        _selectedTerms.add(term); // Add to selected terms
      }
    });
  }

  void _selectDescription(String description) {
    if (_selectedTerms.isNotEmpty) {
      setState(() {
        _matches[_selectedTerms.last] =
            description; // Match last selected term with the description
        _selectedTerms.removeLast(); // Remove the matched term
      });
    }
  }
}
