import 'package:flutter/material.dart';

class MultipleChoiceQuestion extends StatefulWidget {
  final String question;
  final List<String> options;
  final Function(String) onAnswerSelected;

  MultipleChoiceQuestion({
    required this.question,
    required this.options,
    required this.onAnswerSelected,
  });

  @override
  _MultipleChoiceQuestionState createState() => _MultipleChoiceQuestionState();
}

class _MultipleChoiceQuestionState extends State<MultipleChoiceQuestion> {
  String? selectedAnswer;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.question, style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 10),
        for (var option in widget.options)
          RadioListTile<String>(
            title: Text(option),
            value: option,
            groupValue: selectedAnswer,
            onChanged: (value) {
              setState(() {
                selectedAnswer = value;
              });
              widget.onAnswerSelected(value!);
            },
          ),
      ],
    );
  }
}
