import 'package:flutter/material.dart';

class MultipleChoiceQuestion extends StatefulWidget {
  final String question;
  final List<String> options;
  final Function(String) onAnswerSelected;

  const MultipleChoiceQuestion({
    Key? key,
    required this.question,
    required this.options,
    required this.onAnswerSelected,
  }) : super(key: key);

  @override
  _MultipleChoiceQuestionState createState() => _MultipleChoiceQuestionState();
}

class _MultipleChoiceQuestionState extends State<MultipleChoiceQuestion> {
  String? selectedAnswer;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.question, style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 10),
        for (var option in widget.options)
          ListTile(
            title: Text(option),
            tileColor: selectedAnswer == option
                ? Colors.blue.withOpacity(0.3)
                : null, // Change background color if selected
            onTap: () {
              setState(() {
                selectedAnswer = option;
              });
              widget.onAnswerSelected(option);
            },
            // Optional: Add a trailing icon or other indicators if needed
            trailing: selectedAnswer == option
                ? const Icon(Icons.check, color: Colors.blue)
                : null,
          ),
      ],
    );
  }
}
