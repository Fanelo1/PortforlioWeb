import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:studyapp_2024/features/notes/presentation/widgets/custom_loading.dart';

class GenerateQuestionPage extends StatefulWidget {
  final String noteId;
  final String userId;
  final String folderId;

  const GenerateQuestionPage({
    super.key,
    required this.noteId,
    required this.userId,
    required this.folderId,
  });

  @override
  _GenerateQuestionPageState createState() => _GenerateQuestionPageState();
}

class _GenerateQuestionPageState extends State<GenerateQuestionPage> {
  final List<String> _questionTypes = [
    'Multiple Choice',
    'True or False',
    'Short Answer',
    'Fill in the Blank',
    'Matching'
  ];
  final List<int> _questionCounts = [5, 10, 15, 20, 25, 30];

  String? _selectedType;
  int _selectedQuestionCount = 5;
  bool _isLoading = false;
  String? _generatedQuestions;
  String? _noteContent;

  final _storage = const FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
    _loadNoteContent();
  }

  Future<void> _loadNoteContent() async {
    setState(() {
      _isLoading = true;
    });
    try {
      var noteDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .collection('folders')
          .doc(widget.folderId)
          .collection('notes')
          .doc(widget.noteId)
          .get();

      if (noteDoc.exists && noteDoc.data()!.containsKey('content')) {
        setState(() {
          _noteContent = noteDoc['content'];
        });
      } else {
        _showSnackBar('Note content not found');
      }
    } catch (error) {
      _showSnackBar('Error loading note content: $error');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> initializeGeminiService() async {
    final apiKey = await _storage.read(key: 'api_key');
    print("Retrieved API Key: $apiKey"); // Check if this returns null

    if (apiKey == null) {
      _showSnackBar('API key is not set.');
      return;
    }

    try {
      final model = GenerativeModel(model: 'gemini-1.5-flash', apiKey: apiKey);
      final prompt = Content.multi([
        TextPart(
            "Generate $_selectedQuestionCount $_selectedType questions based on this content: $_noteContent."
            "After all questions are generated , display the answers")
      ]);

      final response = await model.generateContent([prompt]);
      setState(() {
        _generatedQuestions = response.text;
      });
    } catch (error) {
      _showSnackBar('Error generating question paper: $error');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _generateQuestionPaper() async {
    if (_selectedType == null || _noteContent == null) {
      _showSnackBar('Please fill in all required fields');
      return;
    }
    setState(() {
      _isLoading = true;
      _generatedQuestions = null;
    });
    await initializeGeminiService();
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Widget _buildGeneratedQuestionsUI() {
    if (_generatedQuestions == null) {
      return const SizedBox.shrink();
    }

    final questionsList = _generatedQuestions!.split('\n');
    return Expanded(
      child: ListView(
        children: questionsList
            .map((question) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4.0),
                  child: Text(question, style: const TextStyle(fontSize: 16)),
                ))
            .toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Generate Question Paper',
          style: TextStyle(
            color: Colors.blue,
            fontWeight: FontWeight.w500,
            fontSize: 18,
          ),
          overflow: TextOverflow.ellipsis,
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Removed the Question Paper Title TextField
            const SizedBox(height: 20),
            const Text('Select Question Type'),
            DropdownButtonFormField<String>(
              value: _selectedType,
              items: _questionTypes.map((type) {
                return DropdownMenuItem<String>(
                  value: type,
                  child: Text(type),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedType = value;
                  _generatedQuestions = null;
                });
              },
              decoration: const InputDecoration(
                filled: true,
                fillColor: Colors.white, // White fill color
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue), // Blue outline
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Colors.blue), // Blue outline on focus
                ),
                hintText: 'Choose a question type',
              ),
              hint: const Text('Choose a question type'),
            ),
            const SizedBox(height: 20),
            const Text('Select Number of Questions'),
            DropdownButtonFormField<int>(
              value: _selectedQuestionCount,
              items: _questionCounts.map((count) {
                return DropdownMenuItem<int>(
                  value: count,
                  child: Text(count.toString()),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedQuestionCount = value!;
                  _generatedQuestions = null;
                });
              },
              decoration: const InputDecoration(
                filled: true,
                fillColor: Colors.white, // White fill color
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue), // Blue outline
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Colors.blue), // Blue outline on focus
                ),
                hintText: 'Choose question count',
              ),
              hint: const Text('Choose question count'),
            ),
            const SizedBox(height: 20),
            _isLoading
                ? const CustomLoading()
                : ElevatedButton(
                    onPressed: _generateQuestionPaper,
                    child: const Text('Generate Questions'),
                  ),
            const SizedBox(height: 20),
            _buildGeneratedQuestionsUI(),
          ],
        ),
      ),
    );
  }
}
