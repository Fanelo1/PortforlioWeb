import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';

class FolderList extends StatelessWidget {
  final String folderName;
  final String folderId;
  final String userId;

  const FolderList({
    required this.folderName,
    required this.folderId,
    required this.userId,
    super.key,
  });

  Future<void> _deleteFolder(BuildContext context, String folderId) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('folders')
          .doc(folderId)
          .delete();
      _showDialog(context, 'Success', 'Folder successfully deleted!',
          Icons.check_circle_outline, Colors.green);
    } catch (error) {
      _showDialog(
          context,
          'Error',
          'Failed to delete folder. Please try again.',
          Icons.error,
          Colors.red);
    }
  }

  void _showDialog(BuildContext context, String title, String message,
      IconData icon, Color iconColor) {
    showDialog(
      context: context,
      builder: (context) => MyDialogBox(
        title: title,
        content: Text(message),
        icon: icon,
        iconColor: iconColor,
        buttons: [
          MyButton(
            buttonTitle: 'OK',
            onTap: () => Navigator.of(context).pop(),
            color: iconColor,
          ),
        ],
      ),
    );
  }

  void _showEditDialog(
      BuildContext context, String folderId, String initialFolderName) {
    final TextEditingController _editController =
        TextEditingController(text: initialFolderName);

    showDialog(
      context: context,
      builder: (context) {
        return MyDialogBox(
          title: 'Edit Folder Name',
          icon: Icons.edit,
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _editController,
                decoration: const InputDecoration(
                  labelText: 'Folder Name',
                  icon: Icon(Icons.folder),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: MyButton(
                      buttonTitle: 'Cancel',
                      onTap: () => Navigator.of(context).pop(),
                      color: const Color.fromARGB(255, 245, 83, 175),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: MyButton(
                      buttonTitle: 'Save',
                      onTap: () async {
                        String newFolderName = _editController.text.trim();
                        if (newFolderName.isNotEmpty) {
                          try {
                            await FirebaseFirestore.instance
                                .collection('users')
                                .doc(userId)
                                .collection('folders')
                                .doc(folderId)
                                .update({'folderName': newFolderName});
                            Navigator.of(context).pop();
                            _showDialog(
                                context,
                                'Success',
                                'Folder name updated!',
                                Icons.check_circle_outline,
                                const Color.fromARGB(255, 119, 214, 240));
                          } catch (error) {
                            _showDialog(
                                context,
                                'Error',
                                'Failed to update folder name.',
                                Icons.error,
                                Colors.red);
                          }
                        } else {
                          _showDialog(
                              context,
                              'Error',
                              'Folder name cannot be empty.',
                              Icons.error,
                              Colors.red);
                        }
                      },
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _confirmDelete(BuildContext context, String folderId) {
    showDialog(
      context: context,
      builder: (context) {
        return MyDialogBox(
          title: 'Confirm Delete',
          content: const Text('Are you sure you want to delete this folder?'),
          icon: Icons.warning,
          iconColor: const Color.fromARGB(255, 113, 94, 66),
          buttons: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: MyButton(
                    buttonTitle: 'Cancel',
                    onTap: () => Navigator.of(context).pop(),
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: MyButton(
                    buttonTitle: 'Delete',
                    onTap: () {
                      Navigator.of(context).pop(); // Close the dialog first
                      _deleteFolder(
                          context, folderId); // Then proceed with deletion
                    },
                    color: Colors.red,
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Container(
          width: 60,
          decoration: const BoxDecoration(
            color: Color.fromARGB(255, 180, 214, 241),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10), // Rounded corner at the top left
              bottomLeft:
                  Radius.circular(10), // Rounded corner at the bottom left
            ),
          ),
          child: const Center(
            child: Icon(
              Icons.folder_outlined,
              color: Colors.black,
              size: 25,
            ),
          ),
        ),
        title: Text(
          folderName,
          style: const TextStyle(fontSize: 15),
        ),
        onTap: () {
          // Navigate to NotesInFolderPage
          Navigator.pushNamed(
            context,
            '/notesPage',
            arguments: {
              'folderId': folderId,
              'folderName': folderName,
            },
          );
        },
        trailing: Transform.translate(
          offset: const Offset(0, -8),
          child: PopupMenuButton(
            icon: const Icon(Icons.more_vert),
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit, color: Colors.black),
                    SizedBox(width: 8),
                    Text('Edit'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete'),
                  ],
                ),
              ),
            ],
            onSelected: (value) {
              if (value == 'edit') {
                _showEditDialog(context, folderId, folderName);
              } else if (value == 'delete') {
                _confirmDelete(context, folderId);
              }
            },
          ),
        ),
      ),
    );
  }
}
