// import 'package:flutter/material.dart';

// class QuestionSettingsWidget extends StatefulWidget {
//   final String selectedQuestionType;
//   final String selectedLanguage;
//   final int selectedMaxQuestions;
//   final ValueChanged<String> onQuestionTypeChanged;
//   final ValueChanged<String> onLanguageChanged;
//   final ValueChanged<int> onMaxQuestionsChanged;

//   const QuestionSettingsWidget({
//     super.key,
//     required this.selectedQuestionType,
//     required this.selectedLanguage,
//     required this.selectedMaxQuestions,
//     required this.onQuestionTypeChanged,
//     required this.onLanguageChanged,
//     required this.onMaxQuestionsChanged,
//   });

//   @override
//   _QuestionSettingsWidgetState createState() => _QuestionSettingsWidgetState();
// }

// class _QuestionSettingsWidgetState extends State<QuestionSettingsWidget> {
//   late String _selectedQuestionType;
//   late String _selectedLanguage;
//   late int _selectedMaxQuestions;

//   final List<String> _questionTypes = [
//     'Multiple choice',
//     'True or False',
//     'Short question',
//     'Fill in the blank',
//     'Matching',
//     'Mixed',
//   ];

//   final List<String> _languages = [
//     'English',
//     'Spanish',
//     'French',
//     'German',
//     'Chinese',
//     'Japanese',
//     'Russian',
//     'Portuguese',
//     'Arabic',
//     'Italian',
//     'Hindi',
//   ];

//   final List<int> _maxQuestionsOptions = [5, 10, 20, 25, 30, 35, 40, 45];

//   @override
//   void initState() {
//     super.initState();
//     _selectedQuestionType = widget.selectedQuestionType;
//     _selectedLanguage = widget.selectedLanguage;
//     _selectedMaxQuestions = widget.selectedMaxQuestions;
//   }

//   void _saveSelections() {
//     widget.onQuestionTypeChanged(_selectedQuestionType);
//     widget.onLanguageChanged(_selectedLanguage);
//     widget.onMaxQuestionsChanged(_selectedMaxQuestions);

//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(
//           'Settings Saved: \nQuestion Type: $_selectedQuestionType\n'
//           'Language: $_selectedLanguage\n'
//           'Max Questions: $_selectedMaxQuestions',
//         ),
//       ),
//     );
//   }

//   @override
//   void didUpdateWidget(QuestionSettingsWidget oldWidget) {
//     super.didUpdateWidget(oldWidget);
//     if (oldWidget.selectedQuestionType != widget.selectedQuestionType) {
//       _selectedQuestionType = widget.selectedQuestionType;
//     }
//     if (oldWidget.selectedLanguage != widget.selectedLanguage) {
//       _selectedLanguage = widget.selectedLanguage;
//     }
//     if (oldWidget.selectedMaxQuestions != widget.selectedMaxQuestions) {
//       _selectedMaxQuestions = widget.selectedMaxQuestions;
//     }
//   }

//   // In QuestionSettingsWidget
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Question Settings'),
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text('Question Type:'),
//             DropdownButtonFormField<String>(
//               value: _selectedQuestionType, // Correctly use question type
//               decoration: const InputDecoration(
//                 labelText: 'Select Question Type',
//                 border: OutlineInputBorder(),
//               ),
//               items: _questionTypes.map((String type) {
//                 return DropdownMenuItem<String>(
//                   value: type,
//                   child: Text(type),
//                 );
//               }).toList(),
//               onChanged: (String? newValue) {
//                 setState(() {
//                   _selectedQuestionType = newValue!;
//                 });
//               },
//             ),
//             const SizedBox(height: 16.0),
//             const Text('Language:'),
//             DropdownButtonFormField<String>(
//               value: _selectedLanguage,
//               decoration: const InputDecoration(
//                 labelText: 'Select Language',
//                 border: OutlineInputBorder(),
//               ),
//               items: _languages.map((String lang) {
//                 return DropdownMenuItem<String>(
//                   value: lang,
//                   child: Text(lang),
//                 );
//               }).toList(),
//               onChanged: (String? newValue) {
//                 setState(() {
//                   _selectedLanguage = newValue!;
//                 });
//               },
//             ),
//             const SizedBox(height: 16.0),
//             const Text('Max Questions:'),
//             DropdownButtonFormField<int>(
//               value: _selectedMaxQuestions,
//               decoration: const InputDecoration(
//                 labelText: 'Select Max Questions',
//                 border: OutlineInputBorder(),
//               ),
//               items: _maxQuestionsOptions.map((int option) {
//                 return DropdownMenuItem<int>(
//                   value: option,
//                   child: Text(option.toString()),
//                 );
//               }).toList(),
//               onChanged: (int? newValue) {
//                 setState(() {
//                   _selectedMaxQuestions = newValue!;
//                 });
//               },
//             ),
//             const SizedBox(height: 32.0),
//             Center(
//               child: ElevatedButton(
//                 onPressed: _saveSelections,
//                 child: const Text('Save Settings'),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
