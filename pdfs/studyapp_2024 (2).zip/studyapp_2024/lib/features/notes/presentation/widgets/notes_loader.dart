import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class NotesLoader extends StatelessWidget {
  const NotesLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return Lottie.asset(
      'assets/animations/notes_loading.json',
      width: 300,
      height: 300,
    );
  }
}
