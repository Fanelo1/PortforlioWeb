import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';

class NotesWidgets extends StatelessWidget {
  final String userId;
  final String folderId;
  final String noteId;
  final String title;
  final String content;
  final Timestamp? createdAt;
  final Timestamp? modifiedAt;
  final VoidCallback onTap;
  final VoidCallback onGenerateQuestion;

  const NotesWidgets({
    super.key,
    required this.userId,
    required this.folderId,
    required this.noteId,
    required this.title,
    required this.content,
    this.createdAt,
    this.modifiedAt,
    required this.onTap,
    required this.onGenerateQuestion,
  });

  // Deleting a note
  Future<void> _deleteNote(BuildContext context) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('folders')
          .doc(folderId)
          .collection('notes')
          .doc(noteId)
          .delete();
      _showSuccessDialog(context, 'Success', 'Note successfully deleted!');
    } catch (error) {
      _showErrorDialog(
          context, 'Error', 'Failed to delete note. Please try again.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: Colors.yellow,
          child: ListTile(
            title: Text(title),
            subtitle: Text(content),
            leading: const Icon(Icons.note),
            onTap: onTap,
            trailing: PopupMenuButton(
              icon: const Icon(Icons.more_vert),
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'edit',
                  child: Row(
                    children: [
                      Icon(Icons.edit, color: Colors.black),
                      SizedBox(width: 8),
                      Text('Edit'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      Icon(Icons.delete, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Delete'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: 'generate',
                  child: Row(
                    children: [
                      Icon(Icons.question_answer, color: Colors.blue),
                      SizedBox(width: 8),
                      Text('Generate Question'),
                    ],
                  ),
                ),
              ],
              onSelected: (value) {
                if (value == 'edit') {
                  _showEditDialog(context);
                } else if (value == 'delete') {
                  _confirmDelete(context);
                } else if (value == 'generate') {
                  onGenerateQuestion();
                }
              },
            ),
          ),
        ),
        const SizedBox(height: 8),
        if (createdAt != null)
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: Text(
              'Created: ${createdAt!.toDate()}',
              style: const TextStyle(color: Colors.white),
            ),
          ),
        const SizedBox(height: 8),
      ],
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return MyDialogBox(
          title: 'Confirm Delete',
          content: const Text('Are you sure you want to delete this note?'),
          icon: Icons.warning,
          iconColor: Colors.orange,
          buttons: [
            MyButton(
              buttonTitle: 'Cancel',
              onTap: () {
                Navigator.of(context).pop();
              },
              color: Colors.grey,
            ),
            const SizedBox(width: 10),
            MyButton(
              buttonTitle: 'Delete',
              onTap: () {
                Navigator.of(context).pop();
                _deleteNote(context);
              },
              color: Colors.red,
            ),
          ],
        );
      },
    );
  }

  void _showSuccessDialog(BuildContext context, String title, String message) {
    showDialog(
      context: context,
      builder: (context) => MyDialogBox(
        title: title,
        content: Text(message),
        icon: Icons.check_circle_outline,
        iconColor: Colors.green,
        buttons: [
          MyButton(
            buttonTitle: 'OK',
            onTap: () {
              Navigator.of(context).pop();
            },
            color: Colors.green,
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(BuildContext context, String title, String message) {
    showDialog(
      context: context,
      builder: (context) => MyDialogBox(
        title: title,
        content: Text(message),
        icon: Icons.error,
        iconColor: Colors.red,
        buttons: [
          MyButton(
            buttonTitle: 'OK',
            onTap: () {
              Navigator.of(context).pop();
            },
            color: Colors.red,
          ),
        ],
      ),
    );
  }

  void _showEditDialog(BuildContext context) {
    final TextEditingController _editController = TextEditingController();
    _editController.text = title; // Use the title of the note

    showDialog(
      context: context,
      builder: (context) {
        return MyDialogBox(
          title: 'Edit Note Name',
          icon: Icons.edit,
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _editController,
                decoration: const InputDecoration(
                  labelText: 'Note Name',
                  icon: Icon(Icons.note),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
          buttons: [
            MyButton(
              buttonTitle: 'Cancel',
              onTap: () {
                Navigator.of(context).pop();
              },
              color: Colors.red,
            ),
            const SizedBox(width: 10),
            MyButton(
              buttonTitle: 'Save',
              onTap: () async {
                String newNoteName = _editController.text.trim();
                if (newNoteName.isNotEmpty) {
                  try {
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(userId)
                        .collection('folders')
                        .doc(folderId)
                        .collection('notes')
                        .doc(noteId)
                        .update({'title': newNoteName});
                    Navigator.of(context).pop();
                    _showSuccessDialog(
                        context, 'Success', 'Note name updated!');
                  } catch (error) {
                    _showErrorDialog(
                        context, 'Error', 'Failed to update note name.');
                  }
                } else {
                  _showErrorDialog(
                      context, 'Error', 'Note name cannot be empty.');
                }
              },
              color: Colors.green,
            ),
          ],
        );
      },
    );
  }
}
