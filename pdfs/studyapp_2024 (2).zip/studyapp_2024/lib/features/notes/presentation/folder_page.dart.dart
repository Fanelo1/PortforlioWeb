// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/features/notes/presentation/widgets/folder_widget.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';

class FoldersPage extends StatefulWidget {
  const FoldersPage({super.key});

  @override
  _FoldersPageState createState() => _FoldersPageState();
}

class _FoldersPageState extends State<FoldersPage> {
  final _folderNameController = TextEditingController();
  String _searchQuery = '';
  bool _isAscending = true; // Change this to a mutable boolean
  final String userId = 'exampleUserId'; // Replace with the actual user ID

  @override
  void dispose() {
    _folderNameController.dispose();
    super.dispose();
  }

  Future<void> _createFolder() async {
    String folderName = _folderNameController.text.trim();

    if (folderName.isNotEmpty) {
      try {
        // Folder creation logic under specific user
        DocumentReference folderRef = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .collection('folders')
            .add({
          'folderName': folderName,
          'createdAt': FieldValue.serverTimestamp(),
        });

        // Create a sub-collection for notes in the new folder
        await folderRef
            .collection('notes')
            .add({}); // Initialize with an empty note or any default structure

        // Confirmation dialog
        showDialog(
          context: context,
          builder: (context) => const MyDialogBox(
            title: 'Success',
            content: Text('Folder successfully created!'),
            icon: Icons.check_circle_outline,
            iconColor: Colors.green,
          ),
        );

        _folderNameController.clear();
      } catch (e) {
        // Error dialog
        showDialog(
          context: context,
          builder: (context) => MyDialogBox(
            title: 'Error',
            content: Text('Failed to create folder: $e'),
            icon: Icons.error_outline,
            iconColor: Colors.red,
          ),
        );
      }
    }
  }

  Stream<QuerySnapshot> _getFolders() {
    return FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('folders')
        .orderBy('createdAt', descending: !_isAscending) // Sort logic here
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Folders',
          style: TextStyle(
            color: Colors.blue,
            fontWeight: FontWeight.w500,
          ),
        ),
        centerTitle: true, // Centers the title
        // actions: [
        //   IconButton(
        //     icon: const Icon(Icons.notifications, color: Colors.black),
        //     onPressed: () {
        //       Navigator.pushNamed(context, RouteManager.studentMainPage);
        //     },
        //   ),
        // ],
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 30.0),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start, // Aligns items to the left
          children: [
            // Search Bar
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      filled: true, // Enables the fill color
                      fillColor: Colors.white, // Sets the fill color to white
                      border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(8.0), // Rounded corners
                        borderSide: const BorderSide(
                          color: Colors.grey, // Grey outline
                          width: 1.0, // Outline width
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(8.0), // Rounded corners
                        borderSide: const BorderSide(
                          color: Colors.grey, // Grey outline for enabled state
                          width: 1.0, // Outline width
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(8.0), // Rounded corners
                        borderSide: const BorderSide(
                          color: Colors.grey, // Grey outline for focused state
                          width: 1.0, // Outline width
                        ),
                      ),
                      labelText: 'Search Folders',
                      prefixIcon: const Icon(Icons.search),
                    ),
                    onChanged: (value) {
                      setState(() {
                        _searchQuery = value;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 10),
                // Sort Icon Button
                IconButton(
                  icon: Icon(
                    _isAscending ? Icons.arrow_upward : Icons.arrow_downward,
                  ), // Icon changes based on sort order
                  onPressed: () {
                    setState(() {
                      _isAscending = !_isAscending; // Toggle sort order
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 10), // Spacing between search bar and label
            const Text(
              'Subjects/Modules',
              style: TextStyle(
                fontSize: 16, // Font size for the label
                fontWeight: FontWeight.bold, // Makes the label bold
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: _getFolders(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return const Center(child: Text('Error loading folders.'));
                  }

                  final folders = snapshot.data?.docs.where((doc) {
                    final folderName = doc['folderName'] as String;
                    return folderName
                        .toLowerCase()
                        .contains(_searchQuery.toLowerCase());
                  }).toList();

                  return ListView.builder(
                    itemCount: folders?.length ?? 0,
                    itemBuilder: (context, index) {
                      final folder = folders![index];
                      return FolderList(
                        folderName: folder['folderName'],
                        folderId: folder.id,
                        userId: userId,
                      );
                    },
                  );
                },
              ),
            ),
            // Add Folder Button
            Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton.icon(
                  onPressed: () {
                    // Show dialog to enter folder name
                    showDialog(
                      context: context,
                      builder: (context) {
                        return MyDialogBox(
                          title: 'Create Folder',
                          icon: Icons.folder,
                          content: TextField(
                            controller: _folderNameController,
                            decoration: const InputDecoration(
                              labelText: 'Folder Name',
                              icon: Icon(Icons.folder),
                            ),
                          ),
                          buttons: [
                            MyButton(
                              buttonTitle: 'Cancel',
                              onTap: () => Navigator.of(context).pop(),
                              color: Colors.grey,
                            ),
                            MyButton(
                              buttonTitle: 'Create',
                              onTap: () {
                                Navigator.of(context).pop(); // Close the dialog
                                _createFolder(); // Call the method to create the folder
                              },
                              color: Colors.green,
                            ),
                          ],
                        );
                      },
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white, // White background
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(12), // Rounded corners
                      side: const BorderSide(
                          color: Color.fromARGB(
                              255, 155, 202, 240)), // Grey outline
                    ),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 12), // Padding for button
                  ),
                  icon: Container(
                    width: 20, // Width of the circle
                    height: 20, // Height of the circle
                    decoration: BoxDecoration(
                      color: Colors.white, // White fill
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.blue, // Blue outline
                        width: 2.0, // Outline width
                      ),
                    ),
                    child: const Icon(
                      Icons.add,
                      color: Colors.blue, // Icon color
                      size: 16, // Icon size
                    ),
                  ),
                  label: const Text(
                    'Add Folder',
                    style: TextStyle(
                        color:
                            Color.fromARGB(255, 155, 202, 240)), // Text color
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
