import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/features/notes/presentation/create_note.dart';
import 'package:studyapp_2024/features/notes/presentation/generate_question.dart';
import 'package:studyapp_2024/features/notes/presentation/notes_details.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';

class NotesInFolderPage extends StatefulWidget {
  final String folderId;
  final String folderName; // Include folderName as a required field

  const NotesInFolderPage({
    super.key,
    required this.folderId,
    required this.folderName, // Pass folderName from the constructor
  });

  @override
  _NotesInFolderPageState createState() => _NotesInFolderPageState();
}

class _NotesInFolderPageState extends State<NotesInFolderPage> {
  String _searchQuery = '';
  bool _isAscending = true;
  String? userId; // Store the user ID

  @override
  void initState() {
    super.initState();
    _getUserId(); // Get the user ID
  }

  // Function to get the current user's ID
  Future<void> _getUserId() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        userId = user.uid; // Store the user ID
      });
    }
  }

  Stream<QuerySnapshot> _getNotes() {
    if (userId == null) {
      return const Stream.empty();
    }

    return FirebaseFirestore.instance
        .collection('users')
        .doc(userId) // Use userId here
        .collection('folders')
        .doc(widget.folderId)
        .collection('notes')
        .orderBy('createdAt', descending: !_isAscending)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(
        title: Text(
          widget.folderName.isEmpty ? 'Loading...' : widget.folderName,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.explore, color: Colors.black),
            onPressed: () {
              Navigator.pushNamed(context, RouteManager.exploreNotes);
            },
          ),
          IconButton(
            icon:
                Icon(_isAscending ? Icons.arrow_downward : Icons.arrow_upward),
            onPressed: () {
              setState(() {
                _isAscending = !_isAscending;
              });
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 30.0),
        child: Column(
          children: [
            // Search Bar
            TextField(
              decoration: const InputDecoration(
                labelText: 'Search Notes',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
            const SizedBox(height: 20),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: _getNotes(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return const Center(child: Text('Error loading notes'));
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text('No notes available'));
                  }

                  var notes = snapshot.data!.docs;

                  // Filter notes based on the search query
                  var filteredNotes = notes.where((note) {
                    var noteData = note.data() as Map<String, dynamic>?;
                    var noteTitle =
                        noteData?['title']?.toString().toLowerCase() ?? '';
                    return noteTitle.contains(_searchQuery.toLowerCase());
                  }).toList();

                  return ListView.builder(
                    itemCount: filteredNotes.length,
                    itemBuilder: (context, index) {
                      var note = filteredNotes[index];
                      var createdAt =
                          (note['createdAt'] as Timestamp?)?.toDate() ??
                              DateTime.now();
                      var lastModified =
                          (note['modifiedAt'] as Timestamp?)?.toDate() ??
                              DateTime.now();

                      return GestureDetector(
                        onTap: () {
                          if (note.id.isNotEmpty) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => NoteDetailPage(
                                  noteId: note.id,
                                  folderId: widget.folderId,
                                  userId: userId!, // Pass the userId here
                                ),
                              ),
                            );
                          } else {
                            // Handle case where note.id is null
                            print("Error: Note ID is null");
                          }
                        },
                        child: NoteList(
                          noteTitle: note['title'] ?? 'Untitled',
                          createdAt: createdAt,
                          lastModified: lastModified,
                          noteId: note.id,
                          folderId: widget.folderId,
                          userId: userId!, // Pass the userId here
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (userId != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CreateNotePage(
                  folderId: widget.folderId,
                  folderName: widget.folderName,
                  userId: userId!, // Pass the userId here
                  noteId: '', // Add this line
                ),
              ),
            );
          } else {
            // Optionally show a message if userId is null
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content:
                    Text('Unable to create a note, user not authenticated'),
              ),
            );
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

class NoteList extends StatefulWidget {
  final String noteTitle;
  final DateTime createdAt;
  final DateTime lastModified;
  final String noteId;
  final String folderId;
  final String userId; // Add userId

  const NoteList({
    required this.noteTitle,
    required this.createdAt,
    required this.lastModified,
    required this.noteId,
    required this.folderId,
    required this.userId, // Include userId here
    super.key,
  });

  @override
  _NoteListState createState() => _NoteListState();
}

class _NoteListState extends State<NoteList> {
  late TextEditingController contentController;

  @override
  void initState() {
    super.initState();
    // Initialize the controller with empty text or retrieve note content if needed
    contentController = TextEditingController();
    _loadNoteContent(); // Load existing note content
  }

  Future<void> _loadNoteContent() async {
    // Optionally load the content from Firestore
    var noteDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection('folders')
        .doc(widget.folderId)
        .collection('notes')
        .doc(widget.noteId)
        .get();

    if (noteDoc.exists) {
      setState(() {
        contentController.text = noteDoc['content'] ??
            'no content available'; // Assuming the content field exists
      });
    }
  }

  @override
  void dispose() {
    contentController.dispose(); // Dispose the controller when done
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0), // Space between cards
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8), // Rounded corners for cards
      ),
      child: ListTile(
        contentPadding: EdgeInsets.zero, // Padding around the content
        leading: Container(
          width: 60,
          height: 70,
          color: const Color.fromARGB(255, 239, 234, 185),
          child: const Center(
            child: Icon(
              Icons.note,
              color: Colors.black,
              size: 30,
            ),
          ),
        ),
        title: Text(widget.noteTitle),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Blue background only for created date
            Container(
              padding: const EdgeInsets.all(8.0),
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 130, 192, 242),
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Text(
                'Created: ${_formatDate(widget.createdAt)}',
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(
                height:
                    4.0), // Space between blue rectangle and last modified text
            Text(
              'Last modified: ${_formatDate(widget.lastModified)}',
            ),
          ],
        ),
        trailing: PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert),
          onSelected: (value) {
            if (value == 'edit') {
              // Handle edit action
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CreateNotePage(
                    folderId: widget.folderId,
                    folderName: 'Edit Note',
                    userId: widget.userId, // Pass the userId here
                    noteId: widget.noteId,
                  ),
                ),
              );
            } else if (value == 'delete') {
              // Handle delete action
              _deleteNote(widget.noteId, widget.userId);
            } else if (value == 'generateQuestion') {
              // Handle generate question action
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => GenerateQuestionPage(
                    folderId: widget.folderId,
                    userId: widget.userId, // Pass the userId here
                    noteId: widget.noteId,
                  ),
                ),
              );
            }
          },
          itemBuilder: (BuildContext context) {
            return [
              const PopupMenuItem(value: 'edit', child: Text('Edit')),
              const PopupMenuItem(value: 'delete', child: Text('Delete')),
              const PopupMenuItem(
                  value: 'generateQuestion',
                  child: Text('Generate Question')), // New button
            ];
          },
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _deleteNote(String noteId, String userId) async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('folders')
        .doc(widget.folderId)
        .collection('notes')
        .doc(noteId)
        .delete();
  }
}
