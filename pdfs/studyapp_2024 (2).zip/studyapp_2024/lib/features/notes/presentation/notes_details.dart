import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NoteDetailPage extends StatefulWidget {
  final String folderId;
  final String noteId;
  final String userId; // Added userId

  const NoteDetailPage({
    super.key,
    required this.folderId,
    required this.noteId,
    required this.userId, // Ensure userId is required
  });

  @override
  _NoteDetailPageState createState() => _NoteDetailPageState();
}

class _NoteDetailPageState extends State<NoteDetailPage> {
  final List<Color> cardColors = [
    Colors.blue[100]!,
    Colors.yellow[100]!,
    Colors.green[100]!,
    Colors.orange[100]!,
    Colors.pink[100]!,
    Colors.purple[100]!,
    Colors.white,
  ];

  int selectedColorIndex = 0;

  void _changeCardColor() {
    setState(() {
      selectedColorIndex = (selectedColorIndex + 1) % cardColors.length;
    });
  }

  Future<Map<String, dynamic>?> _getNoteDetails() async {
    try {
      DocumentSnapshot docSnapshot = await FirebaseFirestore.instance
          .collection('users') // Assuming you are storing notes under users
          .doc(widget.userId) // Query by userId
          .collection('folders')
          .doc(widget.folderId)
          .collection('notes')
          .doc(widget.noteId)
          .get();

      if (docSnapshot.exists) {
        return docSnapshot.data() as Map<String, dynamic>;
      } else {
        return null; // Return null if the note does not exist
      }
    } catch (e) {
      print('Error fetching note details: $e'); // Error logging
      return null; // Handle any errors
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>?>(
        future: _getNoteDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.hasError) {
            return Scaffold(
              body: Center(child: Text('Error: ${snapshot.error}')),
            );
          }

          if (!snapshot.hasData || snapshot.data == null) {
            return const Scaffold(
              body: Center(child: Text('Note not found')),
            );
          }

          var noteData = snapshot.data!;
          String title = noteData['title'] ?? 'Untitled';
          String section = noteData['section'] ?? 'No section';
          String content = noteData['content'] ?? 'No content';

          return Scaffold(
            appBar: AppBar(
              title: Text(title),
              backgroundColor: Colors.lightBlue,
              actions: [
                IconButton(
                  icon: CircleAvatar(
                    backgroundColor: cardColors[selectedColorIndex],
                  ),
                  onPressed: _changeCardColor,
                ),
              ],
            ),
            backgroundColor: Colors.grey[200],
            body: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width - 20,
                    child: Card(
                      color: cardColors[selectedColorIndex],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16.0),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              section,
                              style: const TextStyle(
                                fontSize: 20.0,
                                fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 16.0),
                            Text(
                              content,
                              style: const TextStyle(
                                fontSize: 16.0,
                                color: Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
