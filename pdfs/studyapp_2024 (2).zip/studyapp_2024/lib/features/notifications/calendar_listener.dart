import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:awesome_notifications/awesome_notifications.dart';

class CalendarListener {
  static final CalendarListener _instance = CalendarListener._internal();

  factory CalendarListener() => _instance;
  CalendarListener._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final Set<String> _sentNotifications = {};

  void startListening() {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    // Start listening to calendar events for reminders
    _listenToCalendarReminders(user.uid);
  }

  void _listenToCalendarReminders(String userId) {
    _firestore
        .collection('users')
        .doc(userId)
        .collection('calendarEvents')
        .snapshots()
        .listen((eventSnapshot) {
      for (var eventDoc in eventSnapshot.docs) {
        final eventData = eventDoc.data();
        final eventId = eventDoc.id;

        // Check if reminders are enabled and notification has not been sent yet
        if (!eventData['Reminder Enabled'] ||
            _sentNotifications.contains(eventId)) {
          continue;
        }

        // Get the Reminder Time
        DateTime reminderTime =
            (eventData['Reminder Time'] as Timestamp).toDate();

        // Check if the current time is after the Reminder Time
        if (DateTime.now().isBefore(reminderTime)) {
          // Add eventId to sent notifications to prevent duplicate notifications
          _sentNotifications.add(eventId);

          // Create notification
          AwesomeNotifications().createNotification(
            content: NotificationContent(
              id: eventId.hashCode,
              channelKey: 'calendar_reminders',
              title: eventData['Title'] ?? 'Event Reminder',
              body: eventData['Description'] ?? 'You have an upcoming event',
              payload: {'eventId': eventId},
            ),
          );
        } else {
          if (_sentNotifications.contains(eventId)) {
            _sentNotifications.remove(eventId);
          }
        }
      }
    });
  }
}
