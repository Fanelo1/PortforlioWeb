// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: BackgroundMessageListener CLASS (220024654, LK Maasdorp)
// PURPOSE: This class is responsible for listening for any changes in the application, to trigger a notification

import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:awesome_notifications/awesome_notifications.dart';

class ChatListener {
  static final ChatListener _instance = ChatListener._internal();

  factory ChatListener() => _instance;
  ChatListener._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool _isInChat = false;
  final Map<String, StreamSubscription<QuerySnapshot>> _messageListeners = {};
  final Set<String> _sentNotifications = {};
  final Set<String> _processingMessages = {};

  void startListening() {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    // Prevent re-adding listeners
    if (_messageListeners.isNotEmpty) return;

    _firestore.collection('groupChats').snapshots().listen((groupSnapshot) {
      for (var groupDoc in groupSnapshot.docs) {
        final groupId = groupDoc.id;
        List<dynamic> groupMembers = groupDoc['Group Members'] ?? [];
        bool isUserInGroup =
            groupMembers.any((member) => member['userId'] == user.uid);

        if (isUserInGroup && !_messageListeners.containsKey(groupId)) {
          _listenToGroupMessages(groupId, groupDoc);
        }
      }
    });
  }

  void _listenToGroupMessages(String groupId, DocumentSnapshot groupDoc) {
    // Ensure only one listener is attached to each group chat
    stopListeningToGroup(groupId);

    StreamSubscription<QuerySnapshot> messageListener = _firestore
        .collection('groupChats')
        .doc(groupId)
        .collection('groupMessages')
        .snapshots()
        .listen((messageSnapshot) async {
      for (var messageDoc in messageSnapshot.docs) {
        final messageData = messageDoc.data();
        final notificationKey = '${groupId}_${messageDoc.id}';

        // Skip if the message is being processed or if already notified
        if (_processingMessages.contains(notificationKey) ||
            _sentNotifications.contains(notificationKey)) {
          continue;
        }

        if (_isInChat ||
            messageData['User ID'] == FirebaseAuth.instance.currentUser!.uid ||
            (messageData['notificationTriggered'] ?? false)) {
          continue;
        }

        // Mark message as processing to avoid duplicates
        _processingMessages.add(notificationKey);

        List<dynamic> readBy = messageData['ReadBy'] ?? [];
        if (!readBy.contains(FirebaseAuth.instance.currentUser!.uid)) {
          await Future.delayed(const Duration(milliseconds: 600));
          final updatedMessageDoc = await _firestore
              .collection('groupChats')
              .doc(groupId)
              .collection('groupMessages')
              .doc(messageDoc.id)
              .get();

          if (!(updatedMessageDoc.data()?['notificationTriggered'] ?? false)) {
            _sentNotifications.add(notificationKey);
            await _markNotificationAsTriggered(
                groupId, messageDoc.id, groupDoc, messageData);
          }
        }

        // Remove message from processing set after completion
        _processingMessages.remove(notificationKey);
      }
    });

    _messageListeners[groupId] = messageListener;
  }

  Future<void> _markNotificationAsTriggered(
    String groupId,
    String messageId,
    DocumentSnapshot groupDoc,
    Map<String, dynamic> messageData,
  ) async {
    await _firestore
        .collection('groupChats')
        .doc(groupId)
        .collection('groupMessages')
        .doc(messageId)
        .update({'notificationTriggered': true}).then((_) {
      print('Notification triggered for message: $messageId');
      _triggerGroupMessageNotification(
        groupId: groupId,
        groupName: groupDoc['Group Name'],
        senderName: messageData['Sender Name'],
        message: messageData['Message'] ?? 'You have a new message!',
        messageId: messageId,
      );
    }).catchError((error) {
      print("Failed to mark notification as triggered: $error");
    });
  }

  void _triggerGroupMessageNotification({
    required String groupId,
    required String groupName,
    required String senderName,
    required String message,
    required String messageId,
  }) async {
    await AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: createUniqueId(),
        channelKey: 'chat_messages',
        title: '$senderName in $groupName sent a message',
        body: message,
        payload: {'groupId': groupId, 'messageId': messageId},
      ),
    );
    print('Notification sent for group $groupId, message: $message');
  }

  void stopListeningToGroup(String groupId) {
    _messageListeners[groupId]?.cancel();
    _messageListeners.remove(groupId);
    print('Stopped listening to group: $groupId');
  }

  void stopAllListeners() {
    for (var subscription in _messageListeners.values) {
      subscription.cancel();
    }
    _messageListeners.clear();
    print('Stopped all message listeners.');
  }

  void updateChatStatus(bool isInChat) {
    _isInChat = isInChat;
    print('Chat status updated: $_isInChat');
  }

  int createUniqueId() {
    return DateTime.now().millisecondsSinceEpoch.remainder(100000);
  }
}
