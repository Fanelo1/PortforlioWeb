import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/features/calendar/data/calendar_service.dart';

class CalendarRepo {
  final CalendarService _calendarService;

  CalendarRepo(this._calendarService);

//========== CALENDAR: CRUD OPERATIONS ==========//

  //CREATE
  Future<DocumentReference> addEvent({
    required String title,
    required String description,
    required DateTime time,
    required bool reminderEnabled,
    required int remindBeforeMinutes,
  }) async {
    return await _calendarService.addEvent(
      title,
      description,
      time,
      reminderEnabled,
      remindBeforeMinutes,
    );
  }

  //UPDATE
  Future<void> updateEvent({
    required String eventId,
    required String title,
    required String description,
    required DateTime time,
    required bool reminderEnabled,
    required int remindBeforeMinutes,
    required bool isComplete,
  }) async {
    await _calendarService.updateEvent(
      eventId,
      title,
      description,
      time,
      reminderEnabled,
      remindBeforeMinutes,
      isComplete,
    );
  }

  //DELETE
  Future<void> deleteEvent(String eventId) async {
    await _calendarService.deleteEvent(eventId);
  }

  //READ (ALL EVENTS OF DAY)
  Future<List<Map<String, dynamic>>> fetchEventsForDay(
      DateTime selectedDay) async {
    return await _calendarService.fetchEventsForDay(selectedDay);
  }
}
