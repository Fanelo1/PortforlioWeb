import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CalendarService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  //----- METHOD TO CREATE CALENDAR EVENT -----//
  Future<DocumentReference> addEvent(String title, String description,
      DateTime time, bool reminderEnabled, int remindBeforeMinutes) async {
    final user = _auth.currentUser;

    if (user != null) {
      final eventsRef = _firestore
          .collection('users')
          .doc(user.uid)
          .collection('calendarEvents');

      // Calculate Reminder Time
      DateTime reminderTime =
          time.subtract(Duration(minutes: remindBeforeMinutes));

      return await eventsRef.add({
        'Title': title,
        'Description': description,
        'Time': time,
        'Reminder Time': reminderTime, // New field for Reminder Time
        'Reminder Enabled': reminderEnabled,
        'Remind Before': remindBeforeMinutes,
        'Is Complete': false,
        'Created At': FieldValue.serverTimestamp(),
      });
    }

    throw FirebaseAuthException(
        code: 'user-not-logged-in', message: 'User must be logged in.');
  }

  //----- METHOD TO UPDATE CALENDAR EVENT -----//
  Future<void> updateEvent(
      String eventId,
      String title,
      String description,
      DateTime time,
      bool reminderEnabled,
      int remindBeforeMinutes,
      bool isComplete) async {
    final user = _auth.currentUser;

    if (user != null) {
      final eventRef = _firestore
          .collection('users')
          .doc(user.uid)
          .collection('calendarEvents')
          .doc(eventId);

      // Calculate Reminder Time
      DateTime reminderTime =
          time.subtract(Duration(minutes: remindBeforeMinutes));

      await eventRef.update({
        'Title': title,
        'Description': description,
        'Time': time,
        'Reminder Time': reminderTime, // Update Reminder Time
        'Reminder Enabled': reminderEnabled,
        'Remind Before': remindBeforeMinutes,
        'Is Complete': isComplete, // Update completion status
      });
    }
  }

  //----- METHOD TO DELETE CALENDAR EVENT -----//
  Future<void> deleteEvent(String eventId) async {
    final user = _auth.currentUser;

    if (user != null) {
      final eventRef = _firestore
          .collection('users')
          .doc(user.uid)
          .collection('calendarEvents')
          .doc(eventId);

      await eventRef.delete();
    }
  }

  //----- METHOD TO RETRIEVE ALL CALENDAR EVENTS FOR THE DAY -----//
  Future<List<Map<String, dynamic>>> fetchEventsForDay(
      DateTime selectedDay) async {
    final user = _auth.currentUser;
    List<Map<String, dynamic>> events = [];

    if (user != null) {
      final eventsRef = _firestore
          .collection('users')
          .doc(user.uid)
          .collection('calendarEvents');

      final snapshot = await eventsRef
          .where('Time', isGreaterThanOrEqualTo: selectedDay)
          .where('Time',
              isLessThanOrEqualTo: selectedDay
                  .add(const Duration(hours: 23, minutes: 59, seconds: 59)))
          .get();

      events = snapshot.docs.map((doc) {
        return {
          'id': doc.id,
          'Title': doc['Title'],
          'Description': doc['Description'],
          'Time': doc['Time'],
          'Reminder Time': doc['Reminder Time'], // Include Reminder Time
          'Is Complete': doc['Is Complete'] ?? false,
          'Reminder Enabled': doc['Reminder Enabled'] ?? false,
          'Remind Before': doc['Remind Before'] ?? 0,
        };
      }).toList();
    }

    return events;
  }
}
