import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class EventDialog extends StatefulWidget {
  final Function(String, String, DateTime, bool, int) onAdd;
  final String? initialTitle;
  final String? initialDescription;
  final DateTime? initialTime;
  final bool initialReminderEnabled;
  final int initialRemindBeforeMinutes;

  const EventDialog({
    required this.onAdd,
    this.initialTitle,
    this.initialDescription,
    this.initialTime,
    this.initialReminderEnabled = false,
    this.initialRemindBeforeMinutes = 5,
    super.key,
  });

  @override
  _EventDialogState createState() => _EventDialogState();
}

class _EventDialogState extends State<EventDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleController;
  late final TextEditingController _descriptionController;
  late DateTime _selectedTime;
  late bool _reminderEnabled;
  late int _remindBeforeMinutes;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.initialTitle);
    _descriptionController =
        TextEditingController(text: widget.initialDescription);
    _selectedTime = widget.initialTime ?? DateTime.now();
    _reminderEnabled = widget.initialReminderEnabled;
    _remindBeforeMinutes = widget.initialRemindBeforeMinutes;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_selectedTime),
    );

    if (pickedTime != null) {
      setState(() {
        _selectedTime = DateTime(
          _selectedTime.year,
          _selectedTime.month,
          _selectedTime.day,
          pickedTime.hour,
          pickedTime.minute,
        );
      });
    }
  }

  String _formatTime(DateTime dateTime) {
    return DateFormat('HH:mm').format(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialTitle == null ? 'Add Event' : 'Edit Event'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Event Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a title';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(labelText: 'Description'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a description';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Text('Time: ${_formatTime(_selectedTime)}'),
                  const Spacer(),
                  TextButton(
                    onPressed: () => _selectTime(context),
                    child: const Text('Select Time'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  const Text('Enable Reminder'),
                  const Spacer(),
                  Switch(
                    value: _reminderEnabled,
                    onChanged: (value) {
                      setState(() {
                        _reminderEnabled = value;
                      });
                    },
                  ),
                ],
              ),
              if (_reminderEnabled)
                Row(
                  children: [
                    const Text('Remind Before:'),
                    const Spacer(),
                    DropdownButton<int>(
                      value: _remindBeforeMinutes,
                      items: const [
                        DropdownMenuItem(value: 5, child: Text('5 minutes')),
                        DropdownMenuItem(value: 5, child: Text('10 minutes')),
                        DropdownMenuItem(value: 5, child: Text('15 minutes')),
                        DropdownMenuItem(value: 15, child: Text('20 minutes')),
                        DropdownMenuItem(value: 5, child: Text('25 minutes')),
                        DropdownMenuItem(value: 30, child: Text('30 minutes')),
                        DropdownMenuItem(value: 60, child: Text('1 hour')),
                      ],
                      onChanged: (value) {
                        setState(() {
                          _remindBeforeMinutes = value ?? 15;
                        });
                      },
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              widget.onAdd(
                _titleController.text,
                _descriptionController.text,
                _selectedTime,
                _reminderEnabled,
                _remindBeforeMinutes,
              );
              Navigator.pop(context);
            }
          },
          child: Text(widget.initialTitle == null ? 'Add' : 'Update'),
        ),
      ],
    );
  }
}
