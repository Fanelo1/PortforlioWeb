import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class EventTile extends StatelessWidget {
  final Map<String, dynamic> event;
  final Function(String, bool) onToggleComplete;
  final Function(String) onDelete;
  final Function(BuildContext) onEdit;

  const EventTile({
    super.key,
    required this.event,
    required this.onToggleComplete,
    required this.onDelete,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
      child: ListTile(
        leading: Checkbox(
          value: event['Is Complete'],
          onChanged: (checked) {
            onToggleComplete(event['id'], event['Is Complete']);
          },
        ),
        title: Text(
          event['Title'],
          style: TextStyle(
            decoration:
                event['Is Complete'] ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Text(
          '${event['Description']}\n${_formatTime(event['Time'].toDate())}',
          style: const TextStyle(fontSize: 14),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, color: Colors.blue),
              onPressed: () => onEdit(context),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => onDelete(event['id']),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    return DateFormat('hh:mm a').format(time);
  }
}
