// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: CalendarHomePage CLASS (220032380, MMC MOKOENA)
// PURPOSE:

import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/features/calendar/data/calendar_service.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/dividers/my_left_divider.dart';
import 'package:table_calendar/table_calendar.dart';

class CalendarHomePage extends StatefulWidget {
  const CalendarHomePage({super.key});

  @override
  _CalendarHomePageState createState() => _CalendarHomePageState();
}

class _CalendarHomePageState extends State<CalendarHomePage> {
  final CalendarService _calendarService = CalendarService();
  late Map<DateTime, List<Map<String, dynamic>>> _events;
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;
    _events = {};

    // Fetch today's events immediately when the page loads
    _fetchEventsForSelectedDay(_selectedDay!);
  }

  List<Map<String, dynamic>> _getEventsForDay(DateTime day) {
    if (isSameDay(day, _focusedDay)) {
      return _events[day] ?? [];
    }
    return _events[day] ?? [];
  }

  String _formatTime(DateTime time) {
    return DateFormat('hh:mm a').format(time);
  }

  // Method to mark event as complete/incomplete
  Future<void> _toggleCompleteStatus(
      String eventId, bool isComplete, DateTime selectedDay) async {
    setState(() {
      _isLoading = true;
    });

    final event = _events[selectedDay]?.firstWhere((e) => e['id'] == eventId);
    if (event != null) {
      await _calendarService.updateEvent(
        eventId,
        event['Title'],
        event['Description'],
        event['Time'].toDate(),
        !isComplete,
        event['ReminderEnabled'],
        event['RemindBeforeMinutes'],
      );
      await _fetchEventsForSelectedDay(selectedDay);
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _addEvent(BuildContext context) async {
    TextEditingController eventController = TextEditingController();
    TextEditingController descriptionController = TextEditingController();
    TimeOfDay? selectedTime = TimeOfDay.now();
    bool reminderEnabled = false;
    int remindBeforeMinutes = 15;
    DateTime? reminderTime; // Add this variable to store the reminder time

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Add Event'),
          content: StatefulBuilder(
            builder: (context, setState) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: eventController,
                      decoration:
                          const InputDecoration(labelText: 'Event Name'),
                    ),
                    TextField(
                      controller: descriptionController,
                      decoration:
                          const InputDecoration(labelText: 'Description'),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Text('Time: ${selectedTime?.format(context) ?? ''}'),
                        const Spacer(),
                        TextButton(
                          onPressed: () async {
                            final TimeOfDay? pickedTime = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (pickedTime != null) {
                              setState(() {
                                selectedTime = pickedTime;
                                // Update reminder time when the time is selected
                                reminderTime = DateTime(
                                  _selectedDay!.year,
                                  _selectedDay!.month,
                                  _selectedDay!.day,
                                  pickedTime.hour,
                                  pickedTime.minute,
                                ).subtract(
                                    Duration(minutes: remindBeforeMinutes));
                              });
                            }
                          },
                          child: const Text('Select Time'),
                        ),
                      ],
                    ),
                    // Show the reminder time

                    // Reminder Toggle
                    Row(
                      children: [
                        const Text('Enable Reminder'),
                        const Spacer(),
                        Switch(
                          value: reminderEnabled,
                          onChanged: (value) {
                            setState(() {
                              reminderEnabled = value;
                              if (!value) {
                                reminderTime = null;
                              } else {
                                reminderTime = DateTime(
                                  _selectedDay!.year,
                                  _selectedDay!.month,
                                  _selectedDay!.day,
                                  selectedTime!.hour,
                                  selectedTime!.minute,
                                ).subtract(
                                    Duration(minutes: remindBeforeMinutes));
                              }
                            });
                          },
                        ),
                      ],
                    ),
                    if (reminderTime != null)
                      Text(
                          'Reminder will notify at: ${_formatTime(reminderTime!)}'),
                    const SizedBox(height: 10),
                    // Reminder Time Picker
                    if (reminderEnabled)
                      Row(
                        children: [
                          const Text('Remind Before:'),
                          const Spacer(),
                          DropdownButton<int>(
                            value: remindBeforeMinutes,
                            items: const [
                              DropdownMenuItem(
                                  value: 5, child: Text('5 minutes')),
                              DropdownMenuItem(
                                  value: 10, child: Text('10 minutes')),
                              DropdownMenuItem(
                                  value: 15, child: Text('15 minutes')),
                              DropdownMenuItem(
                                  value: 10, child: Text('20 minutes')),
                              DropdownMenuItem(
                                  value: 25, child: Text('25 minutes')),
                              DropdownMenuItem(
                                  value: 30, child: Text('30 minutes')),
                              DropdownMenuItem(
                                  value: 60, child: Text('1 hour')),
                            ],
                            onChanged: (value) {
                              setState(() {
                                remindBeforeMinutes = value ?? 5;

                                if (selectedTime != null) {
                                  reminderTime = DateTime(
                                    _selectedDay!.year,
                                    _selectedDay!.month,
                                    _selectedDay!.day,
                                    selectedTime!.hour,
                                    selectedTime!.minute,
                                  ).subtract(
                                      Duration(minutes: remindBeforeMinutes));
                                }
                              });
                            },
                          ),
                        ],
                      ),
                  ],
                ),
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                if (eventController.text.isNotEmpty && selectedTime != null) {
                  final eventTime = DateTime(
                    _selectedDay!.year,
                    _selectedDay!.month,
                    _selectedDay!.day,
                    selectedTime!.hour,
                    selectedTime!.minute,
                  );

                  setState(() {
                    _isLoading = true; // Start loading
                  });

                  // Add event to Firestore
                  await _calendarService.addEvent(
                    eventController.text,
                    descriptionController.text,
                    eventTime,
                    reminderEnabled,
                    remindBeforeMinutes,
                  );

                  setState(() {
                    _isLoading = false; // Stop loading
                  });

                  await _fetchEventsForSelectedDay(_selectedDay!);
                  if (context.mounted) {
                    Navigator.of(context).pop();
                  }
                }
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _editEvent(
      BuildContext context, Map<String, dynamic> event, String eventId) async {
    TextEditingController eventController =
        TextEditingController(text: event['Title']);
    TextEditingController descriptionController =
        TextEditingController(text: event['Description']);
    TimeOfDay? selectedTime = TimeOfDay.fromDateTime(event['Time'].toDate());
    bool reminderEnabled = event['Reminder Enabled'] ?? false;
    int remindBeforeMinutes = event['Remind Before'] ?? 15;
    bool isComplete = event['Is Complete'] ?? false; // Track completion status
    DateTime? reminderTime;

    if (reminderEnabled) {
      reminderTime = DateTime(
        _selectedDay!.year,
        _selectedDay!.month,
        _selectedDay!.day,
        selectedTime.hour,
        selectedTime.minute,
      ).subtract(Duration(minutes: remindBeforeMinutes));
    }

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Event'),
          content: StatefulBuilder(
            builder: (context, setState) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: eventController,
                      decoration:
                          const InputDecoration(labelText: 'Event Name'),
                    ),
                    TextField(
                      controller: descriptionController,
                      decoration:
                          const InputDecoration(labelText: 'Description'),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Text('Time: ${selectedTime?.format(context) ?? ''}'),
                        const Spacer(),
                        TextButton(
                          onPressed: () async {
                            final TimeOfDay? pickedTime = await showTimePicker(
                              context: context,
                              initialTime: selectedTime!,
                            );
                            if (pickedTime != null) {
                              setState(() {
                                selectedTime = pickedTime;
                                if (reminderEnabled) {
                                  reminderTime = DateTime(
                                    _selectedDay!.year,
                                    _selectedDay!.month,
                                    _selectedDay!.day,
                                    pickedTime.hour,
                                    pickedTime.minute,
                                  ).subtract(
                                      Duration(minutes: remindBeforeMinutes));
                                }
                              });
                            }
                          },
                          child: const Text('Select Time'),
                        ),
                      ],
                    ),
                    if (reminderTime != null)
                      Text(
                          'Reminder will notify at: ${_formatTime(reminderTime!)}'),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Text('Enable Reminder'),
                        const Spacer(),
                        Switch(
                          value: reminderEnabled,
                          onChanged: (value) {
                            setState(() {
                              reminderEnabled = value;
                              if (!value) {
                                reminderTime = null;
                              } else if (selectedTime != null) {
                                reminderTime = DateTime(
                                  _selectedDay!.year,
                                  _selectedDay!.month,
                                  _selectedDay!.day,
                                  selectedTime!.hour,
                                  selectedTime!.minute,
                                ).subtract(
                                    Duration(minutes: remindBeforeMinutes));
                              }
                            });
                          },
                        ),
                      ],
                    ),
                    if (reminderEnabled)
                      Row(
                        children: [
                          const Text('Remind Before:'),
                          const Spacer(),
                          DropdownButton<int>(
                            value: remindBeforeMinutes,
                            items: const [
                              DropdownMenuItem(
                                  value: 5, child: Text('5 minutes')),
                              DropdownMenuItem(
                                  value: 10, child: Text('10 minutes')),
                              DropdownMenuItem(
                                  value: 15, child: Text('15 minutes')),
                              DropdownMenuItem(
                                  value: 30, child: Text('30 minutes')),
                              DropdownMenuItem(
                                  value: 60, child: Text('1 hour')),
                            ],
                            onChanged: (value) {
                              setState(() {
                                remindBeforeMinutes = value ?? 5;
                                if (selectedTime != null) {
                                  reminderTime = DateTime(
                                    _selectedDay!.year,
                                    _selectedDay!.month,
                                    _selectedDay!.day,
                                    selectedTime!.hour,
                                    selectedTime!.minute,
                                  ).subtract(
                                      Duration(minutes: remindBeforeMinutes));
                                }
                              });
                            },
                          ),
                        ],
                      ),
                    Row(
                      children: [
                        const Text('Mark as Complete'),
                        const Spacer(),
                        Checkbox(
                          value: isComplete,
                          onChanged: (value) {
                            setState(() {
                              isComplete = value ?? false;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                if (eventController.text.isNotEmpty && selectedTime != null) {
                  final eventTime = DateTime(
                    _selectedDay!.year,
                    _selectedDay!.month,
                    _selectedDay!.day,
                    selectedTime!.hour,
                    selectedTime!.minute,
                  );

                  setState(() {
                    _isLoading = true; // Start loading
                  });

                  await _calendarService.updateEvent(
                    eventId,
                    eventController.text,
                    descriptionController.text,
                    eventTime,
                    reminderEnabled,
                    remindBeforeMinutes,
                    isComplete, // Pass the updated isComplete value
                  );

                  setState(() {
                    _isLoading = false; // Stop loading
                  });

                  await _fetchEventsForSelectedDay(_selectedDay!);
                  if (context.mounted) {
                    Navigator.of(context).pop();
                  }
                }
              },
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteEvent(
      String eventId, DateTime selectedDay, int index) async {
    setState(() {
      _isLoading = true; // Start loading
    });

    await _calendarService.deleteEvent(eventId);

    setState(() {
      _isLoading = false; // Stop loading
      _events[selectedDay]?.removeAt(index);
      if (_events[selectedDay]?.isEmpty ?? true) {
        _events.remove(selectedDay);
      }
    });
  }

  Future<void> _fetchEventsForSelectedDay(DateTime selectedDay) async {
    setState(() {
      _isLoading = true; // Start loading before fetching
    });

    final events = await _calendarService.fetchEventsForDay(selectedDay);

    setState(() {
      _events[selectedDay] = events;
      _isLoading = false; // Stop loading after fetching
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(
        title: const Text('Calendar'),
        onLeadingIconPressed: () {
          Navigator.pushNamed(context, RouteManager.studMainPage);
        },
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            _buildCalendar(),
            const SizedBox(height: 8),
            const MyLeftDivider(dividerText: 'My Tasks', fontSize: 18),
            const SizedBox(height: 8),
            _isLoading
                ? const CircularProgressIndicator()
                : Expanded(
                    child: _selectedDay != null &&
                            _getEventsForDay(_selectedDay!).isNotEmpty
                        ? ListView.builder(
                            itemCount: _getEventsForDay(_selectedDay!).length,
                            itemBuilder: (context, index) {
                              final event =
                                  _getEventsForDay(_selectedDay!)[index];
                              return Card(
                                margin: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 4.0),
                                child: ListTile(
                                  leading: Checkbox(
                                    value: event['Is Complete'],
                                    onChanged: (checked) {
                                      _toggleCompleteStatus(event['id'],
                                          event['Is Complete'], _selectedDay!);
                                    },
                                  ),
                                  title: Text(
                                    event['Title'],
                                    style: TextStyle(
                                      decoration: event['Is Complete']
                                          ? TextDecoration.lineThrough
                                          : null,
                                    ),
                                  ),
                                  subtitle: Text(
                                    '${event['Description']}\n${_formatTime(event['Time'].toDate())}',
                                    style: const TextStyle(fontSize: 14),
                                  ),
                                  trailing: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: const Icon(Icons.edit,
                                            color: Colors.blue),
                                        onPressed: () => _editEvent(
                                          context,
                                          event,
                                          event['id'],
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(
                                          Icons.delete,
                                          color: Colors.red,
                                        ),
                                        onPressed: () => _deleteEvent(
                                          event['id'],
                                          _selectedDay!,
                                          index,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          )
                        : const Text('No events for this day.'),
                  ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addEvent(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  TableCalendar _buildCalendar() {
    return TableCalendar(
      firstDay: DateTime(2020),
      lastDay: DateTime(2030),
      focusedDay: _focusedDay,
      selectedDayPredicate: (day) {
        return isSameDay(_selectedDay, day);
      },
      onDaySelected: (selectedDay, focusedDay) {
        setState(() {
          _selectedDay = selectedDay;
          _focusedDay = focusedDay;
        });
        _fetchEventsForSelectedDay(selectedDay);
      },
      calendarFormat: _calendarFormat,
      onFormatChanged: (format) {
        setState(() {
          _calendarFormat = format;
        });
      },
      onPageChanged: (focusedDay) {
        _focusedDay = focusedDay;
      },
      eventLoader: _getEventsForDay, // Load events for the current day
    );
  }
}
