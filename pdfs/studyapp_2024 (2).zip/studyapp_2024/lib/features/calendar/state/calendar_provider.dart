import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/features/calendar/data/calendar_repo.dart';
import 'package:studyapp_2024/features/calendar/data/calendar_service.dart';
import 'package:studyapp_2024/features/calendar/state/calendar_state.dart';
import 'package:studyapp_2024/features/calendar/state/calendar_state_notifier.dart';

final calendarServiceProvider = Provider<CalendarService>((ref) {
  return CalendarService();
});

// CalendarRepo provider
final calendarRepoProvider = Provider<CalendarRepo>((ref) {
  final calendarService = ref.read(calendarServiceProvider);
  return CalendarRepo(calendarService);
});

// CalendarNotifier provider
final calendarNotifierProvider =
    StateNotifierProvider<CalendarStateNotifier, CalendarState>((ref) {
  final calendarRepo = ref.watch(calendarRepoProvider);
  return CalendarStateNotifier(calendarRepo);
});
