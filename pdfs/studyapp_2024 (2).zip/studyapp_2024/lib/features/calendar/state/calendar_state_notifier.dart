import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/features/calendar/data/calendar_repo.dart';
import 'package:studyapp_2024/features/calendar/state/calendar_state.dart';

class CalendarStateNotifier extends StateNotifier<CalendarState> {
  final CalendarRepo calendarRepo;

  CalendarStateNotifier(this.calendarRepo) : super(CalendarState());

//========== CALENDAR STATE ==========//

  //READ STATE (ALL EVENTS FOR DAY)
  Future<void> fetchEventsForDay(DateTime selectedDay) async {
    state = state.copyWith(isLoading: true);
    try {
      final events = await calendarRepo.fetchEventsForDay(selectedDay);
      state = state.copyWith(events: events, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  //CREATE STATE
  Future<void> addEvent({
    required String title,
    required String description,
    required DateTime time,
    required bool reminderEnabled,
    required int remindBeforeMinutes,
  }) async {
    state = state.copyWith(isLoading: true);
    try {
      await calendarRepo.addEvent(
        title: title,
        description: description,
        time: time,
        reminderEnabled: reminderEnabled,
        remindBeforeMinutes: remindBeforeMinutes,
      );
      await fetchEventsForDay(time);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //UPDATE STATE
  Future<void> updateEvent({
    required String eventId,
    required String title,
    required String description,
    required DateTime time,
    required bool reminderEnabled,
    required int remindBeforeMinutes,
    required bool isComplete,
  }) async {
    state = state.copyWith(isLoading: true);
    try {
      await calendarRepo.updateEvent(
        eventId: eventId,
        title: title,
        description: description,
        time: time,
        reminderEnabled: reminderEnabled,
        remindBeforeMinutes: remindBeforeMinutes,
        isComplete: isComplete,
      );
      await fetchEventsForDay(time);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //DELETE STATE
  Future<void> deleteEvent(String eventId, DateTime eventDay) async {
    state = state.copyWith(isLoading: true);
    try {
      await calendarRepo.deleteEvent(eventId);
      await fetchEventsForDay(eventDay);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }
} //END OF CalendarStateNotifier CLASS
