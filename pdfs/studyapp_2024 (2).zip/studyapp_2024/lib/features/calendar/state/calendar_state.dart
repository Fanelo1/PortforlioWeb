class CalendarState {
  final List<Map<String, dynamic>>? events;
  final bool isLoading;
  final String? error;
  final bool reminderPermissionGranted;

  CalendarState({
    this.events,
    this.isLoading = false,
    this.error,
    this.reminderPermissionGranted = false,
  });

  CalendarState copyWith({
    List<Map<String, dynamic>>? events,
    bool? isLoading,
    String? error,
    bool? reminderPermissionGranted,
  }) {
    return CalendarState(
      events: events ?? this.events,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      reminderPermissionGranted:
          reminderPermissionGranted ?? this.reminderPermissionGranted,
    );
  }
}
