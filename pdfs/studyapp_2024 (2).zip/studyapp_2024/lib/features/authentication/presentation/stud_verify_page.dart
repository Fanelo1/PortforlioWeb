// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: EmailVerifyPage CLASS (220024654_LK Maasdorp)
// PURPOSE: This class is responsible for handling the verfication of the user's email address, before logging into the app

import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:lottie/lottie.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/components/my_snackbar.dart';
import 'package:studyapp_2024/features/authentication/state/auth_provider.dart';

class EmailVerifyPage extends ConsumerStatefulWidget {
  final String email;

  const EmailVerifyPage({super.key, required this.email});

  @override
  ConsumerState<EmailVerifyPage> createState() => _EmailVerifyPageState();
}

class _EmailVerifyPageState extends ConsumerState<EmailVerifyPage> {
  //----- TEXTEDITINGCONTROLLER -----//
  final TextEditingController _emailController = TextEditingController();

  Timer? _emailCheckTimer;

  @override
  void initState() {
    super.initState();
    _emailController.text =
        widget.email; // Populate the email field with the user's email
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(authNotifierProvider.notifier).checkUserEmail();
    });
  }

  @override
  void dispose() {
    _emailCheckTimer?.cancel();
    super.dispose();
  }

  Future<bool> _onWillPop() async {
    final result = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Cancel Account Creation'),
              content: const Text(
                'Going back will undo creating your account. Are you sure you want to proceed? \nThis action cannot be undone.',
                textAlign: TextAlign.center,
              ),
              actions: <Widget>[
                TextButton(
                  child: const Text('Cancel'),
                  onPressed: () => Navigator.of(context).pop(false),
                ),
                TextButton(
                  child: const Text('Proceed'),
                  onPressed: () async {
                    Navigator.of(context).pop(true);
                    await ref
                        .read(authNotifierProvider.notifier)
                        .deleteUserData();
                    if (context.mounted) {
                      Navigator.of(context)
                          .pushReplacementNamed(RouteManager.studLogPage);
                    }
                  },
                ),
              ],
            );
          },
        ) ??
        false;
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);

    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var paddingHorizontal = screenWidth * 0.05;
    var paddingVertical = screenHeight * 0.03;
    var fontSizeTitle = screenWidth * 0.047;
    var fontSize = screenWidth * 0.045;
    var lottieHeight = screenHeight * 0.35;
    var lottieWidth = screenWidth * 0.8;

    return WillPopScope(
      onWillPop: () async => _onWillPop(),
      child: Scaffold(
        appBar: MyAppBar(
          title: Text(
            'Verifying Account',
            style: TextStyle(fontSize: fontSizeTitle),
          ),
          onBackButtonPressed: _onWillPop,
        ),
        body: SafeArea(
          child: Stack(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: paddingHorizontal,
                  vertical: paddingVertical,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: lottieHeight,
                      width: lottieWidth,
                      child: Lottie.asset(
                        'assets/animations/VerifyEmail.json',
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 30),
                    if (!authState.isEmailVerified)
                      //----- HEADING 1 -----//
                      Text(
                        'First verify your account to proceed.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: fontSizeTitle,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                    const SizedBox(height: 15),

                    //----- HEADING 2 -----//
                    Text(
                      'A verification email will be sent to this email address.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: fontSize),
                    ),
                    const SizedBox(height: 20),

                    //----- EMAIL TEXTFORMFIELD -----//
                    TextFormField(
                      controller: _emailController,
                      decoration: formDecoration('Email Address', Icons.mail),
                      style: TextStyle(fontSize: fontSize * 0.8),
                      readOnly: true,
                    ),
                    const SizedBox(height: 20),

                    //----- SEND VERIFICATION EMAIL BUTTON -----//
                    MyButton(
                      buttonTitle: authState.isSendingVerification
                          ? 'Sending...'
                          : 'Resend Verification Email',
                      buttonType: ButtonType.bordered,
                      onTap: authState.isSendingVerification
                          ? null
                          : () => ref
                              .read(authNotifierProvider.notifier)
                              .sendVerifyEmail(),
                      color: Colors.green,
                    ),

                    const SizedBox(height: 20),

                    //----- CHECK VERIFICATION BUTTON -----//
                    MyButton(
                      buttonTitle: 'Check Verification Status',
                      buttonType: ButtonType.filled,
                      onTap: () async {
                        showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (BuildContext context) {
                            return const MyDialogBox(
                              content: Text(
                                'Verifying',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green,
                                ),
                              ),
                              showProgressIndicator: true,
                              iconColor: Colors.green,
                              hideCloseButton: true,
                            );
                          },
                        );
                        try {
                          await ref
                              .read(authNotifierProvider.notifier)
                              .checkUserEmail();
                          final updatedState = ref.read(authNotifierProvider);

                          if (context.mounted) {
                            Navigator.of(context).pop();
                          }
                          if (updatedState.isEmailVerified) {
                            if (context.mounted) {
                              Navigator.pushReplacementNamed(
                                  context, RouteManager.studMainPage);
                            }
                          } else {
                            if (context.mounted) {
                              //----- NOT VERIFIED DIALOGBOX -----//
                              showDialog(
                                context: context,
                                barrierDismissible: false,
                                builder: (BuildContext context) {
                                  return const MyDialogBox(
                                    content: Text(
                                      'Email Address not verified!',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red,
                                      ),
                                    ),
                                    icon: CupertinoIcons.exclamationmark_circle,
                                    iconColor: Colors.red,
                                    hideCloseButton: false,
                                  );
                                },
                              );
                            }
                          }
                        } catch (e) {
                          if (context.mounted) {
                            Navigator.of(context).pop();
                            MySnackbar(
                              message: 'Error checking email verification: $e',
                            ).showSnackBar(context);
                          }
                        }
                      },
                      color: Colors.blue,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
