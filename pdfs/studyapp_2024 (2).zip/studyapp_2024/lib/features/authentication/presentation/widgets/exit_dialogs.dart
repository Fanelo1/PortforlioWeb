import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';

class ExitDialog extends StatelessWidget {
  final Color? borderColor;
  final double borderWidth;
  final String title;
  final String content;

  const ExitDialog({
    this.borderColor,
    this.borderWidth = 2.0,
    super.key,
    required this.title,
    required this.content,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double titleFontSize = screenWidth * 0.06;
    double contentFontSize = screenWidth * 0.04;
    double titleHorizontalPadding = screenWidth * 0.05;

    return Center(
      child: AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
            color: Colors.red,
            width: borderWidth,
          ),
        ),
        title: Stack(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(
                horizontal: titleHorizontalPadding,
              ),
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: titleFontSize,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        content: Text(
          content,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: contentFontSize,
          ),
        ),
        actions: <Widget>[
          Row(
            children: [
              Expanded(
                child: MyButton(
                  buttonTitle: 'No',
                  onTap: () {
                    Navigator.of(context).pop(false);
                  },
                  buttonType: ButtonType.bordered,
                  color: Colors.blue,
                  icon: CupertinoIcons.xmark,
                ),
              ),
              const SizedBox(
                width: 8,
              ),
              Expanded(
                child: MyButton(
                  onTap: () {
                    FirebaseAuth.instance.signOut();
                    Navigator.of(context).pop(true);
                    Navigator.of(context)
                        .pushReplacementNamed(RouteManager.studLogPage);
                  },
                  buttonTitle: 'Yes',
                  color: Colors.red,
                  icon: CupertinoIcons.checkmark_alt,
                  buttonType: ButtonType.filled,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
} //END OF ExitDialog CLASS
