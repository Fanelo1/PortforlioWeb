// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: StudLogForm CLASS (220024654 LK MAASDORP)
// PURPOSE: The widget for the student login form

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/features/authentication/state/auth_provider.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dividers/my_divider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/components/form_validations.dart';

class StudLogForm extends ConsumerStatefulWidget {
  const StudLogForm({super.key});

  @override
  ConsumerState<StudLogForm> createState() => _StudLogFormState();
}

class _StudLogFormState extends ConsumerState<StudLogForm> {
  bool _togglePassword = false;

  //----- THE GLOBAL KEY FOR THE STUDENT LOGIN FORM -----//
  final _formKey = GlobalKey<FormState>();

  //----- TEXTEDITINGCONTROLLERS -----//
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);
    return Stack(
      children: [
        Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              //----- EMAIL TEXTFORMFIELD -----//
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                controller: _emailController,
                decoration: formDecoration('Email', Icons.mail),
                validator: validateEmail,
                onChanged: (value) {
                  ref.read(authNotifierProvider.notifier).emailExists(value);
                },
              ),

              const SizedBox(height: 20),

              //----- PASSWORD TEXTFORMFIELD -----//
              TextFormField(
                keyboardType: TextInputType.text,
                controller: _passwordController,
                decoration: formDecoration('Password', Icons.lock,
                    suffixIcon: _togglePassword
                        ? Icons.visibility
                        : Icons.visibility_off, onPressed: () {
                  setState(() {
                    _togglePassword = !_togglePassword;
                  });
                }),
                validator: validatePassword,
                obscureText: !_togglePassword,
                maxLength: 8,
              ),

              //----- FORGOT PASSWORD BUTTON -----//
              if (authState.isEmailInFirestore)
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () async {
                        await ref
                            .read(authNotifierProvider.notifier)
                            .handleForgotPassword(_emailController.text);
                        if (mounted) {
                          if (context.mounted) {
                            Navigator.pushNamed(
                              context,
                              RouteManager.passResetPage,
                              arguments: _emailController.text,
                            );
                          }
                        }
                      },
                      child: const Text(
                        'Forgot Password?',
                        style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),

              const SizedBox(height: 20),

              //----- EMAIL & PASSWORD SIGN IN BUTTON -----//
              MyButton(
                buttonTitle: 'Sign In',
                onTap: () async {
                  if (_formKey.currentState!.validate()) {
                    ref
                        .read(authNotifierProvider.notifier)
                        .signUserInEmail(
                          _emailController.text,
                          _passwordController.text,
                        )
                        .then((_) {
                      // Defer navigation until the current frame completes
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (context.mounted) {
                          Navigator.pushNamed(
                              context, RouteManager.studMainPage);
                        }
                      });
                    });
                  }
                },
                color: const Color.fromARGB(255, 119, 167, 206),
              ),

              const SizedBox(height: 20),

              //----- DIVIDER -----//
              const MyDivider(
                dividerText: 'Or Continue With',
              ),

              const SizedBox(height: 20),

              //----- GOOGLE SIGN-IN BUTTON -----//
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: MyButton(
                      buttonTitle: 'Google',
                      onTap: () async {
                        await ref
                            .read(authNotifierProvider.notifier)
                            .signUserInGoogle(context);
                      },
                      fontAwesomeIcon: (FontAwesomeIcons.google),
                      color: const Color.fromRGBO(219, 68, 55, 1),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 40),

              //----- DON'T HAVE AN ACCOUNT SECTION -----//
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "Don't have an account?",
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(width: 4),

                  //----- NAVIGATES TO CREATE STUDENT ACCOUNT -----//
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushNamed(RouteManager.studRegPage);
                    },
                    child: const Text(
                      'Create An Account',
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
} //END OF StudLogForm CLASS
