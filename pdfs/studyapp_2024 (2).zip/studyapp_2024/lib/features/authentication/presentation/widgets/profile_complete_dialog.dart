import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:studyapp_2024/components/my_snackbar.dart';
import 'package:studyapp_2024/components/date_formatter.dart';
import 'package:studyapp_2024/components/phone_formatter.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/components/form_validations.dart';
import 'package:studyapp_2024/features/authentication/state/auth_provider.dart';

class ProfileCompletionDialog extends ConsumerStatefulWidget {
  final User user;

  const ProfileCompletionDialog({required this.user, super.key});

  @override
  ConsumerState<ProfileCompletionDialog> createState() =>
      _ProfileCompletionDialogState();
}

class _ProfileCompletionDialogState
    extends ConsumerState<ProfileCompletionDialog> {
  final _firstNameController = TextEditingController();
  final _surnameController = TextEditingController();
  final _dobController = TextEditingController();
  final _phoneNumController = TextEditingController();

  @override
  void dispose() {
    _firstNameController.dispose();
    _surnameController.dispose();
    _dobController.dispose();
    _phoneNumController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Complete Your Profile'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            //----- FIRSTNAME TEXTFORMFIELD -----//
            TextFormField(
              keyboardType: TextInputType.text,
              controller: _firstNameController,
              decoration: formDecoration('First Name', Icons.person),
              validator: validateFirstName,
            ),
            const SizedBox(height: 20),

            //----- SURNAME TEXTFORMFIELD -----//
            TextFormField(
              keyboardType: TextInputType.text,
              controller: _surnameController,
              decoration: formDecoration('Surname', Icons.person),
              validator: validateSurname,
            ),
            const SizedBox(height: 20),

            //----- DOB TEXTFORMFIELD -----//
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    readOnly: true,
                    inputFormatters: [DateFormatter()],
                    controller: _dobController,
                    decoration: formDecoration(
                      'Birthday',
                      Icons.person,
                      hintText: 'DD/MM/YYYY',
                    ),
                    validator: validateDateOfBirth,
                  ),
                ),
                TextButton.icon(
                  icon: const Icon(Icons.calendar_month_outlined,
                      color: Colors.blue),
                  label: const Text('Choose Date',
                      style: TextStyle(color: Colors.blue)),
                  onPressed: () async {
                    DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1900),
                      lastDate: DateTime.now(),
                    );
                    if (pickedDate != null) {
                      _dobController.text =
                          DateFormat('dd/MM/yyyy').format(pickedDate);
                    }
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),

            //----- PHONENUMBER TEXTFORMFIELD -----//
            TextFormField(
              inputFormatters: [
                PhoneFormatter(),
                LengthLimitingTextInputFormatter(12),
              ],
              keyboardType: TextInputType.phone,
              controller: _phoneNumController,
              decoration: formDecoration('Contact Number', Icons.phone),
              validator: validatePhoneNum,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () async {
            if (_firstNameController.text.isNotEmpty &&
                _surnameController.text.isNotEmpty &&
                _phoneNumController.text.isNotEmpty &&
                _dobController.text.isNotEmpty) {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return MyDialogBox(
                    hideCloseButton: true,
                    icon: CupertinoIcons.exclamationmark_triangle,
                    iconColor: Colors.red,
                    title: 'Confirm Submission',
                    content: const Text(
                      'Are you sure you want to submit your details? This action cannot be undone.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    buttons: [
                      Row(
                        children: [
                          //----- CANCELING PROMPT -----//
                          Expanded(
                            child: MyButton(
                              buttonTitle: 'Cancel',
                              buttonType: ButtonType.bordered,
                              color: Colors.red,
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                              icon: Icons.close,
                            ),
                          ),
                          const SizedBox(width: 20),

                          //----- PROCEEDING WITH SUBMISSION -----//
                          Expanded(
                            child: MyButton(
                              buttonTitle: 'Yes',
                              buttonType: ButtonType.filled,
                              color: Colors.green,
                              icon: CupertinoIcons.checkmark_alt,
                              onTap: () async {
                                ref
                                    .read(authNotifierProvider.notifier)
                                    .createUser(
                                      widget.user,
                                      _firstNameController.text,
                                      _surnameController.text,
                                      _dobController.text,
                                      _phoneNumController.text,
                                    );
                                Navigator.pushReplacementNamed(
                                    context, RouteManager.studMainPage);
                              },
                            ),
                          )
                        ],
                      )
                    ],
                  );
                },
              );
            } else {
              if (context.mounted) {
                const MySnackbar(
                        message:
                            'Please complete entire form, before continuing')
                    .showSnackBar(context);
              }
            }
          },
          child: const Text('Submit'),
        ),
        TextButton(
          onPressed: () async {
            try {
              // Attempt to sign out the user
              await ref
                  .read(authNotifierProvider.notifier)
                  .signUserOut(context);
            } catch (error) {
              if (context.mounted) {
                const MySnackbar(
                  message: 'Failed to sign out. Please try again.',
                ).showSnackBar(context);
              }
              return;
            }

            // If sign-out succeeds, close the dialog
            if (context.mounted) {
              Navigator.of(context).pop();
            }
          },
          child: const Text('Cancel'),
        ),
      ],
    );
  }
}
