// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: StudRegForm CLASS (220024654 LK MAASDORP)
// PURPOSE: The widget for the student register form

import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/components/date_formatter.dart';
import 'package:studyapp_2024/components/phone_formatter.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/components/form_validations.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:studyapp_2024/widgets/dividers/my_divider.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';
import 'package:studyapp_2024/widgets/dialogs/my_loading_dialog.dart';
import 'package:studyapp_2024/features/authentication/state/auth_provider.dart';

class StudRegForm extends ConsumerStatefulWidget {
  const StudRegForm({super.key});

  @override
  ConsumerState<StudRegForm> createState() => _StudRegFormState();
}

class _StudRegFormState extends ConsumerState<StudRegForm> {
  //----- GLOBAL KEY FOR THE STUDENT REGISTER FORM -----//
  final _formKey = GlobalKey<FormState>();

  //----- TEXTEDITINGCONTROLLERS -----//
  final _firstnameController = TextEditingController();
  final _surnameController = TextEditingController();
  final _dobController = TextEditingController();
  final _phoneNumController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmedPasswordController = TextEditingController();

  //----- PASSWORD VISIBILITY TOGGLE -----//
  bool _togglePassword = false;

  @override
  void dispose() {
    _firstnameController.dispose();
    _surnameController.dispose();
    _dobController.dispose();
    _phoneNumController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmedPasswordController.dispose();
    super.dispose();
  }

  //----- METHOD FOR FOR REGISTERING THE STUDENT USER -----//
  Future<void> _signUserUp() async {
    await ref.read(authNotifierProvider.notifier).signUserUpEmail(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
          firstname: _firstnameController.text.trim(),
          surname: _surnameController.text.trim(),
          dateOfBirth: _dobController.text.trim(),
          phoneNum: _phoneNumController.text.trim(),
          role: 'student',
          context: context,
        );

    if (mounted) {
      Navigator.pushNamed(
        context,
        RouteManager.emailVerifyPage,
        arguments: _emailController.text,
      );
    }
  } //END OF _signUserUp() METHOD

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);

    return Stack(
      children: [
        Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              //----- FIRSTNAME TEXTFORMFIELD -----//
              TextFormField(
                keyboardType: TextInputType.text,
                controller: _firstnameController,
                decoration: formDecoration('First Name', Icons.person),
                validator: validateFirstName,
              ),

              const SizedBox(height: 20),

              //----- SURNAME TEXTFORMFIELD -----//
              TextFormField(
                keyboardType: TextInputType.text,
                controller: _surnameController,
                decoration: formDecoration('Surname', Icons.person),
                validator: validateSurname,
              ),

              const SizedBox(height: 20),

              Row(
                children: [
                  //----- DATE OF BIRTH TEXTFORMFIELD -----//
                  Expanded(
                    child: TextFormField(
                      keyboardType: TextInputType.datetime,
                      inputFormatters: [
                        DateFormatter(),
                      ],
                      controller: _dobController,
                      decoration: formDecoration(
                        'Date of Birth',
                        Icons.person,
                        hintText: 'DD/MM/YYYY',
                      ),
                      validator: validateDateOfBirth,
                    ),
                  ),
                  TextButton.icon(
                    icon: const Icon(
                      Icons.calendar_month_outlined,
                      color: Colors.blue,
                    ),
                    label: const Text(
                      'Choose Date',
                      style: TextStyle(color: Colors.blue),
                    ),
                    onPressed: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(1900),
                        lastDate: DateTime.now(),
                      );

                      if (pickedDate != null) {
                        setState(() {
                          _dobController.text =
                              DateFormat('dd/MM/yyyy').format(pickedDate);
                        });
                      }
                    },
                  ),
                ],
              ),

              const SizedBox(height: 20),

              //----- CONTACT NUMBER TEXTFORMFIELD -----//
              TextFormField(
                inputFormatters: [
                  PhoneFormatter(),
                  LengthLimitingTextInputFormatter(12),
                ],
                keyboardType: TextInputType.phone,
                controller: _phoneNumController,
                decoration: formDecoration('Contact Number', Icons.phone),
                validator: validatePhoneNum,
              ),

              const SizedBox(height: 20),

              //----- EMAIL TEXTFORMFIELD -----//
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                controller: _emailController,
                decoration: formDecoration('Email', Icons.mail),
                validator: validateEmail,
              ),

              const SizedBox(height: 20),

              //----- PASSWORD TEXTFORMFIELD -----//
              TextFormField(
                keyboardType: TextInputType.text,
                controller: _passwordController,
                decoration: formDecoration('Password', Icons.lock,
                    suffixIcon: _togglePassword
                        ? Icons.visibility
                        : Icons.visibility_off, onPressed: () {
                  setState(() {
                    _togglePassword = !_togglePassword;
                  });
                }),
                validator: validatePassword,
                obscureText: !_togglePassword,
                maxLength: 8,
              ),

              const SizedBox(height: 10),

              //----- CONFIRMED PASSWORD TEXTFORMFIELD -----//
              TextFormField(
                keyboardType: TextInputType.text,
                controller: _confirmedPasswordController,
                decoration: formDecoration('Confirm Password', Icons.lock,
                    suffixIcon: _togglePassword
                        ? Icons.visibility
                        : Icons.visibility_off, onPressed: () {
                  setState(() {
                    _togglePassword = !_togglePassword;
                  });
                }),
                validator: (value) {
                  return validateConfirmPassword(
                      _passwordController.text, value);
                },
                obscureText: !_togglePassword,
                maxLength: 8,
              ),

              const SizedBox(height: 20),

              //----- SIGN UP BUTTON -----//
              MyButton(
                buttonTitle: 'Continue with Sign Up',
                onTap: () {
                  if (_formKey.currentState!.validate()) {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return MyDialogBox(
                          hideCloseButton: true,
                          icon: CupertinoIcons.exclamationmark_triangle,
                          iconColor: Colors.red,
                          title: 'Continue Account Creation',
                          content: const Text(
                            'Are you sure all your details are correct before proceeding? This action cannot be undone.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          buttons: [
                            //----- CANCELING PROMPT -----//
                            Row(
                              children: [
                                Expanded(
                                  child: MyButton(
                                    buttonTitle: 'Cancel',
                                    buttonType: ButtonType.bordered,
                                    onTap: () {
                                      Navigator.of(context)
                                          .pop(); // Close the dialog
                                    },
                                    color: Colors.blue,
                                    icon: Icons.close,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                //----- PROCEEDING WITH SIGN UP -----//
                                Expanded(
                                  child: MyButton(
                                    buttonTitle: 'Yes',
                                    buttonType: ButtonType.filled,
                                    onTap: () async {
                                      Navigator.of(context).pop();
                                      await _signUserUp();
                                    },
                                    color: Colors.green,
                                    icon: Icons.check,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    );
                  }
                },
                color: const Color.fromARGB(255, 119, 167, 206),
              ),

              const SizedBox(height: 20),

              //----- DIVIDER -----//
              const MyDivider(
                dividerText: 'Or Continue With',
              ),

              const SizedBox(height: 20),

              //----- GOOGLE SIGN-IN BUTTON -----//
              MyButton(
                buttonTitle: 'Google',
                onTap: () async {
                  await ref
                      .read(authNotifierProvider.notifier)
                      .signUserInGoogle(context);
                },
                fontAwesomeIcon: (FontAwesomeIcons.google),
                color: const Color.fromRGBO(219, 68, 55, 1),
              ),

              const SizedBox(height: 40),

              //----- ALREADY HAVE AN ACCOUNT SECTION -----//
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    "Already have an Account?",
                    style: TextStyle(
                      color: Colors.grey,
                    ),
                  ),
                  const SizedBox(width: 4),

                  //----- NAVIGATES TO STUDENT LOGIN FORM -----//
                  GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, RouteManager.studLogPage);
                    },
                    child: const Text(
                      'Sign in Here',
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        if (authState.isLoading)
          const LoadingDialog(
            icon: CupertinoIcons.person_crop_circle_badge_checkmark,
            message: "Please wait while we process your registration...",
          ),
      ],
    );
  }
} //END OF StudRegForm WIDGET
