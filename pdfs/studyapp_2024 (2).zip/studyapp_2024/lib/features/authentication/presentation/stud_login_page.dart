// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: StudLogPage CLASS (220024654_LK Maasdorp)
// PURPOSE: This class is responsible for displaying the login form widget to the user

import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/authentication/presentation/widgets/stud_login_form.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';

class StudLogPage extends StatefulWidget {
  const StudLogPage({super.key});

  @override
  State<StudLogPage> createState() => _StudLogPageState();
}

class _StudLogPageState extends State<StudLogPage> {
  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var fontSizeTitle = screenWidth * 0.08;
    var fontSizeSubtitle = screenWidth * 0.05;
    var paddingHorizontal = screenWidth * 0.05;
    var paddingVertical = screenHeight * 0.03;

    return Scaffold(
      appBar: MyAppBar(
        title: const Text('Sign Into Account'),
        leadingIcon: Icons.arrow_back_rounded,
        onLeadingIconPressed: () {
          Navigator.pushNamed(context, RouteManager.landingPage);
        },
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: paddingHorizontal,
          vertical: paddingVertical,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome Back!',
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: fontSizeTitle,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: screenHeight * 0.02), // Adjust spacing
              Text(
                'Please Sign into your account to Continue',
                style: TextStyle(
                  fontSize: fontSizeSubtitle,
                  color: Colors.grey,
                ),
              ),
              SizedBox(height: screenHeight * 0.03), // Adjust spacing

              // ----- THE StudLogForm WIDGET -----
              const StudLogForm(),
            ],
          ),
        ),
      ),
    );
  }
} //END OF StudLogPage CLASS

//END OF StudLogPage CLASS
