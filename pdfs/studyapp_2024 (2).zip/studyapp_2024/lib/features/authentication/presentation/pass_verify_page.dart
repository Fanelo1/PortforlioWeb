// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: PassResetPage CLASS (220024654 LK MAASDORP)
// PURPOSE: This class is responsible for handling the verfication of the user's email address, for resetting a forgotten password

//TODO: Make consumer

import 'dart:async';
import 'package:lottie/lottie.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/features/authentication/presentation/reset_pass_page.dart';

class PassVerifyPage extends StatefulWidget {
  final String email;

  const PassVerifyPage({super.key, required this.email});

  @override
  State<PassVerifyPage> createState() => _PassVerifyPageState();
}

class _PassVerifyPageState extends State<PassVerifyPage> {
  final TextEditingController _emailController = TextEditingController();
  bool _isSendingVerification = false;
  Timer? _emailCheckTimer;

  @override
  void initState() {
    super.initState();
    _emailController.text = widget.email;
  }

  @override
  void dispose() {
    _emailController.dispose();
    _emailCheckTimer?.cancel();
    super.dispose();
  }

  Future<void> _sendEmailVerification() async {
    try {
      setState(() {
        _isSendingVerification = true;
      });

      String email = _emailController.text.trim();

      if (email.isNotEmpty) {
        final snapshot = await FirebaseFirestore.instance
            .collection('users')
            .where('Email Address', isEqualTo: email)
            .get();

        if (snapshot.docs.isNotEmpty) {
          User? currentUser = FirebaseAuth.instance.currentUser;
          if (currentUser == null) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('User not signed in.')),
              );
            }
            return;
          }
          await currentUser.sendEmailVerification();

          if (mounted) {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (context) => const MyDialogBox(
                content: Text(
                  'Verification Email has been sent! Please check your inbox',
                  textAlign: TextAlign.center,
                ),
                icon: FontAwesomeIcons.paperPlane,
                iconColor: Colors.blue,
                hideCloseButton: false,
              ),
            );
          }
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Email not found in our records')),
            );
          }
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error: Please enter your email')),
        );
      }
      setState(() {
        _isSendingVerification = false;
      });
    } catch (e) {
      setState(() {
        _isSendingVerification = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error sending verification email: $e')),
        );
      }
    }
  }

  Future<void> _checkEmailVerification() async {
    User? currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser != null) {
      await currentUser.reload(); // Reload user state
      currentUser = FirebaseAuth.instance.currentUser;

      if (currentUser!.emailVerified) {
        _emailCheckTimer?.cancel(); // Stop timer once verified

        // Automatically navigate after email is verified
        WidgetsBinding.instance.addPostFrameCallback((_) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ResetPassPage(email: widget.email),
            ),
          );
        });
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User not signed in.')),
      );
    }
  }

  //----- SHOW CONFIRMATION DIALOG ON BACK BUTTON PRESS -----//
  Future<bool> _onWillPop() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Are you sure you want to leave?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                FirebaseAuth.instance.signOut();
                Navigator.of(context).pop(true); // Return true when confirmed
                Navigator.of(context)
                    .pushReplacementNamed(RouteManager.studLogPage);
              },
              child: const Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false); // Return false when declined
              },
              child: const Text('No'),
            ),
          ],
        );
      },
    );
    return result ?? false; // Ensure a boolean value is returned
  }

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var paddingHorizontal = screenWidth * 0.05;
    var paddingVertical = screenHeight * 0.03;
    var fontSizeTitle = screenWidth * 0.047;
    var fontSize = screenWidth * 0.045;
    var lottieHeight = screenHeight * 0.35;
    var lottieWidth = screenWidth * 0.8;

    return WillPopScope(
      onWillPop: () async => _onWillPop(),
      child: Scaffold(
        appBar: MyAppBar(
          title: Text(
            'Email Verification',
            style: TextStyle(fontSize: fontSizeTitle),
          ),
          onBackButtonPressed: () async {
            // Call _onWillPop and check the result, without returning any value.
            bool shouldPop = await _onWillPop();
            if (shouldPop) {
              if (context.mounted) {
                Navigator.of(context).pop();
              }
            }
          },
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: paddingHorizontal,
                vertical: paddingVertical,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: lottieHeight,
                    width: lottieWidth,
                    child: Lottie.asset(
                      'assets/animations/VerifyPass.json',
                      fit: BoxFit.contain,
                    ),
                  ),
                  const SizedBox(height: 30),
                  Text(
                    'First verify your account to proceed.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: fontSizeTitle, fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 15),
                  Text(
                    'A verification email will be sent to this email address.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: fontSize),
                  ),
                  const SizedBox(height: 20),

                  // Email TextFormField
                  TextFormField(
                    controller: _emailController,
                    decoration: formDecoration('Email Address', Icons.mail),
                    style: TextStyle(fontSize: fontSize * 0.9),
                    readOnly: true,
                  ),
                  const SizedBox(height: 20),

                  // Send Verification Email Button
                  MyButton(
                    buttonTitle: _isSendingVerification
                        ? 'Sending...'
                        : 'Send Verification Email',
                    buttonType: ButtonType.bordered,
                    onTap:
                        _isSendingVerification ? null : _sendEmailVerification,
                    color: Colors.blue,
                  ),

                  const SizedBox(height: 20),

                  // Always display the Continue button
                  MyButton(
                    buttonTitle: 'Check Verification Status',
                    buttonType: ButtonType.bordered,
                    onTap:
                        _checkEmailVerification, // Call to check email verification
                    color: Colors.green,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
