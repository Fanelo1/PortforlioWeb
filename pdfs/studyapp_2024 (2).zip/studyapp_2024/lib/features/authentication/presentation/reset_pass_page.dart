// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: ResetPasswordPage CLASS (220024654 LK MAASDORP)
// PURPOSE: This class is responsible for reseting and updating the password for the user

import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/components/form_validations.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/features/authentication/state/auth_provider.dart';

class ResetPassPage extends ConsumerStatefulWidget {
  const ResetPassPage({super.key, required String email});

  @override
  ConsumerState<ResetPassPage> createState() => _ResetPassPageState();
}

class _ResetPassPageState extends ConsumerState<ResetPassPage> {
  //----- GLOBAL KEY FOR THE RESET PASSWORD FIELDS -----//
  final _formKey = GlobalKey<FormState>();

  //----- TEXTEDITINCONTROLLERS -----//
  final _newPasswordController = TextEditingController();
  final _confirmedPasswordController = TextEditingController();

  //----- PASSWORD VISIBILITY TOGGLE -----//
  bool _togglePassword = false;

  @override
  void dispose() {
    _newPasswordController.dispose();
    _confirmedPasswordController.dispose();
    super.dispose();
  }

  Future<bool> _onWillPop() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Are you sure you want to leave?'),
        actions: <Widget>[
          TextButton(
            onPressed: () async {
              await ref
                  .read(authNotifierProvider.notifier)
                  .signUserOut(context);
              if (context.mounted) {
                Navigator.of(context)
                    .pushReplacementNamed(RouteManager.studLogPage);
              }
            },
            child: const Text('Yes'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('No'),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    //----- AUTHENTICATION STATE MANAGEMENT -----//
    final authState = ref.watch(authNotifierProvider);

    //----- MAKING THE PAGE RESPONSIVE -----//
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var paddingHorizontal = screenWidth * 0.05;
    var paddingVertical = screenHeight * 0.03;
    var fontSize = screenWidth * 0.045;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: MyAppBar(
          title: const Text('Reset Password'),
          onBackButtonPressed: _onWillPop,
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: paddingHorizontal, vertical: paddingVertical),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                //----- NEW PASSWORD TEXTFORMFIELD -----//
                TextFormField(
                  keyboardType: TextInputType.text,
                  controller: _newPasswordController,
                  decoration: formDecoration(
                    'New Password',
                    Icons.lock,
                    suffixIcon: _togglePassword
                        ? Icons.visibility
                        : Icons.visibility_off,
                    onPressed: () {
                      setState(() {
                        _togglePassword = !_togglePassword;
                      });
                    },
                  ),
                  validator: validatePassword,
                  obscureText: !_togglePassword,
                  maxLength: 8,
                  onChanged: (value) {
                    ref
                        .read(authNotifierProvider.notifier)
                        .checkPassword(value);
                  },
                  style: TextStyle(fontSize: fontSize),
                ),
                SizedBox(height: screenHeight * 0.02),

                //----- CONFIRMED PASSWORD TEXTFORMFIELD -----//
                TextFormField(
                  keyboardType: TextInputType.text,
                  controller: _confirmedPasswordController,
                  decoration: formDecoration(
                    'Confirm Password',
                    Icons.lock,
                    suffixIcon: _togglePassword
                        ? Icons.visibility
                        : Icons.visibility_off,
                    onPressed: () {
                      setState(() {
                        _togglePassword = !_togglePassword;
                      });
                    },
                  ),
                  validator: (value) {
                    return validateConfirmPassword(
                        _newPasswordController.text, value);
                  },
                  obscureText: !_togglePassword,
                  maxLength: 8,
                  style: TextStyle(fontSize: fontSize),
                ),
                SizedBox(height: screenHeight * 0.02),

                //----- PASSWORD STRENGTH INDICATOR FLAGS -----//
                Expanded(
                  child: Column(
                    children: [
                      _buildPasswordIndicator(
                          authState.passwordValidation.hasUppercase,
                          'Password contains at least one uppercase letter'),
                      _buildPasswordIndicator(
                          authState.passwordValidation.hasLowercase,
                          'Password contains at least one lowercase letter'),
                      _buildPasswordIndicator(
                          authState.passwordValidation.hasSpecialCharacter,
                          'Password contains at least one special character'),
                      _buildPasswordIndicator(
                          authState.passwordValidation.hasNumber,
                          'Password contains at least one digit'),
                      _buildPasswordIndicator(
                          authState.passwordValidation.isLongEnough,
                          'Password is 8 characters long'),
                    ],
                  ),
                ),

                //----- SAVE NEW PASSWORD BUTTON -----//
                MyButton(
                  buttonTitle: 'Save Changes',
                  onTap: () async {
                    if (_formKey.currentState!.validate()) {
                      try {
                        await ref
                            .read(authNotifierProvider.notifier)
                            .resetPassword(_confirmedPasswordController.text);
                        if (context.mounted) {
                          Navigator.pushNamed(
                              context, RouteManager.studLogPage);
                        }
                      } catch (error) {
                        //
                      }
                    }
                  },
                  color: const Color.fromARGB(255, 119, 167, 206),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //----- PASSWORD INDICATOR WIDGET -----//
  Widget _buildPasswordIndicator(bool isValid, String text) {
    var fontSize = MediaQuery.of(context).size.width * 0.03;
    return Row(
      children: [
        Icon(
          isValid ? Icons.check_circle : Icons.cancel,
          color: isValid ? Colors.green : Colors.red,
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(
            color: isValid ? Colors.green : Colors.red,
            fontWeight: FontWeight.bold,
            fontSize: fontSize,
          ),
        ),
      ],
    );
  }
} //END OF ResetPassPage CLASS
