// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: StudRegPage CLASS (220024654_LK Maasdorp)
// PURPOSE: This class is responsible for displaying the register form widget to the user

import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/authentication/presentation/widgets/stud_register_form.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';

class StudRegPage extends StatefulWidget {
  const StudRegPage({super.key});

  @override
  State<StudRegPage> createState() => _StudRegPageState();
}

class _StudRegPageState extends State<StudRegPage> {
  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var fontSizeTitle = screenWidth * 0.08;
    var fontSizeSubtitle = screenWidth * 0.05;
    var paddingHorizontal = screenWidth * 0.05;
    var paddingVertical = screenHeight * 0.03;

    return Scaffold(
      appBar: MyAppBar(
        title: const Text('Create an Account'),
        leadingIcon: Icons.arrow_back_rounded,
        onLeadingIconPressed: () {
          Navigator.pushNamed(context, RouteManager.studLogPage);
        },
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: paddingHorizontal,
          vertical: paddingVertical,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome!',
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: fontSizeTitle,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: screenHeight * 0.02),
              Text(
                'Please create an account to continue',
                style: TextStyle(
                  fontSize: fontSizeSubtitle,
                  color: Colors.grey,
                ),
              ),
              SizedBox(height: screenHeight * 0.03),

              // ----- THE StudLogForm WIDGET ----- //
              const StudRegForm(),
            ],
          ),
        ),
      ),
    );
  }
} //END OF StudRegPage Class

//END OF StudRegPage Class
