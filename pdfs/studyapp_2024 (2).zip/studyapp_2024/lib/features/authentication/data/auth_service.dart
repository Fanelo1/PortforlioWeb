// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: AuthService CLASS (220024654_LK Maasdorp)
// PURPOSE: This class is responsible for handling the authentication of the user for our application

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/components/my_snackbar.dart';
import 'package:studyapp_2024/features/authentication/presentation/widgets/profile_complete_dialog.dart';
import 'package:studyapp_2024/widgets/dialogs/my_loading_dialog.dart';

class AuthService {
  final FirebaseAuth _auth;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseFirestore _firestore;

  AuthService(this._auth) : _firestore = FirebaseFirestore.instance;

//----- CHECKS IF THE USER IS CURRENTLY SIGNED IN -----//
  Stream<User?> get authState => _auth.authStateChanges();

//----- METHOD TO CREATE THE USER WITH A EMAIL AND PASSWORD -----//
  Future<void> signUpWithEmail({
    required String email,
    required String password,
    required String firstname,
    required String surname,
    required String dateOfBirth,
    required String phoneNum,
    required BuildContext context,
    required String role,
  }) async {
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      User? user = userCredential.user;
      if (user != null) {
        //----- SEND VERIFICATION EMAIL TO NEW USER -----//
        await user.sendEmailVerification();

        //----- STORE NEW USER DATA IN THE FIRESTORE TEMPORARILY -----//
        await FirebaseFirestore.instance
            .collection('pendingUsers')
            .doc(user.uid)
            .set({
          'Email Address': email,
          'Password': password,
          'Firstname': firstname,
          'Surname': surname,
          'Date Of Birth': dateOfBirth,
          'Contact Number': phoneNum,
          'User Role': role,
          'Account Created': FieldValue.serverTimestamp(),
          'Account Type': 'Email & Password'
        });
        if (context.mounted) {
          const MySnackbar(
                  message: 'Account created! Please verify your email.')
              .showSnackBar(context);
        }
      }
    } catch (e) {
      //----- ERROR MESSAGES TO DISPLAY TO USER -----//
      String errorMessage =
          'An error occurred while creating the account. Please try again.';

      if (e is FirebaseAuthException) {
        switch (e.code) {
          case 'email-already-in-use':
            errorMessage = 'An account already exists for this email.';
            break;
          case 'invalid-email':
            errorMessage =
                'The email address is not valid. Please enter a valid email.';
            break;
          case 'network-request-failed':
            errorMessage =
                'Network error. Please check your internet connection.';
            break;
          default:
            errorMessage = e.message ?? errorMessage;
        }
      }
      if (context.mounted) {
        MySnackbar(message: errorMessage).showSnackBar(context);
      }
    }
  } //END OF METHOD TO CREATE USER WITH EMAIL & PASSWORD

//----- METHOD TO SIGN THE CURRENT USER IN WITH THEIR EMAIL AND PASSWORD -----//
  Future<void> signInWithEmail({
    required String email,
    required String password,
    BuildContext? context,
  }) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = userCredential.user;

      if (user != null) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .update({
          'Last Logged In': user.metadata.lastSignInTime,
        });
        if (context != null && context.mounted) {
          MySnackbar(
            message: 'Welcome back, ${user.email}!',
          ).showSnackBar(context);
        }
      }
    } catch (e) {
      //----- ERROR MESSAGES TO DISPLAY TO USER -----//
      String errorMessage =
          'An error occurred while signing in. Please try again.';
      if (e is FirebaseAuthException) {
        switch (e.code) {
          case 'user-not-found':
            errorMessage = 'No user found for the provided credentials.';
            break;
          case 'wrong-password':
            errorMessage = 'Incorrect Password.';
            break;
          case 'network-request-failed':
            errorMessage = 'Network error. Check your internet connection.';
            break;

          default:
            errorMessage = e.message ?? errorMessage;
        }
      }
      if (context != null && context.mounted) {
        MySnackbar(
          message: errorMessage,
        ).showSnackBar(context);
      }
    }
  } //END OF SIGN IN WITH EMAIL & PASSWORD METHOD

//----- METHOD TO SIGN THE CURRENT USER IN WITH THEIR GOOGLE ACCOUNT -----//
  Future<void> signInWithGoogle(BuildContext context) async {
    try {
      final GoogleSignInAccount? gUser = await GoogleSignIn().signIn();
      if (gUser == null) return;

      final GoogleSignInAuthentication gAuth = await gUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: gAuth.accessToken,
        idToken: gAuth.idToken,
      );

      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithCredential(credential);
      User? user = userCredential.user;

      if (user != null) {
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        //----- PROFILE COMPLETION FORM DIALOG BOX -----//
        if (!userDoc.exists) {
          if (context.mounted) {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (BuildContext context) {
                return ProfileCompletionDialog(user: user);
              },
            );
          }
        } else {
          if (context.mounted) {
            showLoading(
              context,
              message: 'Signing You in...',
              icon: CupertinoIcons.person_crop_circle_badge_checkmark,
            );
          }
          //----- NEW SIGN-IN TIME IS ADDED TO FIRESTORE -----//
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .update({
            'Last Logged In': user.metadata.lastSignInTime,
          });
          //----- NAVIGATE TO studMainPage -----//
          if (context.mounted) {
            Navigator.pushReplacementNamed(context, RouteManager.studMainPage);
          }
        }
      }
    } catch (e) {
      String errorMessage =
          'An error occurred during Google sign-in. Please try again.';
      if (e is FirebaseAuthException) {
        switch (e.code) {
          case 'account-exists-with-different-credential':
            errorMessage =
                'An account already exists with the same email address but different sign-in credentials.';
            break;
          case 'invalid-credential':
            errorMessage = 'The Google credential is invalid or has expired.';
            break;
          case 'user-disabled':
            errorMessage =
                'This user account has been disabled. Contact support.';
            break;
          case 'operation-not-allowed':
            errorMessage =
                'Google sign-in is not enabled. Please contact support.';
            break;
          case 'user-not-found':
            errorMessage = 'No user found for the provided credentials.';
            break;
          case 'network-request-failed':
            errorMessage = 'Network error. Check your internet connection.';
            break;
          default:
            errorMessage = e.message ?? errorMessage;
        }
      }
      if (context.mounted) {
        hideLoading(context);
        MySnackbar(message: errorMessage).showSnackBar(context);
      }
    }
  } //END OF SIGN IN WITH GOOGLE METHOD

//----- METHOD TO SIGN CURRENT USER OUT OF APP -----//
  Future<void> signOut(BuildContext context) async {
    try {
      await _auth.signOut();
      await _googleSignIn.signOut();
      if (context.mounted) {
        Navigator.pushReplacementNamed(context, RouteManager.landingPage);
      }
    } catch (e) {
      if (context.mounted) {
        const MySnackbar(
                message:
                    'Failed to sign out of account.Please try again later.')
            .showSnackBar(context);
      }
    }
  }

//----- METHOD TO MOVE TEMPORARY DATA TO USERS COLLECTION -----//
  Future<void> moveUserData(User user) async {
    try {
      DocumentSnapshot pendingUserDoc =
          await _firestore.collection('pendingUsers').doc(user.uid).get();

      if (pendingUserDoc.exists) {
        await _firestore
            .collection('users')
            .doc(user.uid)
            .set(pendingUserDoc.data() as Map<String, dynamic>);

        await _firestore.collection('users').doc(user.uid).update({
          'Email Verified': FieldValue.serverTimestamp(),
        });

        await _firestore.collection('pendingUsers').doc(user.uid).delete();
      }
    } catch (e) {
      throw Exception('Error moving user data: $e');
    }
  }

//----- READ (FORGOT PASSWORD) -----//
  Future<bool> userExists(String email) async {
    var userSnapshot = await _firestore
        .collection('users')
        .where('Email Address', isEqualTo: email.toLowerCase())
        .get();
    return userSnapshot.docs.isNotEmpty;
  }

//----- READ (GROUP MEMBERS) -----//
  Future<List<String>> getGroupMembers(String groupId) async {
    var groupSnapshot =
        await _firestore.collection('groups').doc(groupId).get();
    if (groupSnapshot.exists) {
      return List<String>.from(groupSnapshot.data()?['members'] ?? []);
    }
    return [];
  }

//----- READ (PassVerify, Sending verification) -----//
  Future<void> sendVerificationEmail(User user) async {
    try {
      await user.sendEmailVerification();
    } catch (e) {
      throw Exception('Error sending verification email: $e');
    }
  }

//----- READ (PassVerify, Sending verification) -----//
  Future<void> sendPassVerification() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null && !user.emailVerified) {
      await user.sendEmailVerification();
    }
  }

//----- READ (PassVerify, Check if user is verified within 5 mins) -----//
  Future<bool> checkPassVerified(User user) async {
    try {
      await user.reload();

      if (user.emailVerified) {
        DocumentSnapshot userDoc =
            await _firestore.collection('users').doc(user.uid).get();

        if (userDoc.exists && userDoc['Email Verified'] != null) {
          Timestamp emailVerifiedTimestamp = userDoc['Email Verified'];

          DateTime currentTime = DateTime.now();
          DateTime verifiedTime = emailVerifiedTimestamp.toDate();
          Duration timeDifference = currentTime.difference(verifiedTime);

          if (timeDifference.inMinutes <= 5) {
            return true;
          }
        }
      }
      return false;
    } catch (e) {
      throw Exception('Error checking email verification: $e');
    }
  }

//----- READ (PassVerify, Check if user is verified) -----//
  Future<bool> checkEmailVerified(User user) async {
    try {
      await user.reload();
      return user.emailVerified;
    } catch (e) {
      throw Exception('Error checking email verification: $e');
    }
  }

//----- READ (Checking if user is an existing account) -----//
  Future<bool> checkUserEmailExists(String email) async {
    try {
      final snapshot = await _firestore
          .collection('users')
          .where('Email Address', isEqualTo: email)
          .get();
      return snapshot.docs.isNotEmpty;
    } catch (e) {
      throw Exception('Error checking email existence: $e');
    }
  }

//----- DELETE (StudVerify, deleting temp data) -----//
  Future<void> deleteUserAndData(User user) async {
    try {
      await FirebaseFirestore.instance
          .collection('pendingUsers')
          .doc(user.uid)
          .delete();

      await user.delete();

      await FirebaseAuth.instance.signOut();
    } catch (e) {
      throw Exception('Failed to delete user: $e');
    }
  }

//----- READ (Forgot Password, Check if email exists) -----//
  Future<bool> checkEmailExists(String email) async {
    final snapshot = await _firestore
        .collection('users')
        .where('Email Address', isEqualTo: email)
        .where('Account Type', isEqualTo: 'Email & Password')
        .get();
    return snapshot.docs.isNotEmpty;
  }

//----- UPDATE (Update User's password) -----//
  Future<void> updateUserPassword(String newPassword) async {
    User? user = _auth.currentUser;
    if (user != null) {
      await user.updatePassword(newPassword);
      await _firestore.collection('users').doc(user.uid).update({
        'Password': newPassword,
      });
    }
  }

//----- READ (Check for existing user) -----//
  Future<bool> checkIfUserExists(String email) async {
    final snapshot = await _firestore
        .collection('users')
        .where('Email Address', isEqualTo: email)
        .get();
    return snapshot.docs.isNotEmpty;
  }

//----- READ (Retrieve current user's password) -----//
  Future<String?> getUserPassword(String email) async {
    final snapshot = await _firestore
        .collection('users')
        .where('Email Address', isEqualTo: email)
        .get();

    if (snapshot.docs.isNotEmpty) {
      return snapshot.docs.first['Password'] as String?;
    }
    return null;
  }

//----- UPDATE (Updating login time in firestore) -----//
  Future<void> updateLastLoginTime(String userId) async {
    await _firestore.collection('users').doc(userId).update({
      'Last Logged In': FieldValue.serverTimestamp(),
    });
  }

//----- CREATE (Google Profile Complete) -----//
  Future<void> createUserProfile(User user, String firstName, String surname,
      String dob, String phoneNum) async {
    await _firestore.collection('users').doc(user.uid).set({
      'Account Created': FieldValue.serverTimestamp(),
      'Email Address': user.email,
      'Firstname': firstName,
      'Surname': surname,
      'Date Of Birth': dob,
      'Contact Number': phoneNum,
      'Account Type': 'Google',
      'User  Role': 'student',
      'Last Logged In': user.metadata.lastSignInTime,
    });
  }
} //END OF AUTHSERVICE CLASS

//----- METHOD TO SHOW CIRCLE LOADING PROGRESS INDICATOR -----//
void showLoading(
  BuildContext context, {
  String? message,
  IconData? icon,
  Color? iconColor,
}) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) => LoadingDialog(
      message: message,
      icon: icon,
      iconColor: iconColor,
    ),
  );
} //END OF showLoading METHOD

//----- METHOD TO HIDE CIRCLE LOADING PROGRESS INDICATOR -----//
void hideLoading(BuildContext context) {
  Navigator.of(
    context,
    rootNavigator: true,
  ).pop();
} //END OF hideLoading METHOD
 
