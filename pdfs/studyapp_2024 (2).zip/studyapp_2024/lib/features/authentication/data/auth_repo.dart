import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/authentication/data/auth_service.dart';

class AuthRepo {
  final AuthService _authService;
  AuthRepo(this._authService);

  Future<bool> checkExistsUser(String email) async {
    return await _authService.checkIfUserExists(email);
  }

//========== USER: CRUD OPERATIONS ==========//

  //CREATE (EMAIL & PASS ACCOUNT)
  Future<void> signUpEmail({
    required String email,
    required String password,
    required String firstname,
    required String surname,
    required String dateOfBirth,
    required String phoneNum,
    required BuildContext context,
    required String role,
  }) async {
    await _authService.signUpWithEmail(
      email: email,
      password: password,
      firstname: firstname,
      surname: surname,
      dateOfBirth: dateOfBirth,
      phoneNum: phoneNum,
      context: context,
      role: role,
    );
  }

  //CREATE (PROFILE FOR GOOGLE USER)
  Future<void> createProfile(User user, String firstName, String surname,
      String dob, String phoneNum) async {
    await _authService.createUserProfile(
        user, firstName, surname, dob, phoneNum);
  }

  //READ (EMAIL & PASS)
  Future<void> signInEmail(String email, String password) async {
    return await _authService.signInWithEmail(email: email, password: password);
  }

  //READ & CREATE (GOOGLE ACCOUNT)
  Future<void> signInGoogle(BuildContext context) async {
    await _authService.signInWithGoogle(context);
  }

  //READ (SIGN-OUT)
  Future<void> signOutUser(BuildContext context) async {
    await _authService.signOut(context);
  }

  //READ & UPDATE (MOVE-DATA)
  Future<void> moveData(User user) async {
    await _authService.moveUserData(user);
  }

//========== VERIFICATION: CRUD OPERATIONS ==========//

  //READ (VERIFY EMAIL, StudVerifyPage)
  Future<void> sendEmailVerification(User user) async {
    await _authService.sendVerificationEmail(user);
  }

  //READ (VERIFY EMAIL, PassVerifyPage)
  Future<void> sendVerificationPass(User user) async {
    await _authService.sendPassVerification();
  }

  Future<bool> checkVerifiedUser(User user) async {
    return await _authService.checkEmailVerified(user);
  }

  Future<bool> checkVerifiedPass(User user) async {
    return await _authService.checkPassVerified(user);
  }

  Future<void> deleteUserData(User user) async {
    try {
      await _authService.deleteUserAndData(user);
    } catch (e) {
      throw Exception('Failed to delete user data: $e');
    }
  }

  //----- FORGOT PASSWORDS -----//
  Future<bool> checkIfEmailExists(String email) async {
    return await _authService.checkEmailExists(email);
  }

  Future<void> handleForgotPassword(String email) async {
    final password = await _authService.getUserPassword(email);
    if (password == null) {
      throw Exception('User not found');
    }
    await _authService.signInWithEmail(email: email, password: password);
  }

  Future<void> updatePassword(String newPassword) async {
    await _authService.updateUserPassword(newPassword);
  }
}
