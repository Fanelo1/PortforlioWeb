import 'package:firebase_auth/firebase_auth.dart';

class AuthState {
  final User? user;
  final String? error;
  final bool isLoading;
  final String? message;
  final bool isUserFound;
  final bool isEmailVerified;
  final bool isPasswordValid;
  final bool isEmailInFirestore;
  final bool isDeletingAccount;
  final bool isSendingVerification;
  final bool isPassVerifySending;
  final PasswordValidation passwordValidation;
  final bool isPassVerified;

  AuthState({
    this.isPassVerified = false,
    this.user,
    this.error,
    this.message,
    this.isLoading = false,
    this.isUserFound = false,
    this.isPasswordValid = false,
    this.isEmailVerified = false,
    this.isDeletingAccount = false,
    this.isEmailInFirestore = false,
    this.isSendingVerification = false,
    this.isPassVerifySending = false,
    this.passwordValidation = const PasswordValidation(),
  });

  AuthState copyWith({
    User? user,
    bool? isLoading,
    String? error,
    String? message,
    bool? isUserFound,
    bool? isEmailVerified,
    bool? isPasswordValid,
    bool? isDeletingAccount,
    bool? isEmailInFirestore,
    bool? isSendingVerification,
    bool? isPassVerifySending,
    PasswordValidation? passwordValidation,
  }) {
    return AuthState(
      user: user ?? this.user,
      error: error ?? this.error,
      message: message ?? this.message,
      isLoading: isLoading ?? this.isLoading,
      isUserFound: isUserFound ?? this.isUserFound,
      isPasswordValid: isPasswordValid ?? this.isPasswordValid,
      isSendingVerification:
          isSendingVerification ?? this.isSendingVerification,
      isPassVerifySending: isPassVerifySending ?? this.isPassVerifySending,
      isEmailVerified: isEmailVerified ?? this.isEmailVerified,
      isDeletingAccount: isDeletingAccount ?? this.isDeletingAccount,
      passwordValidation: passwordValidation ?? this.passwordValidation,
      isEmailInFirestore: isEmailInFirestore ?? this.isEmailInFirestore,
    );
  }
}

class PasswordValidation {
  final bool hasNumber;
  final bool hasUppercase;
  final bool hasLowercase;
  final bool isLongEnough;
  final bool hasSpecialCharacter;

  const PasswordValidation({
    this.hasNumber = false,
    this.hasUppercase = false,
    this.hasLowercase = false,
    this.isLongEnough = false,
    this.hasSpecialCharacter = false,
  });
}
