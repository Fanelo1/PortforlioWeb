// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: AuthStateNotifier CLASS (220024654_LK Maasdorp)
// PURPOSE:

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/features/authentication/data/auth_repo.dart';
import 'package:studyapp_2024/features/authentication/state/auth_state.dart';

class AuthStateNotifier extends StateNotifier<AuthState> {
  final AuthRepo _authRepo;
  User? get _user => state.user;

  //----- CONSTRUCTORS -----//
  AuthStateNotifier(this._authRepo) : super(AuthState());

  //CREATE STATE (EMAIL & PASS ACCOUNT)
  Future<void> signUserUpEmail({
    required String email,
    required String password,
    required String firstname,
    required String surname,
    required String dateOfBirth,
    required String phoneNum,
    required BuildContext context,
    required String role,
  }) async {
    state = state.copyWith(isLoading: true);
    try {
      await _authRepo.signUpEmail(
        email: email,
        password: password,
        firstname: firstname,
        surname: surname,
        dateOfBirth: dateOfBirth,
        phoneNum: phoneNum,
        context: context,
        role: role,
      );
      state = state.copyWith(error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //READ STATE (EMAIL & PASS ACCOUNT)
  Future<void> signUserInEmail(String email, String password) async {
    state = state.copyWith(isLoading: true);
    try {
      await _authRepo.signInEmail(
          email, password); // Changed authRepo to _authRepo
      state = state.copyWith(error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //READ & CREATE STATE (GOOGLE ACCOUNT)
  Future<void> signUserInGoogle(BuildContext context) async {
    state = state.copyWith(isLoading: true);
    try {
      await _authRepo.signInGoogle(context); // Changed authRepo to _authRepo
      state = state.copyWith(error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //READ STATE (SIGN OUT)
  Future<void> signUserOut(BuildContext context) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      await _authRepo.signOutUser(context);
      state = AuthState();
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //READ STATE (USER EMAIL)
  Future<void> checkUserEmail() async {
    state = state.copyWith(isLoading: true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await user.reload();
        final isVerified = user.emailVerified;
        state = state.copyWith(isEmailVerified: isVerified);

        if (isVerified) {
          await _authRepo.moveData(user);
        }
      }
      state = state.copyWith(error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //READ STATE (PASSVERIFY EMAIL)
  Future<void> checkPassEmail(User user) async {
    // Start loading
    state = AuthState(isLoading: true);
    try {
      bool isVerified = await _authRepo.checkVerifiedPass(user);

      state = AuthState(isPassVerified: isVerified);
    } catch (e) {
      state = AuthState(error: 'Failed to check verification status: $e');
    }
  }

  //READ STATE (EMAIL VERIFICATION)
  Future<void> sendVerifyEmail() async {
    state = state.copyWith(isSendingVerification: true);
    try {
      if (_user != null) {
        await _authRepo.sendEmailVerification(_user!);
      }
      state = state.copyWith(error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isSendingVerification: false);
    }
  }

  //READ STATE (PASS VERIFICATION)
// Example sendPassEmail method (make sure this is in your AuthNotifier)
  Future<void> sendPassEmail() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      await user.sendEmailVerification();
      // Optionally, set a loading state or notify the user that the email has been sent
    } else {
      throw Exception("User not logged in");
    }
  }

  //DELETE STATE (USER TEMP DATA)
  Future<void> deleteUserData() async {
    state = state.copyWith(isDeletingAccount: true, error: null);
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        await _authRepo.deleteUserData(currentUser);
        state = AuthState(); // Reset state after successful deletion
      } else {
        throw Exception('No user is currently signed in');
      }
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isDeletingAccount: false);
    }
  }

  //READ STATE (EMAIL IF EXISTS)
  Future<void> emailExists(String email) async {
    if (email.isEmpty) {
      state = state.copyWith(isEmailInFirestore: false);
      return;
    }
    try {
      final exists = await _authRepo.checkIfEmailExists(email);
      state = state.copyWith(isEmailInFirestore: exists);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  //READ STATE (USER EXISTS)
  Future<void> checkUserExists(String email) async {
    if (email.isEmpty) {
      state = state.copyWith(isEmailInFirestore: false);
      return;
    }
    try {
      final exists = await _authRepo.checkExistsUser(email);
      state = state.copyWith(isEmailInFirestore: exists);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    }
  }

  //READ STATE (FORGOT PASSWORD)
  Future<void> handleForgotPassword(String email) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      await _authRepo.handleForgotPassword(email);
      state = state.copyWith(error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //READ STATE (PASSWORD VALIDATION)
  void checkPassword(String password) {
    final validation = PasswordValidation(
      hasUppercase: RegExp(r'[A-Z]').hasMatch(password),
      hasLowercase: RegExp(r'[a-z]').hasMatch(password),
      hasNumber: RegExp(r'[0-9]').hasMatch(password),
      hasSpecialCharacter: RegExp(r'[!@#\$&*~]').hasMatch(password),
      isLongEnough: password.length == 8,
    );
    state = state.copyWith(passwordValidation: validation);
  }

  //UPDATE STATE (RESET PASSWORD)
  Future<void> resetPassword(String newPassword) async {
    state = state.copyWith(isLoading: true);
    try {
      await _authRepo.updatePassword(newPassword);
      state = state.copyWith(isLoading: false, error: null);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  //CREATE STATE (GOOGLE PROFILE)
  Future<void> createUser(User user, String firstName, String surname,
      String dob, String phoneNum) async {
    state = AuthState(user: user, isLoading: true);
    try {
      await _authRepo.createProfile(user, firstName, surname, dob, phoneNum);
      state = AuthState(user: user);
    } catch (e) {
      state = AuthState(user: user, error: e.toString());
    }
  }
} //END OF AuthStateNotifier CLASS
