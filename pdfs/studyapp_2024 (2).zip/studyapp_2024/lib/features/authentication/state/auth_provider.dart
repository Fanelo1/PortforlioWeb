// AuthService provider
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/features/authentication/data/auth_repo.dart';
import 'package:studyapp_2024/features/authentication/data/auth_service.dart';
import 'package:studyapp_2024/features/authentication/state/auth_state.dart';
import 'package:studyapp_2024/features/authentication/state/auth_state_notifier.dart';

final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService(FirebaseAuth.instance);
});

// AuthRepo provider
final authRepoProvider = Provider<AuthRepo>((ref) {
  final authService = ref.read(authServiceProvider);
  return AuthRepo(authService);
});

// AuthNotifier provider
final authNotifierProvider =
    StateNotifierProvider<AuthStateNotifier, AuthState>((ref) {
  final authRepo = ref.watch(authRepoProvider);
  return AuthStateNotifier(authRepo);
});
