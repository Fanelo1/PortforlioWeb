class Flashcard {
  final String id;
  final String question;
  final String answer;
  bool? isKnown;

  Flashcard({
    required this.id,
    required this.question,
    required this.answer,
    this.isKnown,
  });

  factory Flashcard.fromMap(Map<String, dynamic> map, String id) {
    return Flashcard(
      id: id,
      question: map['question'] ?? '',
      answer: map['answer'] ?? '',
      isKnown: map['isKnown'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'question': question,
      'answer': answer,
      'isKnown': isKnown,
    };
  }
}

class FlashcardSet {
  final String id;
  final String title;
  final String description;
  final String subject;
  List<Flashcard> flashcards;

  FlashcardSet({
    required this.id,
    required this.title,
    required this.description,
    required this.subject,
    this.flashcards = const [],
  });

  factory FlashcardSet.fromMap(Map<String, dynamic> map, String id) {
    return FlashcardSet(
      id: id,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      subject: map['subject'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'subject': subject,
    };
  }
}
