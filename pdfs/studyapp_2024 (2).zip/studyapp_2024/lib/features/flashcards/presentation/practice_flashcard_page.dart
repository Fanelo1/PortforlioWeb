import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/flashcards/model/flashcard_model.dart';
import 'package:studyapp_2024/features/flashcards/presentation/flashcard_results_page.dart';

class PracticeFlashcardPage extends StatefulWidget {
  final String setId;

  const PracticeFlashcardPage({super.key, required this.setId});

  @override
  _PracticeFlashcardPageState createState() => _PracticeFlashcardPageState();
}

class _PracticeFlashcardPageState extends State<PracticeFlashcardPage> {
  int currentIndex = 0;
  bool showingQuestion = true;
  List<Flashcard> flashcards = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFlashcards();
  }

  Future<void> _loadFlashcards() async {
    try {
      final QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('flashcardSets')
          .doc(widget.setId)
          .collection('flashcards')
          .get();

      if (mounted) {
        setState(() {
          flashcards = snapshot.docs
              .map((doc) =>
                  Flashcard.fromMap(doc.data() as Map<String, dynamic>, doc.id))
              .toList();
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading flashcards: $e')),
        );
      }
    }
  }

  void _handleKnowCard(bool knows) {
    setState(() {
      flashcards[currentIndex].isKnown = knows;
      currentIndex++;
      showingQuestion = true;

      if (currentIndex >= flashcards.length) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => FlashcardResultPage(flashcards: flashcards),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Practice Flashcards'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : flashcards.isEmpty
              ? const Center(
                  child: Text(
                    'No flashcards in this set',
                    style: TextStyle(fontSize: 18),
                  ),
                )
              : currentIndex >= flashcards.length
                  ? _buildCompletionScreen()
                  : _buildFlashcard(),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildFlashcard() {
    final Flashcard flashcard = flashcards[currentIndex];

    return GestureDetector(
      onTap: () => setState(() => showingQuestion = !showingQuestion),
      child: Card(
        elevation: 4,
        margin: const EdgeInsets.all(16),
        child: Container(
          padding: const EdgeInsets.all(24),
          width: double.infinity,
          height: MediaQuery.of(context).size.height * 0.6,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                showingQuestion ? flashcard.question : flashcard.answer,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Text(
                showingQuestion ? 'Tap to see answer' : 'Tap to see question',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey,
                    ),
              ),
              const SizedBox(height: 16),
              Text(
                'Card ${currentIndex + 1} of ${flashcards.length}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompletionScreen() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.check_circle_outline,
            size: 64,
            color: Colors.green,
          ),
          const SizedBox(height: 16),
          Text(
            'You completed the set!',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () => setState(() {
              currentIndex = 0;
              showingQuestion = true;
            }),
            child: const Text('Review Again'),
          ),
        ],
      ),
    );
  }

  Widget? _buildBottomBar() {
    if (flashcards.isEmpty || currentIndex >= flashcards.length) {
      return null;
    }

    return BottomAppBar(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            TextButton.icon(
              icon: const Icon(Icons.close),
              label: const Text('Did not know'),
              onPressed: () => _handleKnowCard(false),
              style: TextButton.styleFrom(foregroundColor: Colors.red),
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.check),
              label: const Text('Knew this'),
              onPressed: () => _handleKnowCard(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
