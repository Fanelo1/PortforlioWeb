import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/features/flashcards/model/flashcard_model.dart';

class FlashcardResultPage extends StatelessWidget {
  final List<Flashcard> flashcards;

  const FlashcardResultPage({
    super.key,
    required this.flashcards,
  });

  @override
  Widget build(BuildContext context) {
    final knownCards = flashcards.where((card) => card.isKnown == true).length;
    final unknownCards =
        flashcards.where((card) => card.isKnown == false).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Review Results'),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () =>
              Navigator.of(context).popUntil((route) => route.isFirst),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    'I know this term',
                    knownCards,
                    Colors.green,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildStatCard(
                    'I do not know this term',
                    unknownCards,
                    Colors.red,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: flashcards.length,
              itemBuilder: (context, index) {
                final card = flashcards[index];
                return ListTile(
                  leading: Text('${index + 1}'),
                  title: Text(card.question),
                  trailing: Icon(
                    card.isKnown == true ? Icons.check_circle : Icons.close,
                    color: card.isKnown == true ? Colors.green : Colors.red,
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              OutlinedButton(
                child: const Text('Review Again'),
                onPressed: () {
                  // Reset all cards' isKnown status
                  for (var card in flashcards) {
                    card.isKnown = null;
                  }
                  Navigator.pop(context);
                },
              ),
              ElevatedButton(
                child: const Text('Done'),
                onPressed: () => Navigator.pushNamed(
                    context, RouteManager.flashcardHomePage),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, int count, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              '$count',
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text('terms'),
          ],
        ),
      ),
    );
  }
}
