import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/flashcards/presentation/practice_flashcard_page.dart';

class AddFlashcardPage extends StatefulWidget {
  final String setId;

  const AddFlashcardPage({super.key, required this.setId});

  @override
  _AddFlashcardPageState createState() => _AddFlashcardPageState();
}

class _AddFlashcardPageState extends State<AddFlashcardPage> {
  final List<Map<String, TextEditingController>> _flashcardControllers = [];
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    // Start with one flashcard
    _addNewFlashcard();
  }

  void _addNewFlashcard() {
    setState(() {
      _flashcardControllers.add({
        'question': TextEditingController(),
        'answer': TextEditingController(),
      });
    });
  }

  @override
  void dispose() {
    for (var controllers in _flashcardControllers) {
      controllers['question']?.dispose();
      controllers['answer']?.dispose();
    }
    super.dispose();
  }

  Future<void> _saveFlashcards() async {
    if (!_formKey.currentState!.validate()) return;

    final batch = FirebaseFirestore.instance.batch();
    final flashcardsRef = FirebaseFirestore.instance
        .collection('flashcardSets')
        .doc(widget.setId)
        .collection('flashcards');

    for (var controllers in _flashcardControllers) {
      final newFlashcardRef = flashcardsRef.doc();
      batch.set(newFlashcardRef, {
        'question': controllers['question']!.text,
        'answer': controllers['answer']!.text,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }

    try {
      await batch.commit();
      if (mounted) {
        // Replace Navigator.pop with pushReplacement to PracticeFlashcardsScreen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => PracticeFlashcardPage(setId: widget.setId),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving flashcards: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Flashcards'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveFlashcards,
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: _flashcardControllers.length + 1, // +1 for the add button
          itemBuilder: (context, index) {
            if (index == _flashcardControllers.length) {
              return Center(
                child: TextButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text('Add Another Flashcard'),
                  onPressed: _addNewFlashcard,
                ),
              );
            }

            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('Flashcard ${index + 1}',
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _flashcardControllers[index]['question'],
                      decoration: const InputDecoration(
                        labelText: 'Question',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter a question'
                          : null,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _flashcardControllers[index]['answer'],
                      decoration: const InputDecoration(
                        labelText: 'Answer',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) => value?.isEmpty ?? true
                          ? 'Please enter an answer'
                          : null,
                    ),
                    if (_flashcardControllers.length > 1)
                      TextButton.icon(
                        icon: const Icon(Icons.delete),
                        label: const Text('Remove'),
                        onPressed: () {
                          setState(() {
                            var controllers =
                                _flashcardControllers.removeAt(index);
                            controllers['question']?.dispose();
                            controllers['answer']?.dispose();
                          });
                        },
                        style:
                            TextButton.styleFrom(foregroundColor: Colors.red),
                      ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
