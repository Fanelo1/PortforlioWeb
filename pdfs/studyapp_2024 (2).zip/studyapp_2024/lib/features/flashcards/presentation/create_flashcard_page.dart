// ignore_for_file: use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/flashcards/presentation/add_flashcard_page.dart';

class CreateFlashcardPage extends StatefulWidget {
  final String? setId;
  final bool isEditing;

  const CreateFlashcardPage({
    super.key,
    this.setId,
    this.isEditing = false,
  });

  @override
  _CreateFlashcardPageState createState() => _CreateFlashcardPageState();
}

class _CreateFlashcardPageState extends State<CreateFlashcardPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _subjectController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.isEditing && widget.setId != null) {
      _loadFlashcardSet();
    }
  }

  Future<void> _loadFlashcardSet() async {
    setState(() => _isLoading = true);
    try {
      final doc = await FirebaseFirestore.instance
          .collection('flashcardSets')
          .doc(widget.setId)
          .get();

      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        _titleController.text = data['title'] ?? '';
        _descriptionController.text = data['description'] ?? '';
        _subjectController.text = data['subject'] ?? '';
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading flashcard set: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            widget.isEditing ? 'Edit Flashcard Set' : 'Create Flashcard Set'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => _showDiscardDialog(context),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  TextFormField(
                    controller: _titleController,
                    decoration: const InputDecoration(
                      labelText: 'Title',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        value?.isEmpty ?? true ? 'Please enter a title' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _descriptionController,
                    decoration: const InputDecoration(
                      labelText: 'Description',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _subjectController,
                    decoration: const InputDecoration(
                      labelText: 'Subject',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
      bottomNavigationBar: BottomAppBar(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: () => _showDiscardDialog(context),
                style: TextButton.styleFrom(foregroundColor: Colors.red),
                child: const Text('Discard Set'),
              ),
              ElevatedButton(
                onPressed: _saveFlashcardSet,
                child: Text(widget.isEditing ? 'Update Set' : 'Save Set'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showDiscardDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(widget.isEditing
            ? 'Discard changes?'
            : 'Are you sure you want to delete this set?'),
        content: Text(widget.isEditing
            ? 'Any unsaved changes will be lost.'
            : 'This action cannot be undone.'),
        actions: [
          TextButton(
            child: const Text('Cancel'),
            onPressed: () => Navigator.pop(context),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close dialog
              Navigator.pop(context); // Go back to home
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: Text(widget.isEditing ? 'Discard' : 'Delete'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveFlashcardSet() async {
    if (_formKey.currentState!.validate()) {
      try {
        final data = {
          'title': _titleController.text,
          'description': _descriptionController.text,
          'subject': _subjectController.text,
          'updatedAt': FieldValue.serverTimestamp(),
        };

        if (widget.isEditing && widget.setId != null) {
          // Update existing set
          await FirebaseFirestore.instance
              .collection('flashcardSets')
              .doc(widget.setId)
              .update(data);

          Navigator.pop(context); // Go back to home screen
        } else {
          // Create new set
          data['createdAt'] = FieldValue.serverTimestamp();

          DocumentReference setRef = await FirebaseFirestore.instance
              .collection('flashcardSets')
              .add(data);

          // Navigate to add flashcards screen
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddFlashcardPage(setId: setRef.id),
            ),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(
                  'Error ${widget.isEditing ? 'updating' : 'creating'} flashcard set: $e')),
        );
      }
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _subjectController.dispose();
    super.dispose();
  }
}
