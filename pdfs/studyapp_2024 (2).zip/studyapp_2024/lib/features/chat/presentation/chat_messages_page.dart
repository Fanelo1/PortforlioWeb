// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: GroupChatPage CLASS (220024654, LK MAASDORP)
// PURPOSE: This class is responsible for displaying and managing the text messages within the group chat

import 'dart:async';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_messages/chat_message_field.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_messages/chat_message_tile.dart';
import 'package:studyapp_2024/features/chat/state/chat_provider.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';

class ChatMessagePage extends ConsumerStatefulWidget {
  final String groupId;
  final String groupName;

  const ChatMessagePage({
    super.key,
    required this.groupId,
    required this.groupName,
  });

  @override
  _GroupChatPageState createState() => _GroupChatPageState();
}

class _GroupChatPageState extends ConsumerState<ChatMessagePage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final User? _currentUser = FirebaseAuth.instance.currentUser;
  StreamSubscription<QuerySnapshot>? _messageSubscription;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _markAllMessagesAsRead();
  }

  void _sendMessage(String messageText) {
    if (messageText.trim().isNotEmpty) {
      ref.read(chatNotifierProvider.notifier).sendText(
            widget.groupId,
            messageText.trim(),
          );
      _messageController.clear();
    }
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image =
          await ImagePicker().pickImage(source: ImageSource.gallery);

      if (image != null) {
        setState(() {
          _isLoading = true;
        });

        await ref
            .read(chatNotifierProvider.notifier)
            .sendImg(widget.groupId, image);
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      print('Error picking image: $e');
    }
  }

  Future<void> _pickPdf() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );

    if (result != null && result.files.isNotEmpty) {
      XFile pdfFile = XFile(result.files.first.path!);

      await ref
          .read(chatNotifierProvider.notifier)
          .sendPdf(widget.groupId, pdfFile);
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _markAllMessagesAsRead() {
    final userId = _currentUser!.uid;
    _messageSubscription = ref
        .read(chatNotifierProvider.notifier)
        .getGroupMessages(widget.groupId)
        .listen((snapshot) {
      for (var message in snapshot.docs) {
        if (!message['ReadBy'].contains(userId)) {
          ref
              .read(chatNotifierProvider.notifier)
              .markTextRead(widget.groupId, message.id);
        }
      }
    });
  }

  @override
  void dispose() {
    _messageSubscription?.cancel();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(
        title: Text(widget.groupName),
        actions: const [],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
        child: Column(
          children: [
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: ref
                    .read(chatNotifierProvider.notifier)
                    .getGroupMessages(widget.groupId),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final messages = snapshot.data!.docs;
                  DateTime? lastDisplayedDate;

                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (_scrollController.hasClients) {
                      _scrollController
                          .jumpTo(_scrollController.position.maxScrollExtent);
                    }
                  });

                  return ListView.builder(
                    controller: _scrollController,
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final messageData =
                          messages[index].data() as Map<String, dynamic>;
                      final isMe = messageData['User ID'] == _currentUser!.uid;

                      // Get previous message data for comparison
                      final previousMessageData = index > 0
                          ? messages[index - 1].data() as Map<String, dynamic>
                          : null;

                      final Timestamp? sentAt =
                          messageData['Sent At'] as Timestamp?;
                      final DateTime dateTime =
                          sentAt?.toDate() ?? DateTime.now();
                      String dateHeader;
                      final DateFormat dateFormat =
                          DateFormat('EEE, d MMM yyyy');
                      final DateTime now = DateTime.now();
                      final DateTime yesterday =
                          now.subtract(const Duration(days: 1));

                      if (DateUtils.isSameDay(dateTime, now)) {
                        dateHeader = 'TODAY';
                      } else if (DateUtils.isSameDay(dateTime, yesterday)) {
                        dateHeader = 'YESTERDAY';
                      } else {
                        dateHeader = dateFormat.format(dateTime);
                      }

                      if (lastDisplayedDate == null ||
                          !DateUtils.isSameDay(dateTime, lastDisplayedDate)) {
                        lastDisplayedDate = dateTime;

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 10.0),
                              child: Center(
                                child: Text(
                                  '• $dateHeader •',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                            ),
                            MessageTile(
                              messageData: messageData,
                              isMe: isMe,
                              groupId: widget.groupId, // Add this
                              previousMessageData: previousMessageData,
                              messageId: messages[index].id,
                            ),
                          ],
                        );
                      } else {
                        return MessageTile(
                          messageData: messageData,
                          isMe: isMe,
                          groupId: widget.groupId,
                          previousMessageData: previousMessageData,
                          messageId: messages[index].id,
                        );
                      }
                    },
                  );
                },
              ),
            ),
            if (_isLoading)
              const Center(
                child: CircularProgressIndicator(),
              ),
            MessageField(
              onSendMessage: _sendMessage,
              onPickImage: _pickImage,
              onPickPdf: _pickPdf,
            ),
          ],
        ),
      ),
    );
  }
}
