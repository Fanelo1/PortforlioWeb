// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: GroupInfoPage CLASS (220024654 LK MAASDORP)
// PURPOSE: This class is responsible for displaying the members of the group chat

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_info/chat_add_member.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/widgets/dividers/my_left_divider.dart';

class ChatInfoPage extends StatefulWidget {
  final String groupId;
  final String groupName;

  const ChatInfoPage({
    super.key,
    required this.groupId,
    required this.groupName,
  });

  @override
  State<ChatInfoPage> createState() => _ChatInfoPageState();
}

class _ChatInfoPageState extends State<ChatInfoPage> {
  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var avatarRadius = screenWidth * 0.12;
    var fontSizeTitle = screenWidth * 0.06;
    var paddingHorizontal = screenWidth * 0.05;
    var paddingVertical = screenHeight * 0.03;
    var buttonHeight = screenHeight * 0.06;
    var fontSizeDivider = screenWidth * 0.04;

    return Scaffold(
      appBar: MyAppBar(
        onLeadingIconPressed: () {
          Navigator.pushNamed(context, RouteManager.chatHomePage);
        },
        title: Text('${widget.groupName} Group Info'),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: paddingHorizontal,
          vertical: paddingVertical,
        ),
        child: Column(
          children: [
            Column(
              children: [
                CircleAvatar(
                  radius: avatarRadius,
                  backgroundColor: Colors.blue,
                  child: const Icon(
                    CupertinoIcons.group_solid,
                    size: 40,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),
                Text(
                  widget.groupName,
                  style: TextStyle(
                    fontSize: fontSizeTitle,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),
                /*TextButton.icon(
                  onPressed: () async {
                    // Display a dialog to enter a new group name
                    String? newGroupName = await showDialog<String>(
                      context: context,
                      builder: (context) =>
                          EditGroupNameDialog(currentName: widget.groupName),
                    );

                    if (newGroupName != null && newGroupName.isNotEmpty) {
                      // Update the group name using ChatService
                      await ChatService().updateGroupName(
                        groupId: widget.groupId,
                        newGroupName: newGroupName,
                      );

                      setState(() {
                        // Update the local state with the new group name
                        widget.groupName = newGroupName;
                      });
                    }
                  },
                  icon: const Icon(
                    CupertinoIcons.pencil,
                    color: Colors.blue,
                  ),
                  label: const Text(
                    'Edit Group Name',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),*/
              ],
            ),
            SizedBox(height: screenHeight * 0.03),
            MyLeftDivider(
                dividerText: 'Group Members', fontSize: fontSizeDivider),
            SizedBox(height: screenHeight * 0.02),

            //----- DISPLAY ALL GROUP MEMBERS & THEIR DETAILS -----//
            Expanded(
              child: StreamBuilder<DocumentSnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('groupChats')
                    .doc(widget.groupId)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return const Center(
                      child: Text('Error loading members'),
                    );
                  }

                  if (!snapshot.hasData || !snapshot.data!.exists) {
                    return const Center(
                      child: Text('Group not found'),
                    );
                  }

                  var groupData = snapshot.data!.data() as Map<String, dynamic>;
                  var members = groupData['Group Members'] as List<dynamic>;

                  var memberIds =
                      members.map((member) => member['userId']).toList();

                  return StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('users')
                        .where(FieldPath.documentId, whereIn: memberIds)
                        .snapshots(),
                    builder: (context, memberSnapshot) {
                      if (memberSnapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      if (memberSnapshot.hasError) {
                        return const Center(
                            child: Text('Error loading member details'));
                      }

                      if (!memberSnapshot.hasData ||
                          memberSnapshot.data!.docs.isEmpty) {
                        return const Center(
                            child: Text('No members in this group'));
                      }

                      var memberDocs = memberSnapshot.data!.docs;

                      return ListView.builder(
                        itemCount: memberDocs.length,
                        itemBuilder: (context, index) {
                          var member = memberDocs[index];
                          var firstName = member['Firstname'] ?? 'Unknown';
                          var surname = member['Surname'] ?? '';
                          var fullName = '$firstName $surname';

                          var currentUserId =
                              FirebaseAuth.instance.currentUser?.uid;
                          var isCurrentUser = member.id == currentUserId;

                          return ListTile(
                            leading: CircleAvatar(
                              backgroundColor: Colors.grey[300],
                              child: const Icon(CupertinoIcons.person),
                            ),
                            title: Text(
                                isCurrentUser ? '$fullName (You)' : fullName),
                            onTap: () {
                              Navigator.pushNamed(
                                context,
                                RouteManager.memberDetails,
                                arguments: {
                                  'userId': member.id,
                                  'groupId': widget.groupId,
                                  'groupName': widget.groupName,
                                },
                              );
                            },
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  height: buttonHeight,

                  //----- ADD MEMBER BUTTON -----//
                  child: MyButton(
                    buttonTitle: 'Add a Member',
                    buttonType: ButtonType.bordered,
                    icon: CupertinoIcons.add_circled,
                    onTap: () {
                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (context) {
                          return AddMemberDialog(
                            groupId: widget.groupId,
                            groupName: widget.groupName,
                          );
                        },
                      );
                    },
                    color: Colors.blue,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
} //END OF GroupInfoPage CLASS
