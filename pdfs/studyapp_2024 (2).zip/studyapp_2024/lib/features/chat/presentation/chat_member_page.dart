// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MemberDetailsPage CLASS (220024654 LK MAASDORP)
// PURPOSE: This class is responsible for displaying the user details of the group member

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';

class ChatMemberPage extends StatelessWidget {
  final String userId;
  final String groupId;
  final String groupName;

  const ChatMemberPage({
    super.key,
    required this.userId,
    required this.groupId,
    required this.groupName,
  });

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var avatarRadius = screenWidth * 0.12;
    var fontSizeTitle = screenWidth * 0.06;
    var paddingHorizontal = screenWidth * 0.05;
    var paddingVertical = screenHeight * 0.03;

    var currentUserId = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      appBar: MyAppBar(
        title: const Text('Member Details'),
        onLeadingIconPressed: () {},
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future:
            FirebaseFirestore.instance.collection('users').doc(userId).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(
              child: Text('Error loading user details'),
            );
          }

          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(
              child: Text('User not found'),
            );
          }

          // Extract user details
          var userData = snapshot.data!.data() as Map<String, dynamic>;
          var firstName = userData['Firstname'] ?? 'Firstname not available';
          var surname = userData['Surname'] ?? 'Surname not available';
          var email =
              userData['Email Address'] ?? 'Email Address not available';
          var contactNumber =
              userData['Contact Number'] ?? 'Contact Number not available';

          return Padding(
            padding: EdgeInsets.symmetric(
              horizontal: paddingHorizontal,
              vertical: paddingVertical,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: avatarRadius,
                  backgroundColor: Colors.blue,
                  child: const Icon(
                    CupertinoIcons.person,
                    size: 40,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),

                Text(
                  '$firstName $surname',
                  style: TextStyle(
                    fontSize: fontSizeTitle,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: screenHeight * 0.04), // Dynamic spacing
                //----- DISPLAYING THE USER'S EMAIL ADDRESS IN A TEXTFORMFIELD -----//
                TextFormField(
                  initialValue: email,
                  decoration: formDecoration('Email Address', Icons.mail),
                  readOnly: true,
                ),
                SizedBox(height: screenHeight * 0.02), // Dynamic spacing
                //----- DISPLAYING THE USER'S CONTACT NUMBER IN A TEXTFORMFIELD -----//
                TextFormField(
                  initialValue: contactNumber,
                  decoration: formDecoration('Contact Number', Icons.phone),
                  readOnly: true,
                ),
                SizedBox(height: screenHeight * 0.04), // Dynamic spacing
                if (currentUserId != userId)
                  MyButton(
                    buttonTitle: 'REPORT USER',
                    buttonType: ButtonType.bordered,
                    icon: Icons.campaign_outlined,
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        RouteManager.userReportPage,
                        arguments: {
                          'userId': userId,
                          'groupId': groupId,
                          'groupName': groupName,
                        },
                      );
                    },
                    color: Colors.red,
                  )
                else
                  const Center(
                    child: Text(
                      'You cannot report yourself',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
