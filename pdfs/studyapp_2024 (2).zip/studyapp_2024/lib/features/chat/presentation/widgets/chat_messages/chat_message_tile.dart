import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_messages/chat_pdf_card.dart';
import 'package:studyapp_2024/features/chat/state/chat_provider.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_messages/chat_img_card.dart';

class MessageTile extends ConsumerWidget {
  final Map<String, dynamic> messageData;
  final bool isMe;
  final Map<String, dynamic>? previousMessageData;
  final String groupId;
  final String messageId;

  const MessageTile({
    super.key,
    required this.messageData,
    required this.isMe,
    this.previousMessageData,
    required this.groupId,
    required this.messageId,
  });

  void _showDeleteDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Message'),
        content: const Text('Are you sure you want to delete this message?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await ref
                  .read(chatNotifierProvider.notifier)
                  .deleteMessage(groupId, messageId); // Use messageId here
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bool hasImage =
        messageData.containsKey('ImageURL') && messageData['ImageURL'] != null;
    final bool hasPdf =
        messageData.containsKey('PdfURL') && messageData['PdfURL'] != null;
    final Timestamp? sentAt = messageData['Sent At'] as Timestamp?;
    final DateTime dateTime = sentAt?.toDate() ?? DateTime.now();

    final bool isNewDay = previousMessageData != null &&
        DateFormat('yyyy-MM-dd')
                .format(previousMessageData!['Sent At'].toDate()) !=
            DateFormat('yyyy-MM-dd').format(dateTime);

    final bool shouldHideUsername = previousMessageData != null &&
        previousMessageData!['User ID'] == messageData['User ID'] &&
        !isNewDay;

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: isMe ? () => _showDeleteDialog(context, ref) : null,
        child: Container(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.7,
          ),
          padding: const EdgeInsets.all(10),
          margin: const EdgeInsets.symmetric(vertical: 5),
          decoration: BoxDecoration(
            color: isMe
                ? const Color.fromARGB(255, 186, 215, 249)
                : Colors.grey[300],
            borderRadius: shouldHideUsername
                ? BorderRadius.circular(10) // All corners rounded if same owner
                : BorderRadius.only(
                    topLeft: const Radius.circular(10),
                    topRight: const Radius.circular(10),
                    bottomLeft: isMe ? const Radius.circular(10) : Radius.zero,
                    bottomRight: isMe ? Radius.zero : const Radius.circular(10),
                  ),
          ),
          child: Column(
            crossAxisAlignment:
                isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              if (!shouldHideUsername)
                FutureBuilder<String>(
                  future: ref
                      .read(chatNotifierProvider.notifier)
                      .getNameUser(messageData['User ID']),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting ||
                        !snapshot.hasData) {
                      return const Text('Loading...');
                    }
                    return Text(
                      isMe ? 'You' : snapshot.data!,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontStyle: isMe ? FontStyle.italic : FontStyle.normal,
                      ),
                    );
                  },
                ),
              const SizedBox(height: 5),
              if (hasImage)
                ImageCard(
                  imageAssetName: messageData['ImageURL'] ?? '',
                ),
              if (hasPdf)
                PdfCard(
                  fileName: messageData['FileName'] ?? 'Unknown PDF',
                  date: dateTime,
                  size: messageData['FileSize'] ?? 'Unknown Size',
                  groupId: messageData['GroupID'] ?? '',
                  pdfUrl: messageData['PdfURL'] ?? '',
                  isSending: ref
                      .watch(chatNotifierProvider.notifier)
                      .isSendingPdf(messageData['PdfURL']),
                ),
              if (!hasImage && !hasPdf)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (messageData['isDeleted'] == true)
                      const Icon(
                        Icons
                            .cancel_outlined, // or Icons.block for a different style
                        size: 16,
                        color: Colors.grey,
                      ),
                    const SizedBox(
                        width: 4), // Add some spacing between icon and text
                    Text(
                      messageData['isDeleted'] == true
                          ? 'Deleted Message'
                          : (messageData['Message'] ?? 'No message'),
                      style: TextStyle(
                        color: messageData['isDeleted'] == true
                            ? Colors.grey
                            : (isMe ? Colors.white : Colors.black),
                        fontStyle: messageData['isDeleted'] == true
                            ? FontStyle.italic
                            : FontStyle.normal,
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 5),
              Text(
                DateFormat('h:mm a').format(dateTime),
                style: TextStyle(
                  fontSize: 10,
                  color: isMe ? Colors.white70 : Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
