import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:studyapp_2024/components/form_decorations.dart';

class ChatSearchBar extends StatelessWidget {
  final Function(String) onChanged;
  final double fontSize;

  const ChatSearchBar({
    super.key,
    required this.onChanged,
    required this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: TextField(
        decoration: formDecoration('Search', CupertinoIcons.search),
        onChanged: onChanged,
        style: TextStyle(fontSize: fontSize),
      ),
    );
  }
}
