//import 'package:flutter/material.dart';

/*
class EditGroupNameDialog extends StatelessWidget {
  final String currentName;
  final TextEditingController nameController;

  EditGroupNameDialog({super.key, required this.currentName})
      : nameController = TextEditingController(text: currentName);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Edit Group Name'),
      content: TextField(
        controller: nameController,
        decoration: const InputDecoration(
          hintText: 'Enter new group name',
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context); // Close the dialog without saving
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            // Return the new group name from the dialog
            Navigator.pop(context, nameController.text);
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}
*/