import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class SortButton extends StatelessWidget {
  final bool isAscending;
  final VoidCallback onPressed;
  final double fontSize;

  const SortButton({
    super.key,
    required this.isAscending,
    required this.onPressed,
    required this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: AnimatedSwitcher(
        duration: const Duration(milliseconds: 350),
        transitionBuilder: (Widget child, Animation<double> animation) {
          return ScaleTransition(scale: animation, child: child);
        },
        child: Icon(
          isAscending ? CupertinoIcons.sort_up : CupertinoIcons.sort_down,
          key: ValueKey<bool>(isAscending),
          color: Colors.grey,
          size: fontSize * 1.2,
        ),
      ),
      onPressed: onPressed,
    );
  }
}
