import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/components/form_validations.dart';
import 'package:studyapp_2024/features/chat/state/chat_provider.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';

class AddMemberDialog extends ConsumerStatefulWidget {
  final String groupId;
  final String groupName;

  const AddMemberDialog({
    super.key,
    required this.groupId,
    required this.groupName,
  });

  @override
  _AddMemberDialogState createState() => _AddMemberDialogState();
}

class _AddMemberDialogState extends ConsumerState<AddMemberDialog> {
  final TextEditingController _emailController = TextEditingController();
  bool _isLoading = false;
  bool _isUserFound = false;

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _searchUser() async {
    setState(() {
      _isLoading = true;
      _isUserFound = false;
    });

    String email = _emailController.text.trim().toLowerCase();

    try {
      var userSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('Email Address', isEqualTo: email)
          .get();

      if (userSnapshot.docs.isNotEmpty) {
        setState(() {
          _isUserFound = true;
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('User not found.')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }

    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _addUserToGroup() async {
    setState(() {
      _isLoading = true;
    });

    String email = _emailController.text.trim();
    if (email.isNotEmpty) {
      // Use the Riverpod provider to get ChatService
      final chatService = ref.read(chatServiceProvider);

      await chatService.addUserToGroupChat(
        groupId: widget.groupId,
        groupName: widget.groupName,
        inviteeEmail: email,
      );

      if (mounted) {
        Navigator.of(context).pop();

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) {
            return const MyDialogBox(
              title: 'Success!',
              content: Text('Member successfully added to group!'),
              icon: CupertinoIcons.person_crop_circle_badge_checkmark,
              iconColor: Colors.green,
              hideCloseButton: false,
            );
          },
        );
      }
    }

    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Center(child: Text('Add Member')),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              CupertinoIcons.person_add_solid,
              color: Colors.blue,
              size: 50,
            ),
            const SizedBox(
              height: 20,
            ),
            TextFormField(
              keyboardType: TextInputType.emailAddress,
              controller: _emailController,
              decoration: formDecoration(
                'Search User by Email',
                Icons.search_rounded,
              ),
              validator: validateEmail,
            ),
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.only(top: 10),
                child: CircularProgressIndicator(),
              ),
            if (_isUserFound)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: ListTile(
                  leading: const Icon(
                    Icons.check_circle_outline,
                    color: Colors.green,
                  ),
                  title: const Text('User found. Add to group?'),
                  subtitle: Text(_emailController.text),
                ),
              ),
          ],
        ),
      ),
      actions: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            MyButton(
              buttonTitle: 'Cancel',
              buttonType: ButtonType.bordered,
              onTap: () {
                Navigator.pop(context);
              },
              color: Colors.red,
            ),
            MyButton(
              buttonTitle: _isUserFound ? 'Add to Group' : 'Search',
              buttonType: ButtonType.filled,
              onTap: _isLoading
                  ? null
                  : (_isUserFound ? _addUserToGroup : _searchUser),
              color: Colors.blue,
            ),
          ],
        ),
      ],
    );
  }
}
