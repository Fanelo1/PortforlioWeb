// chat_group_tile.dart
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:studyapp_2024/widgets/my_list_tile.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_messages_page.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_info_page.dart';

class ChatGroupTile extends StatelessWidget {
  final String groupName;
  final String groupId;
  final Color containerColor;
  final Function(BuildContext) showColorDialog;

  const ChatGroupTile({
    super.key,
    required this.groupName,
    required this.groupId,
    required this.containerColor,
    required this.showColorDialog,
  });

  @override
  Widget build(BuildContext context) {
    return MyListTile(
      title: groupName,
      leadingIcon: FontAwesomeIcons.peopleGroup,
      leadingIconColor: Colors.white,
      trailingIcon: Icons.more_vert,
      trailingIconColor: Colors.blue,
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ChatMessagePage(
              groupId: groupId,
              groupName: groupName,
            ),
          ),
        );
      },
      popupMenuItems: const [
        PopupMenuItem<String>(
          value: 'info',
          child: Row(
            children: [
              Icon(CupertinoIcons.info, color: Colors.blue),
              SizedBox(width: 8),
              Text(
                'Group info',
                style: TextStyle(
                  color: Color.fromARGB(255, 9, 87, 150),
                ),
              ),
            ],
          ),
        ),
      ],
      onSelected: (value) {
        if (value == 'info') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChatInfoPage(
                groupId: groupId,
                groupName: groupName,
              ),
            ),
          );
        }
      },
      containerColor: containerColor,
    );
  }
}
