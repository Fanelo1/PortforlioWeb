import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class MessageField extends ConsumerStatefulWidget {
  final Function(String) onSendMessage;
  final VoidCallback onPickImage;
  final VoidCallback onPickPdf;

  const MessageField({
    super.key,
    required this.onSendMessage,
    required this.onPickImage,
    required this.onPickPdf,
  });

  @override
  MessageFieldState createState() => MessageFieldState();
}

class MessageFieldState extends ConsumerState<MessageField> {
  final TextEditingController _messageController = TextEditingController();
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _messageController.addListener(() {
      setState(() {
        _isTyping = _messageController.text.isNotEmpty;
      });
    });
  }

  void _sendMessage() {
    if (_messageController.text.isNotEmpty) {
      widget.onSendMessage(_messageController.text.trim());
      _messageController.clear();
    }
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      offset: const Offset(0, 3),
                      blurRadius: 5,
                      color: Colors.grey.withOpacity(0.5),
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: Container(
                        constraints: const BoxConstraints(maxHeight: 100),
                        child: SingleChildScrollView(
                          child: TextField(
                            controller: _messageController,
                            maxLines: null,
                            decoration: const InputDecoration(
                              hintText: 'Type Something...',
                              hintStyle: TextStyle(color: Colors.grey),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                vertical: 10.0,
                                horizontal: 15.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Row(
                        children: [
                          IconButton(
                            icon: const Icon(
                              CupertinoIcons.photo,
                              color: Colors.grey,
                            ),
                            onPressed: widget.onPickImage,
                          ),
                          IconButton(
                            icon: const Icon(
                              CupertinoIcons.paperclip,
                              color: Colors.grey,
                            ),
                            onPressed: widget
                                .onPickPdf, // Add file attachment logic here
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 15),
            if (_isTyping)
              IconButton(
                icon: const Icon(
                  CupertinoIcons.paperplane_fill,
                  color: Colors.blue,
                ),
                onPressed: _sendMessage,
              ),
          ],
        ),
      ],
    );
  }
}
