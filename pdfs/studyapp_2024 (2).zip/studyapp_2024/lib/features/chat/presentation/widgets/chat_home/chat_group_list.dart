// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: GroupChatList CLASS (220024654_LK Maasdorp)
// PURPOSE: A custom widget that displays all the current user's group chats in a listview

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:studyapp_2024/features/chat/data/chat_service.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_info_page.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_messages_page.dart';
import 'package:studyapp_2024/widgets/my_list_tile.dart';

class GroupChatList extends StatefulWidget {
  const GroupChatList({
    super.key,
    required ChatService chatService,
    required String searchQuery,
    required bool isAscending,
  })  : _chatService = chatService,
        _searchQuery = searchQuery,
        _isAscending = isAscending;

  final ChatService _chatService;
  final String _searchQuery;
  final bool _isAscending;

  @override
  State<GroupChatList> createState() => _GroupChatListState();
}

class _GroupChatListState extends State<GroupChatList> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: StreamBuilder<QuerySnapshot>(
        stream: widget._chatService.getGroupChats(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(child: Text('Error loading groups'));
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No groups available'));
          }

          var groups = snapshot.data!.docs;
          var filteredGroups = groups.where((group) {
            var groupName = group['Group Name'].toLowerCase();
            return groupName.contains(widget._searchQuery.toLowerCase());
          }).toList();

          filteredGroups.sort((a, b) {
            var groupNameA = a['Group Name'].toLowerCase();
            var groupNameB = b['Group Name'].toLowerCase();
            return widget._isAscending
                ? groupNameA.compareTo(groupNameB)
                : groupNameB.compareTo(groupNameA);
          });

          return ListView.separated(
            itemCount: filteredGroups.length,
            separatorBuilder: (context, index) => const SizedBox(height: 20),
            itemBuilder: (context, index) {
              var group = filteredGroups[index];
              var groupName = group['Group Name'];
              var groupId = group.id;

              return MyListTile(
                title: groupName,

                leadingIcon: FontAwesomeIcons.peopleGroup,
                leadingIconColor: Colors.white,
                trailingIcon: Icons.more_vert,
                trailingIconColor: Colors.blue,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return ChatMessagePage(
                          groupId: groupId,
                          groupName: groupName,
                        );
                      },
                    ),
                  );
                },

                //----- GROUP INFO BUTTON -----//
                popupMenuItems: const [
                  PopupMenuItem<String>(
                    value: 'info',
                    child: Row(
                      children: [
                        Icon(CupertinoIcons.info, color: Colors.blue),
                        SizedBox(width: 8),
                        Text(
                          'Group info',
                          style:
                              TextStyle(color: Color.fromARGB(255, 9, 87, 150)),
                        ),
                      ],
                    ),
                  ),
                ],

                //----- NAVIGATES TO GROUP INFO PAGE -----//
                onSelected: (value) {
                  if (value == 'info') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ChatInfoPage(
                          groupId: groupId,
                          groupName: groupName,
                        ),
                      ),
                    );
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
} // END OF GroupChatList WIDGET
