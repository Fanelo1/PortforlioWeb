import 'package:flutter/material.dart';

class ImageFullPage extends StatelessWidget {
  final String imageAssetName;

  const ImageFullPage(this.imageAssetName, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      backgroundColor: Colors.black,
      body: Center(
        child: GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Image.network(
            imageAssetName,
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }
}
