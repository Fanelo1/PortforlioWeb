// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: ReportUserPage CLASS (220024654, LK MAASDORP)
// PURPOSE:

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';

class ChatReportPage extends StatefulWidget {
  final String userId;
  final String groupId;
  final String groupName;

  const ChatReportPage({
    super.key,
    required this.userId,
    required this.groupId,
    required this.groupName,
  });

  @override
  _ChatReportPageState createState() => _ChatReportPageState();
}

class _ChatReportPageState extends State<ChatReportPage> {
  String? selectedReason;
  bool isOtherSelected = false;
  final TextEditingController otherReasonController = TextEditingController();

  final List<String> reasons = [
    'Inappropriate Language',
    'Harassment',
    'Other...'
  ];

  @override
  void dispose() {
    otherReasonController.dispose();
    super.dispose();
  }

  Future<void> reportMember(BuildContext context) async {
    try {
      // Get the current user's ID (reporter)
      String currentUserId = FirebaseAuth.instance.currentUser!.uid;

      // Fetch the reporter's full name
      var reporterDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUserId)
          .get();
      var reporterData = reporterDoc.data();

      var reporterFullName = (reporterData?['Firstname'] ?? 'Unknown') +
          ' ' +
          (reporterData?['Surname'] ?? '');

      // Fetch the reported user's full name
      var reportedUserDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .get();
      var reportedUserData = reportedUserDoc.data();

      var reportedFullName = (reportedUserData?['Firstname'] ?? 'Unknown') +
          ' ' +
          (reportedUserData?['Surname'] ?? '');

      String reason = selectedReason == 'Other...'
          ? otherReasonController.text
          : selectedReason ?? 'No reason specified';

      // Save the report to Firestore with combined names
      await FirebaseFirestore.instance.collection('reports').add({
        'Reported UserID': widget.userId,
        'Reported User': reportedFullName,
        'Reported At': Timestamp.now(),
        'Reported By UserID': currentUserId,
        'Reported By': reporterFullName,
        'Reason': reason,
        'Group ID': widget.groupId,
        'Group Name': widget.groupName,
      });

      if (context.mounted) {
        Navigator.of(context).pop();

        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => MyDialogBox(
            title: 'Report Sent!',
            content: const Text(
              'Intelli-Ed will review the report snd take the appropriate actions after reviewing.',
              textAlign: TextAlign.center,
            ),
            icon: CupertinoIcons.checkmark_alt_circle,
            iconColor: Colors.green,
            hideCloseButton: true,
            buttons: [
              MyButton(
                buttonTitle: 'Back to Member Details',
                buttonType: ButtonType.filled,
                onTap: () {
                  Navigator.of(context).pop();
                },
                color: Colors.blue,
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error reporting member: $e')),
          );
        }
      }
    }
  }

  //----- SHOW CONFIRMATION DIALOG ON BACK BUTTON PRESS -----//
  Future<bool> _onWillPop() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
              'Go Back? No changes in report will be saved, continue?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(true); // Return true when confirmed
                Navigator.pop(context);
              },
              child: const Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false); // Return false when declined
              },
              child: const Text('No'),
            ),
          ],
        );
      },
    );
    return result ?? false; // Ensure a boolean value is returned
  }

  @override
  Widget build(BuildContext context) {
    // Responsive UI Variables
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;
    var padding = screenWidth * 0.05;
    var buttonHeight = screenHeight * 0.06;
    var fontSizeDropdown = screenWidth * 0.045;
    var fontSizeInput = screenWidth * 0.04;

    return WillPopScope(
      onWillPop: () async => _onWillPop(),
      child: Scaffold(
        appBar: MyAppBar(
          title: const Text('Report User'),
          onBackButtonPressed: () async {
            bool shouldPop = await _onWillPop();
            if (shouldPop) {
              if (context.mounted) {
                Navigator.of(context).pop();
              }
            }
          },
        ),
        body: Padding(
          padding: EdgeInsets.all(padding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Dropdown for selecting reason
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: 'Reason',
                  border: OutlineInputBorder(),
                ),
                value: selectedReason,
                items: reasons.map((String reason) {
                  return DropdownMenuItem<String>(
                    value: reason,
                    child: Text(reason,
                        style: TextStyle(fontSize: fontSizeDropdown)),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedReason = value;
                    isOtherSelected = value == 'Other...';
                  });
                },
              ),
              SizedBox(height: screenHeight * 0.02), // Dynamic spacing
              // Text field for 'Other' reason input
              if (isOtherSelected)
                TextFormField(
                  controller: otherReasonController,
                  maxLines: 3,
                  style: TextStyle(fontSize: fontSizeInput),
                  decoration: const InputDecoration(
                    hintText: 'Give a reason...',
                    border: OutlineInputBorder(),
                  ),
                ),
              const Spacer(),
              // Cancel and Send Report buttons
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: buttonHeight,
                      child: MyButton(
                        buttonType: ButtonType.bordered,
                        icon: CupertinoIcons.xmark,
                        buttonTitle: 'Cancel',
                        onTap: () {
                          Navigator.pop(context);
                        },
                        color: Colors.red,
                      ),
                    ),
                  ),
                  SizedBox(width: screenWidth * 0.04), // Dynamic spacing
                  Expanded(
                    child: SizedBox(
                      height: buttonHeight,
                      child: MyButton(
                        buttonType: ButtonType.filled,
                        icon: CupertinoIcons.paperplane,
                        buttonTitle: 'Send Report',
                        onTap: () {
                          if (selectedReason != null) {
                            reportMember(context);
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Please select a reason'),
                              ),
                            );
                          }
                        },
                        color: Colors.blue,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
