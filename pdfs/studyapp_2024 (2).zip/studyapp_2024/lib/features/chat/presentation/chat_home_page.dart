import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/components/form_decorations.dart';
import 'package:studyapp_2024/features/chat/data/chat_service.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_home/chat_group_list.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_home/chat_search_bar.dart';
import 'package:studyapp_2024/features/chat/presentation/widgets/chat_home/chat_sort_button.dart';
import 'package:studyapp_2024/features/chat/state/chat_provider.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';
import 'package:studyapp_2024/widgets/dividers/my_left_divider.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';
import 'package:studyapp_2024/widgets/buttons/my_float_button.dart';

class ChatHomePage extends ConsumerStatefulWidget {
  const ChatHomePage({super.key});

  @override
  ConsumerState<ChatHomePage> createState() => _ChatHomePageState();
}

class _ChatHomePageState extends ConsumerState<ChatHomePage> {
  final _groupNameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final chatState = ref.watch(chatNotifierProvider);
    final chatNotifier = ref.read(chatNotifierProvider.notifier);
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final paddingHorizontal = screenWidth * 0.05;
    final paddingVertical = screenHeight * 0.03;
    final fontSize = screenWidth * 0.045;

    // Function to create a new chat group
    Future<void> _createGroup() async {
      String groupName = _groupNameController.text.trim();
      if (groupName.isNotEmpty) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) =>
              const Center(child: CircularProgressIndicator()),
        );

        try {
          await chatNotifier.createChatGroup(groupName, context);
          if (context.mounted) {
            Navigator.of(context).pop();
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (context) => MyDialogBox(
                title: 'Success',
                content: const Text('Group successfully created!',
                    textAlign: TextAlign.center),
                icon: CupertinoIcons.checkmark_alt_circle,
                iconColor: Colors.green,
                hideCloseButton: true,
                buttons: [
                  MyButton(
                    buttonTitle: 'Back to all Chats',
                    buttonType: ButtonType.filled,
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    color: Colors.blue,
                  ),
                ],
              ),
            );
          }
        } catch (e) {
          if (context.mounted) {
            Navigator.of(context).pop();
            showDialog(
              context: context,
              builder: (context) => const MyDialogBox(
                title: 'Error',
                content: Text('Failed to create group. Please try again.'),
                icon: CupertinoIcons.exclamationmark_circle,
                iconColor: Colors.red,
                hideCloseButton: true,
              ),
            );
          }
        } finally {
          _groupNameController.clear();
        }
      }
    }

    return Scaffold(
      appBar: MyAppBar(
        onLeadingIconPressed: () {
          Navigator.pushNamed(context, RouteManager.studMainPage);
        },
        title: Text(
          'All Chats',
          style: TextStyle(fontSize: fontSize * 1.2),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: paddingHorizontal, vertical: paddingVertical),
          child: Column(
            children: [
              // First Column with search bar and divider
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      ChatSearchBar(
                        onChanged: (query) {
                          chatNotifier.updateSearchQuery(query);
                        },
                        fontSize: fontSize,
                      ),
                      SortButton(
                        isAscending: chatState.isAscending,
                        onPressed: chatNotifier.toggleSortOrder,
                        fontSize: fontSize,
                      ),
                    ],
                  ),
                  SizedBox(height: paddingVertical),
                  MyLeftDivider(
                    dividerText: 'Conversations',
                    fontSize: fontSize,
                  ),
                  SizedBox(height: paddingVertical * 0.5),
                ],
              ),
              // GroupChatList outside the first Column
              GroupChatList(
                searchQuery: chatState.searchQuery,
                isAscending: chatState.isAscending,
                chatService: ChatService(),
              ),
            ],
          ),
        ),
      ),

      //----- CREATE A GROUP BUTTON -----//
      floatingActionButton: MyFloatingActionButton(
        buttonTitle: 'Create a Group',
        onTap: () {
          showDialog(
            context: context,
            builder: (context) => MyDialogBox(
              title: 'Create Group',
              icon: CupertinoIcons.group_solid,
              hideCloseButton: true,
              buttons: [
                TextField(
                  controller: _groupNameController,
                  decoration:
                      formDecoration('Enter Group Name', CupertinoIcons.group),
                  style: TextStyle(fontSize: fontSize),
                ),
                SizedBox(height: paddingVertical),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: MyButton(
                        buttonTitle: 'Cancel',
                        buttonType: ButtonType.bordered,
                        onTap: () {
                          Navigator.of(context).pop();
                          _groupNameController.clear();
                        },
                        color: Colors.red,
                        fontSize: fontSize,
                      ),
                    ),
                    SizedBox(width: paddingHorizontal * 0.2),
                    Expanded(
                      child: MyButton(
                        buttonTitle: 'Create',
                        buttonType: ButtonType.filled,
                        onTap: () {
                          Navigator.of(context).pop();
                          _createGroup();
                        },
                        color: Colors.green,
                        fontSize: fontSize,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
        color: Colors.blue, // Customize button color
        floatingActionButtonType:
            FloatingActionButtonType.bordered, // Choose type
        icon: CupertinoIcons.add_circled, // Optional Material icon
      ),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.endFloat, // Add this line
    );
  }
}
