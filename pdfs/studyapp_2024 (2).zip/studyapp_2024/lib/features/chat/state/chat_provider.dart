import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/features/chat/data/chat_repo.dart';
import 'package:studyapp_2024/features/chat/data/chat_service.dart';
import 'package:studyapp_2024/features/chat/state/chat_state.dart';
import 'package:studyapp_2024/features/chat/state/chat_state_notifier.dart';

final chatServiceProvider = Provider<ChatService>((ref) => ChatService());

final chatRepoProvider =
    Provider((ref) => ChatRepo(ref.read(chatServiceProvider)));

final chatNotifierProvider =
    StateNotifierProvider<ChatStateNotifier, ChatState>(
  (ref) => ChatStateNotifier(ref.read(chatRepoProvider)),
);
