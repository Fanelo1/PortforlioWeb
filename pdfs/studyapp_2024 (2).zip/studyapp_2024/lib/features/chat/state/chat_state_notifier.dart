// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: ChatStateNotifier CLASS (220024654_LK Maasdorp)
// PURPOSE:

import 'package:flutter/widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:studyapp_2024/features/chat/data/chat_repo.dart';
import 'package:studyapp_2024/features/chat/state/chat_state.dart';

class ChatStateNotifier extends StateNotifier<ChatState> {
  final ChatRepo chatRepo;

  ChatStateNotifier(this.chatRepo) : super(ChatState()) {
    _listenToGroupChats();
  }

//========== GROUP CHAT STATE ==========//

  void _listenToGroupChats() {
    chatRepo.getGroups().listen((snapshot) {
      final groupChats = snapshot.docs; // List of QueryDocumentSnapshot
      state = state.copyWith(groupChats: groupChats, isLoading: false);
    }, onError: (error) {
      state = state.copyWith(error: error.toString(), isLoading: false);
    });
  }

  //CREATE STATE
  Future<void> createChatGroup(String groupName, BuildContext context) async {
    state = state.copyWith(isLoading: true);
    try {
      await chatRepo.createGroup(groupName, context);
      state = state.copyWith(error: null);
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //READ STATE
  Future<void> loadGroupChats() async {
    state = state.copyWith(isLoading: true);
    try {
      final stream = chatRepo.getGroups();
      stream.listen((snapshot) {
        state = state.copyWith(groupChats: snapshot.docs);
      });
    } catch (e) {
      state = state.copyWith(error: e.toString());
    } finally {
      state = state.copyWith(isLoading: false);
    }
  }

  //UPDATE STATE (GROUP NAME)
  Future<void> editGroupName(String groupId, String newGroupName) async {
    await chatRepo.editGroupChatName(groupId, newGroupName);
    loadGroupChats();
  }

//========== MESSAGES STATE ==========//

  //CREATE STATE (TEXT-MESSAGE)
  Future<void> sendText(String groupId, String messageText) async {
    await chatRepo.sendTextMessage(groupId, messageText);
  }

  //CREATE STATE (IMAGE)
  Future<void> sendImg(String groupId, XFile image) async {
    await chatRepo.sendImage(groupId, image);
  }

  Future<void> updatePdfSendingStatus(String pdfUrl, bool isSending) async {
    state = state.copyWith(
      sendingPdfStatus: {...state.sendingPdfStatus, pdfUrl: isSending},
    );
  }

  bool isSendingPdf(String? pdfUrl) {
    if (pdfUrl == null) return false;
    return state.sendingPdfStatus[pdfUrl] ?? false;
  }

  //CREATE STATE (PDF)
  Future<void> sendPdf(String groupId, XFile pdfFile) async {
    try {
      // Generate a temporary URL or ID to track this upload
      String tempId = DateTime.now().millisecondsSinceEpoch.toString();
      await updatePdfSendingStatus(tempId, true);

      // Send the PDF and get the actual URL
      final pdfUrl = await chatRepo.sendFile(groupId, pdfFile);

      // Update the status with the actual URL
      await updatePdfSendingStatus(tempId, false);
      await updatePdfSendingStatus(pdfUrl, false);
    } catch (e) {
      print('Error sending PDF: $e');
      // Handle error...
    }
  }

  //READ STATE
  Stream<QuerySnapshot> getGroupMessages(String groupId) {
    return chatRepo.groupMessages(groupId);
  }

  //READ STATE (MESSAGE READ BY MEMBER)
  Future<void> markTextRead(String groupId, String messageId) async {
    await chatRepo.markAsRead(groupId, messageId);
  }

  //READ STATE (MEMBER NAME)
  Future<String> getNameUser(String userId) async {
    return await chatRepo.getName(userId);
  }

  //DELETE STATE
  // In chat_state_notifier.dart
  Future<void> deleteMessage(String groupId, String messageId) async {
    try {
      await chatRepo.deleteMessage(groupId, messageId);
    } catch (e) {
      print('Error deleting message: $e');
    }
  }

//========== GROUP MEMBERS STATE ==========//

  //READ STATE (MEMBER SEARCH RESET)
  void resetMemberSearchState() {
    state = state.copyWith(
      isLoading: false,
      isMemberFound: false,
      memberSearchMessage: null,
    );
  }

  //READ STATE (ADD MEMBER RESET)
  void resetAddMemberDialogState() {
    state = state.copyWith(
      isLoading: false,
      isMemberFound: false,
      memberSearchMessage: null,
    );
  }

  //READ STATE (MEMBER EMAIL)
  Future<Map<String, dynamic>> validateMemberEmail(
      String email, String groupId) async {
    state = state.copyWith(isLoading: true);
    try {
      final result = await chatRepo.validateMemberEmail(email, groupId);
      state = state.copyWith(
        isLoading: false,
        isMemberFound: result['isValid'],
        memberSearchMessage: result['message'],
        foundMemberData: result['userData'],
      );
      return result;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: e.toString(),
      );
      return {
        'isValid': false,
        'message': 'Error validating email: $e',
      };
    }
  }

  //CREATE STATE (ADD MEMBER)
  Future<void> addMemberToGroup({
    required String groupId,
    required String groupName,
    required String email,
  }) async {
    state = state.copyWith(isLoading: true);
    try {
      await chatRepo.addMemberToGroup(
        groupId: groupId,
        groupName: groupName,
        email: email,
      );
      state = state.copyWith(
        isLoading: false,
        memberSearchMessage: 'Member successfully added to group!',
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: e.toString(),
      );
    }
  }

  //READ STATE (ALL GROUP MEMBERS)
  Future<void> getGroupMembers(String groupId) async {
    state = state.copyWith(isLoading: true);
    try {
      final members = await chatRepo.getGroupMembers(groupId);

      // Convert the members list to include user details
      List<Map<String, dynamic>> memberDetails = [];
      for (var member in members) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(member['userId'])
            .get();

        if (userDoc.exists) {
          memberDetails.add({
            ...userDoc.data()!,
            'userId': member['userId'],
          });
        }
      }

      state = state.copyWith(
        groupMembers: memberDetails,
        isLoading: false,
      );
    } catch (e) {
      print('Error getting group members: $e');
      state = state.copyWith(
        error: e.toString(),
        isLoading: false,
      );
    }
  }

  //READ STATE (MEMBER EXISTS)
  Future<bool> checkMemberInGroup(String userId, String groupId) async {
    state = state.copyWith(isLoading: true);
    try {
      final isMember = await chatRepo.isMemberInGroup(userId, groupId);
      state = state.copyWith(isLoading: false);
      return isMember;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: e.toString(),
      );
      return false;
    }
  }

  Future<void> preloadUsernames() async {
    // Implement logic if necessary to preload usernames.
  }

  void toggleSortOrder() {
    state = state.copyWith(isAscending: !state.isAscending);
  }

  void updateSearchQuery(String query) {
    state = state.copyWith(searchQuery: query.toLowerCase());
  }
} //END OF ChatStateNotifier CLASS
