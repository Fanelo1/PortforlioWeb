import 'package:cloud_firestore/cloud_firestore.dart';

class ChatState {
  final List<QueryDocumentSnapshot>? groupChats;
  final bool isLoading;
  final String? error;
  final bool isAscending;
  final String searchQuery;
  final Map<String, bool> sendingPdfStatus;
  final bool isMemberSearchLoading;
  final bool isMemberFound;
  final String? memberSearchMessage;
  final Map<String, dynamic>? foundMemberData;
  final List<Map<String, dynamic>> groupMembers;

  ChatState({
    this.groupChats,
    this.isLoading = false,
    this.error,
    this.isAscending = true,
    this.searchQuery = '',
    this.isMemberSearchLoading = false,
    this.isMemberFound = false,
    this.memberSearchMessage,
    this.foundMemberData,
    this.sendingPdfStatus = const {},
    this.groupMembers = const [],
  });
  ChatState copyWith({
    List<QueryDocumentSnapshot>? groupChats,
    List<Map<String, dynamic>>? groupMembers,
    bool? isLoading,
    String? error,
    bool? isAscending,
    String? searchQuery,
    bool? isMemberSearchLoading,
    bool? isMemberFound,
    String? memberSearchMessage,
    Map<String, dynamic>? foundMemberData,
    Map<String, bool>? sendingPdfStatus,
  }) {
    return ChatState(
      groupMembers: groupMembers ?? this.groupMembers,
      sendingPdfStatus: sendingPdfStatus ?? this.sendingPdfStatus,
      groupChats: groupChats ?? this.groupChats,
      isLoading: isLoading ?? this.isLoading,
      error: error ?? this.error,
      isAscending: isAscending ?? this.isAscending,
      searchQuery: searchQuery ?? this.searchQuery,
      isMemberSearchLoading:
          isMemberSearchLoading ?? this.isMemberSearchLoading,
      isMemberFound: isMemberFound ?? this.isMemberFound,
      memberSearchMessage: memberSearchMessage ?? this.memberSearchMessage,
      foundMemberData: foundMemberData ?? this.foundMemberData,
    );
  }
}
