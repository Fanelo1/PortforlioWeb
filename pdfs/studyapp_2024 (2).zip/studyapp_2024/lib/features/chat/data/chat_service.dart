// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: ChatService CLASS (220024654, LK Maasdorp)
// PURPOSE: This class is used to interact with Firebase Firestore for the chat functionality of the application

import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final Map<String, String> _userNamesCache = {};

  //----- CONSTRUCTORS -----//
  ChatService() {
    _preloadUsernames();
  }

// Preload usernames from Firestore into cache
  void _preloadUsernames() async {
    final userCollection = await _firestore.collection('users').get();
    for (var doc in userCollection.docs) {
      final data = doc.data();
      _userNamesCache[doc.id] = '${data['Firstname']} ${data['Surname']}';
    }
  }

//----- METHOD TO CREATE A NEW GROUP CHAT -----//
  Future<void> createGroupChat({
    required String groupName,
    required BuildContext context,
  }) async {
    try {
      String userId = FirebaseAuth.instance.currentUser!.uid;
      DocumentSnapshot userDoc =
          await _firestore.collection('users').doc(userId).get();
      String firstName = userDoc['Firstname'];
      String surname = userDoc['Surname'];
      String userName = "$firstName $surname";

      //----- GROUPCHAT FIRESTORE COLLECTION IS CREATED -----//
      DocumentReference groupChatRef =
          await _firestore.collection('groupChats').add({
        'Group Name': groupName,
        'Created By': userId,
        'Group Creator': userName,
        'Group Members': [
          {
            'userId': userId,
            'userName': userName,
          }
        ],
        'Created At': Timestamp.now(),
      });

      //----- SUBCOLLECTION OF GROUPCHATS IS ADDED UNDER THE USERS COLLECTION -----//
      await _firestore
          .collection('users')
          .doc(userId)
          .collection('joinedGroupChats')
          .doc(groupChatRef.id)
          .set(
        {
          'Group Creator': userName,
          'Group Name': groupName,
          'Group Members': [
            {
              'userId': userId,
              'userName': userName,
            }
          ],
          'Created At': Timestamp.now(),
        },
      );
    } catch (e) {
      print("Error creating group chat: $e");
    }
  } //END OF createGroupChat METHOD

//----- METHOD TO ADD A USER TO THE GROUP CHAT -----//
  Future<void> addUserToGroupChat({
    required String groupId,
    required String groupName,
    required String inviteeEmail,
  }) async {
    try {
      //----- QUERY TO FIND THE USER IN THE FIRESTORE -----//
      final userSnapshot = await _firestore
          .collection('users')
          .where('Email Address', isEqualTo: inviteeEmail)
          .get();

      if (userSnapshot.docs.isNotEmpty) {
        final inviteeUserId = userSnapshot.docs.first.id;
        final inviteeFirstName = userSnapshot.docs.first['Firstname'];
        final inviteeSurname = userSnapshot.docs.first['Surname'];
        final inviteeUserName = "$inviteeFirstName $inviteeSurname";

        await _firestore.collection('groupChats').doc(groupId).update({
          'Group Members': FieldValue.arrayUnion([
            {'userId': inviteeUserId, 'userName': inviteeUserName}
          ]),
        });

        DocumentSnapshot groupChatSnapshot =
            await _firestore.collection('groupChats').doc(groupId).get();
        List<Map<String, dynamic>> updatedGroupMembers =
            List<Map<String, dynamic>>.from(
                groupChatSnapshot['Group Members'] ?? []);

        await _firestore
            .collection('users')
            .doc(inviteeUserId)
            .collection('joinedGroupChats')
            .doc(groupId)
            .set({
          'Group Name': groupName,
          'Group Members': updatedGroupMembers,
          'Created At': groupChatSnapshot['Created At'],
          'Group Creator': groupChatSnapshot['Group Creator'],
        }, SetOptions(merge: true));

        //----- UPDATING GROUPCHAT SUBCOLLECTION OF USER COLLECTION -----//
        for (var members in updatedGroupMembers) {
          await _firestore
              .collection('users')
              .doc(members['userId'])
              .collection('groupChats')
              .doc(groupId)
              .update({
            'Group Members': updatedGroupMembers,
          });
        }

        print(
            "User $inviteeUserName added to the group '$groupName' successfully and updated all members!");
      } else {
        print("User not found.");
      }
    } catch (e) {
      print("Error adding user to group: $e");
    }
  } //END OF addUserToGroupChat METHOD

//----- METHOD TO UPDATE THE GROUP NAME IN FIRESTORE -----//
  Future<void> updateGroupName({
    required String groupId,
    required String newGroupName,
  }) async {
    try {
      await _firestore.collection('groupChats').doc(groupId).update({
        'Group Name': newGroupName,
      });

      var groupChatSnapshot =
          await _firestore.collection('groupChats').doc(groupId).get();
      var members = groupChatSnapshot['Group Members'] as List<dynamic>;

      for (var memberId in members) {
        await _firestore
            .collection('users')
            .doc(memberId)
            .collection('groupChats')
            .doc(groupId)
            .update({
          'Group Name': newGroupName,
        });
      }

      print('Group name updated successfully to "$newGroupName"');
    } catch (e) {
      print('Error updating group name: $e');
    }
  }

//----- METHOD TO CHECK IF THE USER EXISTS IN THE FIRESTORE -----//
  Future<bool> checkUserExists(String email) async {
    var querySnapshot = await _firestore
        .collection('users')
        .where('Email Address', isEqualTo: email)
        .get();

    return querySnapshot.docs.isNotEmpty;
  } //END OF checkUserExists METHOD

//----- METHOD TO RETRIEVE ALL THE GROUP CHATS THE CURRENT USER HAS -----//
  Stream<QuerySnapshot> getGroupChats() {
    String currentUserId = FirebaseAuth.instance.currentUser!.uid;

    return FirebaseFirestore.instance
        .collection('users')
        .doc(currentUserId)
        .collection('joinedGroupChats')
        .snapshots();
  } //END OF getGroupChats METHOD

//----- METHOD TO SEND A MESSAGE TO A GROUP -----//
  Future<void> sendMessage({
    required String groupId,
    required String message,
  }) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception('User not logged in');
      }

      DocumentSnapshot userDoc =
          await _firestore.collection('users').doc(user.uid).get();
      String firstName = userDoc['Firstname'];
      String surname = userDoc['Surname'];
      String fullName = "$firstName $surname";

      await _firestore
          .collection('groupChats')
          .doc(groupId)
          .collection('groupMessages')
          .add({
        'Message': message,
        'User ID': user.uid,
        'Sender Name': fullName,
        'Sent At': Timestamp.now(),
        'ReadBy': [],
      });
    } catch (e) {
      print('Error sending message: $e');
      rethrow;
    }
  } //END OF sendMessage METHOD

//----- METHOD TO UPLOAD IMAGE TO FIREBASE STORAGE AND SAVE TO GROUPFILES SUBCOLLECTION -----//
  Future<void> uploadImageToGroup({
    required String groupId,
    required XFile imageFile,
  }) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception('User not logged in');
      }

      DocumentSnapshot userDoc =
          await _firestore.collection('users').doc(user.uid).get();
      String firstName = userDoc['Firstname'];
      String surname = userDoc['Surname'];
      String fullName = "$firstName $surname";

      Reference storageRef =
          _storage.ref().child('groupChats/$groupId/images/${imageFile.name}');

      UploadTask uploadTask = storageRef.putFile(File(imageFile.path));
      TaskSnapshot taskSnapshot = await uploadTask;

      String downloadUrl = await taskSnapshot.ref.getDownloadURL();

      await _firestore
          .collection('groupChats')
          .doc(groupId)
          .collection('groupFiles')
          .add({
        'File Name': imageFile.name,
        'File URL': downloadUrl,
        'Sender Name': fullName,
        'User ID': user.uid,
        'Uploaded At': Timestamp.now(),
        'File Type': 'Image',
      });

      // Add the image as a message with initial read status
      await _firestore
          .collection('groupChats')
          .doc(groupId)
          .collection('groupMessages')
          .add({
        'ImageURL': downloadUrl,
        'Sender Name': fullName,
        'User ID': user.uid,
        'Sent At': Timestamp.now(),
      });

      print('Image uploaded and message sent with image URL.');
    } catch (e) {
      print('Error uploading image: $e');
      rethrow;
    }
  } //END OF uploadImageToGroup METHOD

//----- METHOD TO UPLOAD PDF TO FIREBASE STORAGE AND SAVE TO GROUPFILES SUBCOLLECTION -----//
  Future<String> uploadPdfToGroup({
    required String groupId,
    required XFile pdfFile,
  }) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception('User not logged in');
      }
      // Get file details
      final File file = File(pdfFile.path);
      final int fileSize = await file.length();
      final String fileName = pdfFile.name;
      final String formattedSize = _formatFileSize(fileSize);

      DocumentSnapshot userDoc =
          await _firestore.collection('users').doc(user.uid).get();
      String firstName = userDoc['Firstname'];
      String surname = userDoc['Surname'];
      String fullName = "$firstName $surname";

      Reference storageRef =
          _storage.ref().child('groupChats/$groupId/pdfs/$fileName');

      UploadTask uploadTask = storageRef.putFile(File(pdfFile.path));
      TaskSnapshot taskSnapshot = await uploadTask;

      String downloadUrl = await taskSnapshot.ref.getDownloadURL();

      // Save the PDF metadata in the groupFiles subcollection
      await _firestore
          .collection('groupChats')
          .doc(groupId)
          .collection('groupFiles')
          .add({
        'File Name': fileName,
        'File URL': downloadUrl,
        'File Size': formattedSize,
        'Sender Name': fullName,
        'User ID': user.uid,
        'Uploaded At': Timestamp.now(),
        'File Type': 'pdf',
      });

      // Add the PDF as a message with initial read status
      await _firestore
          .collection('groupChats')
          .doc(groupId)
          .collection('groupMessages')
          .add({
        'PdfURL': downloadUrl,
        'FileName': fileName,
        'FileSize': formattedSize,
        'Sender Name': fullName,
        'User ID': user.uid,
        'Sent At': Timestamp.now(),
      });
      return downloadUrl;
    } catch (e) {
      print('Error uploading PDF: $e');
      rethrow;
    }
  } //END OF uploadPdfToGroup METHOD

  String _formatFileSize(int bytes) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var i = (log(bytes) / log(1024)).floor();
    return '${(bytes / pow(1024, i)).toStringAsFixed(1)} ${suffixes[i]}';
  }

  //----- METHOD TO DELETE MESSAGE FROM GROUP CHAT -----//
  Future<void> deleteMessage(String groupId, String messageId) async {
    try {
      await _firestore
          .collection('groupChats')
          .doc(groupId)
          .collection('groupMessages')
          .doc(messageId)
          .update({
        'isDeleted': true,
        'Message': FieldValue.delete(),
        'ImageURL': FieldValue.delete(),
        'PdfURL': FieldValue.delete(),
      });
    } catch (e) {
      print('Error deleting message: $e');
      rethrow;
    }
  }

  //----- METHOD TO RETRIEVE USER'S NAME FROM FIRESTORE -----//
  Future<String> getUserName(String userId) async {
    if (_userNamesCache.containsKey(userId)) {
      return _userNamesCache[userId]!;
    }

    final userDoc = await _firestore.collection('users').doc(userId).get();
    final userData = userDoc.data();

    if (userData != null) {
      final fullName = '${userData['Firstname']} ${userData['Surname']}';
      _userNamesCache[userId] = fullName;
      return fullName;
    }
    return 'Unknown';
  } //END OF _getUserName METHOD

//----- METHOD TO RECEIVE A MESSAGE IN THE GROUP CHAT -----//
  Stream<QuerySnapshot> groupMessagesStream(String groupId) {
    return FirebaseFirestore.instance
        .collection('groupChats')
        .doc(groupId)
        .collection('groupMessages')
        .orderBy('Sent At', descending: false)
        .snapshots();
  } //END OF groupMessagesStream METHOD

//----- METHOD TO MARK A MESSAGE AS READ BY THE CURRENT USER -----//
  Future<void> markMessageAsRead(
    String groupId,
    String messageId,
  ) async {
    final userId = FirebaseAuth.instance.currentUser!.uid;

    await FirebaseFirestore.instance
        .collection('groupChats')
        .doc(groupId)
        .collection('groupMessages')
        .doc(messageId)
        .update({
      'ReadBy': FieldValue.arrayUnion([userId])
    });
  } //END OF markMessagesAsRead METHOD

//----- METHOD TO UPDATE USER GROUP COLOR PREFERENCE -----//
  Future<void> saveGroupColor({
    required String groupId,
    required String color,
  }) async {
    try {
      await _firestore.collection('groupChats').doc(groupId).update({
        'TileColor': color,
      });
      print("Group color saved: $color");
    } catch (e) {
      print("Error saving group color: $e");
    }
  }

//----- METHOD TO RETRIEVE USER GROUP COLOR PREFERENCE -----//
  Future<String> getGroupColor(String groupId) async {
    try {
      var doc = await _firestore.collection('groupChats').doc(groupId).get();
      return doc['TileColor'] ?? 'blue'; // Default color
    } catch (e) {
      print("Error retrieving group color: $e");
      return 'blue';
    }
  }

//----- METHOD TO CHECK IF USER EXISTS AND IS NOT ALREADY IN GROUP -----//
  Future<Map<String, dynamic>> checkUserForGroup({
    required String email,
    required String groupId,
  }) async {
    try {
      final userSnapshot = await _firestore
          .collection('users')
          .where('Email Address', isEqualTo: email.toLowerCase())
          .get();

      if (userSnapshot.docs.isEmpty) {
        return {
          'exists': false,
          'message': 'User not found.',
        };
      }

      // Get the group document to check members
      final groupDoc =
          await _firestore.collection('groupChats').doc(groupId).get();

      if (!groupDoc.exists) {
        return {
          'exists': false,
          'message': 'Group not found.',
        };
      }

      // Get current group members
      List<dynamic> groupMembers = groupDoc.data()?['Group Members'] ?? [];

      // Check if user is already a member
      bool isAlreadyMember = groupMembers
          .any((member) => member['userId'] == userSnapshot.docs.first.id);

      if (isAlreadyMember) {
        return {
          'exists': false,
          'message': 'Member already added.',
        };
      }

      // User exists and is not a member
      return {
        'exists': true,
        'userId': userSnapshot.docs.first.id,
        'userData': userSnapshot.docs.first.data(),
      };
    } catch (e) {
      print('Error checking user for group: $e');
      return {
        'exists': false,
        'message': 'Error checking user status.',
      };
    }
  }

//----- METHOD TO GET GROUP MEMBERS -----//
  Future<List<Map<String, dynamic>>> getGroupMembers(String groupId) async {
    try {
      DocumentSnapshot groupDoc =
          await _firestore.collection('groupChats').doc(groupId).get();

      if (!groupDoc.exists) {
        return [];
      }

      List<dynamic> members =
          (groupDoc.data() as Map<String, dynamic>)['Group Members'] ?? [];
      return List<Map<String, dynamic>>.from(members);
    } catch (e) {
      print('Error in ChatService getting group members: $e');
      rethrow;
    }
  }

//----- METHOD TO CHECK IF USER IS GROUP MEMBER -----//
  Future<bool> isUserGroupMember({
    required String userId,
    required String groupId,
  }) async {
    try {
      DocumentSnapshot groupDoc =
          await _firestore.collection('groupChats').doc(groupId).get();

      if (!groupDoc.exists) {
        return false;
      }

      List<dynamic> members = groupDoc['Group Members'] ?? [];
      return members.any((member) => member['userId'] == userId);
    } catch (e) {
      print('Error checking if user is group member: $e');
      return false;
    }
  }

  Future<void> updatePdfSendingStatus(String pdfUrl, bool isSending) async {
    // This method would typically update the status in Firestore
    // For now, we'll just print the status change
    print('PDF $pdfUrl sending status: $isSending');
  }

  Stream<Map<String, bool>> getPdfSendingStatus() {
    // This method would typically return a stream from Firestore
    // For now, we'll just return an empty stream
    return Stream.value({});
  }
}
