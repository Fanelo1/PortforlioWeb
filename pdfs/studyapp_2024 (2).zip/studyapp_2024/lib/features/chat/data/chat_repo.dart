// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: ChatRepo CLASS (220024654_LK Maasdorp)
// PURPOSE: This class is responsible for handling the application's business logic

import 'chat_service.dart';
import 'package:flutter/widgets.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ChatRepo {
  final ChatService _chatService;
  ChatRepo(this._chatService);

//========== GROUP: CRUD  OPERATIONS ==========//

  //CREATE
  Future<void> createGroup(String groupName, BuildContext context) async {
    await _chatService.createGroupChat(groupName: groupName, context: context);
  }

  //READ
  Stream<QuerySnapshot> getGroups() {
    return _chatService.getGroupChats();
  }

  //UPDATE (GROUP NAME)
  Future<void> editGroupChatName(String groupId, String newGroupName) async {
    await _chatService.updateGroupName(
        groupId: groupId, newGroupName: newGroupName);
  }

  //CREATE (GROUP COLOR)
  Future<void> saveColor(String groupId, String color) async {
    await _chatService.saveGroupColor(groupId: groupId, color: color);
  }

  //READ (GROUP COLOR)
  Future<String> getColor(String groupId) async {
    return await _chatService.getGroupColor(groupId);
  }

//========== MESSAGE: CRUD  OPERATIONS ==========//

  //CREATE (TEXT-MESSAGE)
  Future<void> sendTextMessage(String groupId, String message) async {
    await _chatService.sendMessage(groupId: groupId, message: message);
  }

  //CREATE (IMAGE)
  Future<void> sendImage(String groupId, XFile imageFile) async {
    await _chatService.uploadImageToGroup(
        groupId: groupId, imageFile: imageFile);
  }

  //CREATE (PDF)
  Future<String> sendFile(String groupId, XFile pdfFile) async {
    return await _chatService.uploadPdfToGroup(
      groupId: groupId,
      pdfFile: pdfFile,
    );
  }

  //READ (PDF)
  Future<void> updatePdfSendingStatus(String pdfUrl, bool isSending) {
    return _chatService.updatePdfSendingStatus(pdfUrl, isSending);
  }

  //READ (SENDING PDF)
  Stream<Map<String, bool>> getPdfSendingStatus() {
    return _chatService.getPdfSendingStatus();
  }

  //READ (ALL MESSAGES)
  Stream<QuerySnapshot> groupMessages(String groupId) {
    return _chatService.groupMessagesStream(groupId);
  }

  //READ (MEMBER NAME)
  Future<String> getName(String userId) async {
    return await _chatService.getUserName(userId);
  }

  //READ (ALL MESSAGES READ BY MEMBERS)
  Future<void> markAsRead(String groupId, String messageId) async {
    await _chatService.markMessageAsRead(groupId, messageId);
  }

  //READ (USER EXISTS)
  Future<bool> checkUser(String email) async {
    return await _chatService.checkUserExists(email);
  }

  //DELETE
  // In chat_repo.dart
  Future<void> deleteMessage(String groupId, String messageId) async {
    await _chatService.deleteMessage(groupId, messageId);
  }

//========== MEMBER: CRUD  OPERATIONS ==========//

  Future<String?> searchUser(String email, String groupId) async {
    final result = await _chatService.checkUserForGroup(
      email: email,
      groupId: groupId,
    );

    if (!result['exists']) {
      return result['message'];
    }

    return null; // User can be added to group
  }

  //----- MEMBER: SEARCH -----//
  Future<Map<String, dynamic>> searchGroupMember(
      String email, String groupId) async {
    try {
      final result = await _chatService.checkUserForGroup(
        email: email,
        groupId: groupId,
      );
      return result;
    } catch (e) {
      return {
        'exists': false,
        'message': 'Error searching for user: $e',
      };
    }
  }

  //----- MEMBER: ADD TO GROUP -----//
  Future<void> addMemberToGroup({
    required String groupId,
    required String groupName,
    required String email,
  }) async {
    try {
      await _chatService.addUserToGroupChat(
        groupId: groupId,
        groupName: groupName,
        inviteeEmail: email,
      );
    } catch (e) {
      throw Exception('Failed to add member to group: $e');
    }
  }

  //----- MEMBER: GET ALL -----//
  Future<List<Map<String, dynamic>>> getGroupMembers(String groupId) async {
    try {
      return await _chatService.getGroupMembers(groupId);
    } catch (e) {
      print('Error in ChatRepo getting group members: $e');
      rethrow;
    }
  }

  //----- MEMBER: CHECK IF EXISTS -----//
  Future<bool> isMemberInGroup(String userId, String groupId) async {
    try {
      return await _chatService.isUserGroupMember(
        userId: userId,
        groupId: groupId,
      );
    } catch (e) {
      print('Error checking member status: $e');
      return false;
    }
  }

  //----- MEMBER: VALIDATE EMAIL -----//
  Future<Map<String, dynamic>> validateMemberEmail(
      String email, String groupId) async {
    try {
      // First check if email is valid
      if (!email.contains('@')) {
        return {
          'isValid': false,
          'message': 'Please enter a valid email address',
        };
      }

      // Then check if user exists and can be added
      final result = await _chatService.checkUserForGroup(
        email: email,
        groupId: groupId,
      );

      return {
        'isValid': result['exists'],
        'message': result['message'],
        'userData': result['userData'],
      };
    } catch (e) {
      return {
        'isValid': false,
        'message': 'Error validating email: $e',
      };
    }
  }
} //END OF ChatRepo CLASS
