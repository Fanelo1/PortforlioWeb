// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: OnboardingPage CLASS (220024654, LK MAASDORP)
// PURPOSE: The initial first page when launching the app, serves as an introduction to our application

import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:studyapp_2024/features/onboarding/widgets/onboarding_items.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  //----- ONBOADING SCREEN METHOD (FOR SHOWING PAGE ONLY ONE TIME)-----//
  Future<void> _completeOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding', false);

    if (!mounted) return;
    Navigator.pushReplacementNamed(context, RouteManager.landingPage);
  }

  //----- CONTROLLER -----//
  final PageController _pageController = PageController();

  int currentPage = 0;
  bool onLastPage = false;

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(248, 249, 251, 1),
        actions: [
          if (currentPage != 5)
            TextButton(
              onPressed: () {
                _pageController.jumpToPage(5);
              },
              child: const Text(
                'Skip',
                style: TextStyle(
                  fontSize: 16,
                  color: Color.fromARGB(255, 0, 74, 173),
                ),
              ),
            ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          vertical: screenHeight * 0.02,
        ),
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: _pageController,
                scrollDirection: Axis.horizontal,
                onPageChanged: (index) {
                  setState(() {
                    currentPage = index;
                  });
                },
                children: const [
                  OnboardingItem(
                    imagePath: 'assets/images/Onboarding4.png',
                    title: "Take Notes",
                    description: "Create and save your notes",
                  ),
                  OnboardingItem(
                    imagePath: 'assets/images/Onboarding1.png',
                    title: "Use A Study Timer",
                    description: "Time yourself while you study",
                  ),
                  OnboardingItem(
                    imagePath: 'assets/images/Onboarding2.png',
                    title: "Flashcard Revison",
                    description: "Revise your notes",
                  ),
                  OnboardingItem(
                    imagePath: 'assets/images/Onboarding3.png',
                    title: "Generate papers with AI",
                    description: "Generate question papers with AI",
                  ),
                  OnboardingItem(
                    imagePath: 'assets/images/Onboarding5.png',
                    title: "Communicate with friends",
                    description: "Create group chats with study buddies",
                  ),
                  OnboardingItem(
                    imagePath: 'assets/images/Onboarding6.png',
                    title: "Schedule",
                    description: "Plan your next study session",
                  ),
                ],
              ),
            ),

            //----- MY BUTTON (LANDING PAGE) -----//
            if (currentPage == 5)
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: screenWidth * 0.05,
                ),
                child: MyButton(
                  buttonTitle: 'Get Started',
                  onTap: _completeOnboarding,
                  color: const Color.fromARGB(255, 56, 182, 255),
                ),
              ),

            const SizedBox(height: 30),

            //----- THE SMOOTHCONTROLLER FOR THE PAGEVIEW -----//
            Padding(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (currentPage > 0)
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_back,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                      iconSize: screenWidth * 0.08,
                      onPressed: () {
                        _pageController.previousPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                        );
                      },
                    ),
                  Expanded(
                    child: Container(
                      width: screenWidth * 0.6,
                      alignment: Alignment.center,
                      child: SmoothPageIndicator(
                        controller: _pageController,
                        count: 6,
                        effect: ExpandingDotsEffect(
                          dotWidth: screenWidth * 0.05,
                          dotHeight: screenHeight * 0.015,
                          radius: screenWidth * 0.025,
                          dotColor: Colors.grey,
                          activeDotColor:
                              const Color.fromARGB(255, 103, 156, 224),
                        ),
                      ),
                    ),
                  ),
                  if (currentPage < 5)
                    IconButton(
                      icon: const Icon(
                        Icons.arrow_forward,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                      iconSize: screenWidth * 0.08,
                      onPressed: () {
                        _pageController.nextPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                        );
                      },
                    ),
                ],
              ),
            ),
            SizedBox(height: screenHeight * 0.02)
          ],
        ),
      ),
    );
  }
} //END OF OnboardingPage CLASS
