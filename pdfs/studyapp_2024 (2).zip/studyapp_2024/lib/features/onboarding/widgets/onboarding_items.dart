// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: OnboardingItem CLASS (220024654, LK MAASDORP)
// PURPOSE: The custom widget for the onboarding images for our Onboarding page in our application

import 'package:flutter/material.dart';

class OnboardingItem extends StatelessWidget {
  final String title;
  final String imagePath;
  final String description;

  const OnboardingItem({
    required this.title,
    required this.imagePath,
    required this.description,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: SizedBox(
            width: screenWidth * 0.95, // Responsive width
            height: screenHeight,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: screenHeight * 0.5, // Responsive height for image
                  child: Image.asset(
                    imagePath,
                    fit: BoxFit.contain,
                  ),
                ),
                const SizedBox(height: 20),

                // Title
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize:
                        screenWidth < 600 ? 24 : 50, // Responsive font size
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                const SizedBox(height: 10),

                // Description
                Text(
                  description,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize:
                        screenWidth < 600 ? 16 : 20, // Responsive font size
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }
} //END OF OnboardingItem CLASS
