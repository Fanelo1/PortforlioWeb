// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: LandingPage CLASS (220024654, LK Maasdorp)
// PURPOSE: The landing page for both the admin and student user

import 'package:lottie/lottie.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

Future<void> _launchURL() async {
  final Uri url = Uri.parse('https://localhost:7142');
  if (await canLaunchUrl(url)) {
    await launchUrl(url, mode: LaunchMode.externalApplication);
  } else {
    throw 'Could not launch $url';
  }
}

class _LandingPageState extends State<LandingPage> {
  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: SizedBox(
            width: screenWidth * 0.9,
            height: screenHeight,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: screenHeight * 0.4,
                  child: Lottie.asset(
                    'assets/animations/Onboarding8.json',
                    fit: BoxFit.contain,
                  ),
                ),
                const SizedBox(height: 20),

                //-----  WELCOME MESSAGE TO THE USER -----//
                const Text(
                  'Intelli-Ed',
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 36,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),

                //----- TITLE TO OUR STUDY APPLICATION -----//
                const Text(
                  'Student Study Application',
                  style: TextStyle(
                    color: Color.fromRGBO(67, 98, 124, 1),
                    fontSize: 24,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(
                  height: 60,
                ),

                //----- BUTTON TO STUDENT PORTAL -----//
                MyButton(
                  buttonTitle: 'Continue As Student',
                  onTap: () {
                    Navigator.pushNamed(context, RouteManager.studLogPage);
                  },
                  color: const Color.fromARGB(255, 56, 182, 255),
                ),
                const SizedBox(
                  height: 30,
                ),

                //----- BUTTON TO ADMIN PORTAL -----//
                MyButton(
                  buttonTitle: 'Continue As Admin',
                  onTap: () {
                    _launchURL();
                  },
                  color: const Color.fromARGB(255, 0, 74, 173),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
} //END OF LandingPage CLASS