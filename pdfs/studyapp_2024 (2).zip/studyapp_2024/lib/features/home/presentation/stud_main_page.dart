import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/features/calendar/data/calendar_service.dart';
import 'package:studyapp_2024/features/home/widgets/my_drawer.dart';
import 'package:studyapp_2024/features/home/widgets/study_timer.dart';
import 'package:studyapp_2024/features/home/widgets/timeline_events.dart';
import 'package:studyapp_2024/widgets/my_appbar.dart';

class StudMainPage extends StatefulWidget {
  const StudMainPage({super.key});

  @override
  State<StudMainPage> createState() => _StudMainPageState();
}

class _StudMainPageState extends State<StudMainPage> {
  late final User user;
  late final Stream<DocumentSnapshot> _userStream;
  List<Map<String, dynamic>> _todayEvents = [];
  bool _isLoadingEvents = true;
  DateTime _lastUpdateTime = DateTime.now();

  final ScrollController _scrollController = ScrollController();

  Future<void> _fetchTodayEvents() async {
    try {
      setState(() {
        _isLoadingEvents = true;
      });

      final calendarService = CalendarService();
      DateTime today = DateTime.now();
      DateTime selectedDay = DateTime(today.year, today.month, today.day);

      _todayEvents = await calendarService.fetchEventsForDay(selectedDay);

      setState(() {
        _isLoadingEvents = false;
        _lastUpdateTime = DateTime.now();
      });
    } catch (e) {
      setState(() {
        _isLoadingEvents = false;
      });
      print("Error fetching events: $e");
    }
  }

  bool _needsRefresh() {
    final now = DateTime.now();
    return now.difference(_lastUpdateTime) > const Duration(minutes: 1);
  }

  @override
  void initState() {
    super.initState();
    User? currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser != null) {
      user = currentUser;
      _userStream = FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .snapshots();
      _fetchTodayEvents();
    } else {
      Navigator.pushReplacementNamed(context, RouteManager.landingPage);
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(
        title: StreamBuilder<DocumentSnapshot>(
          stream: _userStream,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Text('Loading...');
            } else if (snapshot.hasError) {
              return const Text('Error loading name');
            } else if (snapshot.hasData && snapshot.data != null) {
              var userData = snapshot.data!.data() as Map<String, dynamic>?;
              String firstName = userData?['Firstname'] ?? 'First Name';
              String surname = userData?['Surname'] ?? 'Surname';
              return Text('Hello, $firstName $surname!');
            } else {
              return const Text('No user data available');
            }
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchTodayEvents, // Reload button action
          ),
        ],
      ),
      drawer: const MyDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RefreshIndicator(
          onRefresh: _fetchTodayEvents,
          child: CustomScrollView(
            controller: _scrollController,
            slivers: [
              const SliverToBoxAdapter(child: StudyTimer()),
              const SliverToBoxAdapter(child: SizedBox(height: 16)),
              const SliverToBoxAdapter(
                child: Text(
                  'Explore Categories',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 8)),
              SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, // Fixed number of columns
                  childAspectRatio: 1,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                    return InkWell(
                      onTap: () {
                        // Add navigation logic here based on index
                        switch (index) {
                          case 0:
                            Navigator.pushNamed(
                                context, RouteManager.foldersPage);
                            break;
                          case 1:
                            Navigator.pushNamed(
                                context, RouteManager.chatHomePage);
                            break;
                          case 2:
                            Navigator.pushNamed(
                                context, RouteManager.flashcardHomePage);
                            break;
                          case 3:
                            Navigator.pushNamed(
                                context, RouteManager.calendarPage);
                            break;
                          default:
                            break;
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                          color: _getColorForIndex(index),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _getIconForIndex(index),
                              size: 50,
                              color: Colors.white,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              _getLabelForIndex(index),
                              style: const TextStyle(
                                fontSize: 16,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  childCount: 4,
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 16)),
              const SliverToBoxAdapter(
                child: Text(
                  'What To Do Today',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 8)),
              _isLoadingEvents
                  ? const SliverToBoxAdapter(
                      child: Center(child: CircularProgressIndicator()))
                  : _todayEvents.isNotEmpty
                      ? SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (BuildContext context, int index) {
                              return EventTimeLine(
                                todayEvents: _todayEvents,
                                event: _todayEvents[index],
                                index: index,
                              );
                            },
                            childCount: _todayEvents.length,
                          ),
                        )
                      : const SliverToBoxAdapter(
                          child: Text('No events for today')),
              if (_needsRefresh())
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 16.0),
                    child: Center(
                      child: Text(
                        'Pull down to refresh for the latest events',
                        style: TextStyle(
                          color: Theme.of(context).hintColor,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper methods to get label, icon, and color for each grid item
  String _getLabelForIndex(int index) {
    switch (index) {
      case 0:
        return "Notes";
      case 1:
        return "Chats";
      case 2:
        return "Flashcards";
      default:
        return "Calendar";
    }
  }

  IconData _getIconForIndex(int index) {
    switch (index) {
      case 0:
        return Icons.note;
      case 1:
        return Icons.chat;
      case 2:
        return Icons.card_membership;
      default:
        return Icons.calendar_today;
    }
  }

  Color _getColorForIndex(int index) {
    switch (index) {
      case 0:
        return Colors.green;
      case 1:
        return const Color.fromARGB(255, 249, 46, 202);
      case 2:
        return Colors.orange;
      default:
        return Colors.purple;
    }
  }
}
