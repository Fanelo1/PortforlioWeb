import 'package:flutter/material.dart';
import 'package:timeline_tile/timeline_tile.dart';

class EventTimeLine extends StatelessWidget {
  final List<Map<String, dynamic>> todayEvents;
  final Map<String, dynamic> event;
  final int index;

  const EventTimeLine({
    super.key,
    required this.todayEvents,
    required this.event,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    bool isComplete = event['Is Complete'] ?? false;
    return TimelineTile(
      alignment: TimelineAlign.start,
      isFirst: index == 0,
      isLast: index == todayEvents.length - 1,
      indicatorStyle: IndicatorStyle(
        width: 20,
        color: isComplete ? Colors.green : Colors.red,
        padding: const EdgeInsets.all(8),
      ),
      beforeLineStyle: const LineStyle(
        color: Colors.grey,
        thickness: 2,
      ),
      endChild: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              event['Title'],
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                decoration: isComplete
                    ? TextDecoration.lineThrough
                    : TextDecoration.none,
              ),
            ),
            const SizedBox(height: 4),
            Text(event['Description'] ?? 'No Description',
                style: const TextStyle(color: Colors.grey)),
            if (isComplete)
              const Text(
                'Completed',
                style: TextStyle(
                  fontStyle: FontStyle.italic,
                  color: Colors.green,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
