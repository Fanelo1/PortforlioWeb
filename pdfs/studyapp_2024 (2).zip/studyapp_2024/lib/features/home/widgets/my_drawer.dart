// GROUP A
// NAME: MyDrawer CLASS (220024654_LK Maasdorp)
// PURPOSE: Custom Widget for the Drawer screen in our application

import 'package:flutter/cupertino.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:studyapp_2024/features/authentication/data/auth_service.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';
import 'package:studyapp_2024/widgets/dialogs/my_dialog_box.dart';

class MyDrawer extends StatefulWidget {
  const MyDrawer({super.key});

  @override
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  late final User user;
  late final Stream<DocumentSnapshot> _userStream;

  @override
  void initState() {
    super.initState();

    //----- RETRIEVING FIRESTORE DATA OF CURRENT USER -----//
    user = FirebaseAuth.instance.currentUser!;
    _userStream = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            //----- EXIT DRAWER BUTTON -----//
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: IconButton(
                icon: const Icon(
                  Icons.close,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),

            //----- HEADER OF THE DRAWER WIDGET -----//
            DrawerHeader(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const CircleAvatar(
                    child: Icon(Icons.person),
                  ),

                  const SizedBox(width: 16),

                  //----- USER'S NAMES AND EMAIL ADDRESS IS DISPLAYED -----//
                  Expanded(
                    child: StreamBuilder<DocumentSnapshot>(
                      stream: _userStream,
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          var userData =
                              snapshot.data?.data() as Map<String, dynamic>;
                          String firstName =
                              userData['Firstname'] ?? 'First Name';
                          String surname = userData['Surname'] ?? 'Surname';
                          String email =
                              userData['Email Address'] ?? 'Email Address';
                          return RichText(
                            text: TextSpan(
                              text: '$firstName $surname',
                              style: DefaultTextStyle.of(context).style,
                              children: <TextSpan>[
                                TextSpan(
                                  text: '\n$email',
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ],
                            ),
                          );
                        } else if (snapshot.hasError) {
                          return const Text('Error loading name...');
                        } else {
                          return const Text('Loading...');
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),

            const Divider(
              color: Colors.grey,
            ),

            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  //----- NAVIGATION TO PROFILE PAGE -----//
                  ListTile(
                    leading: const Icon(Icons.person),
                    title: const Text('View Profile'),
                    onTap: () {
                      Navigator.pushNamed(context, RouteManager.profilePage);
                    },
                  ),
                  const Divider(
                    color: Colors.grey,
                  ),
                ],
              ),
            ),
            const Divider(
              color: Colors.grey,
            ),

            //----- LOGOUT BUTTON -----//
            ListTile(
              leading: const Icon(
                Icons.logout,
                color: Colors.red,
              ),
              title: const Text(
                'Logout',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
              onTap: () async {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return MyDialogBox(
                      borderColor: Colors.red,
                      hideCloseButton: true,
                      icon: CupertinoIcons.exclamationmark_triangle,
                      iconColor: Colors.red,
                      title: "Are you sure you want to logout of your account?",
                      buttons: [
                        //----- CANCELING PROMPT -----//
                        Row(
                          children: [
                            Expanded(
                              child: MyButton(
                                buttonTitle: 'Cancel',
                                buttonType: ButtonType.bordered,
                                onTap: () {
                                  Navigator.of(context).pop();
                                },
                                color: Colors.blue,
                                icon: CupertinoIcons.xmark,
                              ),
                            ),

                            const SizedBox(width: 20),

                            //----- SIGNING USER OUT OF THE APPLICATION -----//
                            Expanded(
                              child: MyButton(
                                buttonTitle: 'Yes',
                                buttonType: ButtonType.filled,
                                onTap: () async {
                                  await AuthService(FirebaseAuth.instance)
                                      .signOut(context);
                                  if (mounted) {
                                    if (context.mounted) {
                                      Navigator.pushReplacementNamed(
                                          context, RouteManager.landingPage);
                                    }
                                  }
                                },
                                color: Colors.red,
                                icon: CupertinoIcons.checkmark_alt,
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
} // END OF MyDrawer STATE CLASS




