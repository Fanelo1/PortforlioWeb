import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:async';

class StudyTimer extends StatefulWidget {
  const StudyTimer({super.key});

  @override
  _StudyTimerState createState() => _StudyTimerState();
}

class _StudyTimerState extends State<StudyTimer> {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  int _focusTime = 5 * 60; // Default focus time is 5 minutes
  int _breakTime = 5 * 60;
  int _remainingTime = 5 * 60;
  Timer? _timer;
  bool _isRunning = false;
  bool _isFocusMode = true;

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
  }

  // Initialize local notifications and notification channel
  void _initializeNotifications() async {
    const AndroidInitializationSettings androidInitializationSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    final InitializationSettings initializationSettings =
        InitializationSettings(android: androidInitializationSettings);
    await _flutterLocalNotificationsPlugin.initialize(initializationSettings);

    // Set up notification channel for sound
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'study_timer_channel', // Channel ID
      'Study Timer', // Channel Name
      description: 'Notifications for study and break times with sound',
      importance: Importance.high,
      playSound: true,
      sound: RawResourceAndroidNotificationSound(
          'alarm'), // Raw sound file reference
    );

    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  // Start or stop the timer
  void _startStopTimer() {
    if (_isRunning) {
      _timer?.cancel();
      setState(() {
        _isRunning = false;
        _remainingTime = _focusTime; // Reset to focus time
      });
    } else {
      _startTimer();
      setState(() {
        _isRunning = true;
      });
    }
  }

  // Start the timer logic
  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingTime > 0) {
          _remainingTime--;
        } else {
          _showAlert();
          _timer?.cancel();
          if (_isFocusMode) {
            _remainingTime = _breakTime;
            _isFocusMode = false;
            _showNotification('Time for a break!', 'Focus time is over.');
          } else {
            _remainingTime = _focusTime;
            _isFocusMode = true;
            _showNotification('Back to work!', 'Break time is over.');
          }
          _startTimer();
        }
      });
    });
  }

  // Show alert when time is up
  void _showAlert() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Time Up!'),
          content: Text(_isFocusMode
              ? 'Focus time is over. Take a break!'
              : 'Break time is over. Back to work!'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  // Show local notification with sound (through the notification channel)
  Future<void> _showNotification(String title, String body) async {
    const AndroidNotificationDetails androidNotificationDetails =
        AndroidNotificationDetails(
      'study_timer_channel', // Channel ID
      'Study Timer', // Channel Name
      channelDescription: 'Notifications for study and break times with sound.',
      importance: Importance.high,
      priority: Priority.high,
      playSound: true, // Play sound with notification
      sound: RawResourceAndroidNotificationSound(
          'alarm'), // Raw sound file reference
    );
    const NotificationDetails notificationDetails =
        NotificationDetails(android: androidNotificationDetails);

    await _flutterLocalNotificationsPlugin.show(
      0,
      title,
      body,
      notificationDetails,
    );
  }

  // Show dialog to set focus and break time
  void _showSetTimerDialog() {
    int tempFocusTime = _focusTime ~/ 60;
    int tempBreakTime = _breakTime ~/ 60;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Set Timer'),
          content: StatefulBuilder(
            builder: (context, setState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const Text('Focus Time:'),
                      const SizedBox(width: 10),
                      DropdownButton<int>(
                        value: tempFocusTime,
                        items: [for (int i = 1; i <= 60; i += 1) i]
                            .map((int value) => DropdownMenuItem<int>(
                                  value: value,
                                  child: Text('$value minutes'),
                                ))
                            .toList(),
                        onChanged: (value) {
                          setState(() {
                            tempFocusTime = value!;
                          });
                        },
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text('Break Time:'),
                      const SizedBox(width: 10),
                      DropdownButton<int>(
                        value: tempBreakTime,
                        items: [for (int i = 5; i <= 30; i += 5) i]
                            .map((int value) => DropdownMenuItem<int>(
                                  value: value,
                                  child: Text('$value minutes'),
                                ))
                            .toList(),
                        onChanged: (value) {
                          setState(() {
                            tempBreakTime = value!;
                          });
                        },
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _focusTime = tempFocusTime * 60;
                  _breakTime = tempBreakTime * 60;
                  _remainingTime = _focusTime;
                });
                Navigator.of(context).pop();
                _showSuccessMessage();
              },
              child: const Text('Set'),
            ),
          ],
        );
      },
    );
  }

  // Show success message after setting the timer
  void _showSuccessMessage() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return const AlertDialog(
          content: Row(
            children: [
              Icon(Icons.check_circle, color: Colors.green),
              SizedBox(width: 10),
              Text('Timer successfully set!'),
            ],
          ),
        );
      },
    );
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.of(context).pop();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final minutes = (_remainingTime ~/ 60).toString().padLeft(2, '0');
    final seconds = (_remainingTime % 60).toString().padLeft(2, '0');

    return SizedBox(
      width: 500,
      child: Card(
        color: _isRunning
            ? (_isFocusMode ? Colors.red : Colors.green)
            : Colors.blue,
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Study Timer',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.more_vert),
                    onPressed: _showSetTimerDialog,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                '$minutes:$seconds',
                style:
                    const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: _startStopTimer,
                child: Text(_isRunning ? 'Pause' : 'Start'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
