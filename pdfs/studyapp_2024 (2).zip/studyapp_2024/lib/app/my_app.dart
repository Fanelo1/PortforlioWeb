import 'package:flutter/material.dart';
import 'package:studyapp_2024/main.dart';
import 'package:studyapp_2024/app/routes.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MyApp extends StatefulWidget {
  final User? user;
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  const MyApp({super.key, this.user});

  @override
  State<MyApp> createState() => MyAppState();
}

class MyAppState extends State<MyApp> {
  @override
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: MyApp.navigatorKey,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme(Theme.of(context).textTheme),
        scaffoldBackgroundColor: const Color.fromRGBO(248, 249, 251, 1),
        primaryColor: Colors.blue,
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.blue),
      ),
      initialRoute: widget.user != null
          ? RouteManager.studMainPage
          : show
              ? RouteManager.landingPage
              : RouteManager.onboardingPage,
      onGenerateRoute: RouteManager.generateRoute,
    );
  }
}
