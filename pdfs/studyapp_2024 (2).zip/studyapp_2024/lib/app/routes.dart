// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: RouteManager CLASS
// PURPOSE:

import 'package:flutter/material.dart';
import 'package:studyapp_2024/features/authentication/presentation/pass_verify_page.dart';
import 'package:studyapp_2024/features/authentication/presentation/reset_pass_page.dart';
import 'package:studyapp_2024/features/authentication/presentation/stud_login_page.dart';
import 'package:studyapp_2024/features/authentication/presentation/stud_register_page.dart';
import 'package:studyapp_2024/features/authentication/presentation/stud_verify_page.dart';
import 'package:studyapp_2024/features/calendar/presentation/calendar_page.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_home_page.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_messages_page.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_info_page.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_member_page.dart';
import 'package:studyapp_2024/features/chat/presentation/chat_report_page.dart';
import 'package:studyapp_2024/features/firebase/presentation/storage_list.dart.dart';
import 'package:studyapp_2024/features/flashcards/presentation/add_flashcard_page.dart';
import 'package:studyapp_2024/features/flashcards/presentation/create_flashcard_page.dart';
import 'package:studyapp_2024/features/flashcards/presentation/flashcard_results_page.dart';
import 'package:studyapp_2024/features/flashcards/presentation/flashcard_home_page.dart';
import 'package:studyapp_2024/features/flashcards/presentation/practice_flashcard_page.dart';
import 'package:studyapp_2024/features/home/presentation/stud_main_page.dart';
import 'package:studyapp_2024/features/notes/presentation/explore_notes.dart.dart';
import 'package:studyapp_2024/features/notes/presentation/folder_page.dart.dart';
import 'package:studyapp_2024/features/notes/presentation/generate_question.dart';
import 'package:studyapp_2024/features/notes/presentation/notes_details.dart';
import 'package:studyapp_2024/features/notes/presentation/notes_page.dart';
import 'package:studyapp_2024/features/onboarding/landing_page.dart';
import 'package:studyapp_2024/features/onboarding/onboarding_page.dart';
import 'package:studyapp_2024/features/profile/presentation/stud_profile_edit_page.dart';
import 'package:studyapp_2024/features/profile/presentation/stud_profile_page.dart';

class RouteManager {
  //----- ONBOARDING & AUTHENTICATION -----//
  static const String onboardingPage = '/';
  static const String landingPage = '/landingPage';
  static const String studLogPage = '/studlogPage';
  static const String studRegPage = '/studRegPage';
  static const String emailVerifyPage = '/emailVerifyPage';
  static const String passResetPage = '/passResetPage';
  static const String resetPassPage = '/resetPassPage';
  static const String studMainPage = '/studMainPage';
  static const String profilePage = '/profilePage';
  static const String profileEditPage = '/profileEditPage';

  //----- NOTES -----//
  static const String notesPage = '/notes';
  static const String generateQuestionPage = '/generateQuestionPage';
  static const String foldersPage = '/folders';
  static const String createNotePage = '/createNote';
  static const String noteDetailPage = '/noteDetail';

  static const String storageListPage = '/storageList';
  static const String exploreNotes = '/exploreNotes';

  //----- CHATS -----//
  static const String chatHomePage = '/chatHomePage';
  static const String groupChatPage = '/groupChatPage';
  static const String groupInfoPage = '/groupInfoPage';
  static const String memberDetails = '/memberDetails';
  static const String userReportPage = '/userReportPage';
  static const String reportNotifyPage = '/reportNotifyPage';
  static const String groupInvitePage = '/groupInvitePage';

  //----- CALENDAR -----//
  static const String calendarPage = '/calendarPage';

  //----- FLASHCARDS -----//
  static const String flashcardHomePage = '/flashcardHomePage';
  static const String flashcardAddPage = '/flashcardAddPage';
  static const String flashcardCreatePage = '/flashcardCreatePage';
  static const String flashcardPracticePage = '/flashcardPracticePage';
  static const String flashcardResultPage = '/flashcardResultPage';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case onboardingPage:
        return MaterialPageRoute(
          builder: (context) => const OnboardingPage(),
        );

      case landingPage:
        return MaterialPageRoute(
          builder: (context) => const LandingPage(),
        );

      case studLogPage:
        return MaterialPageRoute(
          builder: (context) => const StudLogPage(),
        );

      case studRegPage:
        return MaterialPageRoute(
          builder: (context) => const StudRegPage(),
        );

      case emailVerifyPage:
        final email = settings.arguments as String;
        return MaterialPageRoute(
          builder: (context) => EmailVerifyPage(email: email),
        );

      case passResetPage:
        final email = settings.arguments as String;
        return MaterialPageRoute(
          builder: (context) => PassVerifyPage(email: email),
        );

      case resetPassPage:
        final email = settings.arguments as String;

        return MaterialPageRoute(
          builder: (context) => ResetPassPage(email: email),
        );

      //----- STUDENT HOME PAGE NAVIGATION -----//
      case studMainPage:
        return MaterialPageRoute(
          builder: (context) => const StudMainPage(),
        );

      //----- NOTE PAGES NAVIGATION -----//
      case foldersPage:
        return MaterialPageRoute(
          builder: (context) => const FoldersPage(),
        );

      case '/notesPage':
        if (settings.arguments is Map) {
          final args = settings.arguments as Map<String, dynamic>;
          final folderId = args['folderId'] as String;
          final folderName = args['folderName'] as String;

          return MaterialPageRoute(
            builder: (context) => NotesInFolderPage(
              folderId: folderId,
              folderName: folderName,
            ),
          );
        }
        throw const FormatException('Missing arguments for notes page');

      case generateQuestionPage:
        if (settings.arguments is Map) {
          final args = settings.arguments as Map<String, dynamic>;
          final noteId = args['noteId'] as String;
          final userId = args['userId'] as String;
          final folderId = args['folderId'] as String;

          return MaterialPageRoute(
            builder: (context) => GenerateQuestionPage(
              noteId: noteId,
              userId: userId,
              folderId: folderId,
            ),
          );
        }
        throw const FormatException(
            'Missing arguments for generate question page');

      case noteDetailPage:
        if (settings.arguments is Map) {
          final args = settings.arguments as Map<String, dynamic>;
          final noteId = args['noteId'] as String;
          final folderId = args['folderId'] as String;
          final userId = args['userId'] as String; // Add userId

          return MaterialPageRoute(
            builder: (context) => NoteDetailPage(
              noteId: noteId,
              folderId: folderId,
              userId: userId, // Pass the userId here
            ),
          );
        }
        throw const FormatException('Missing arguments for note detail page');

      case '/exploreNotes':
        return MaterialPageRoute(
          builder: (context) =>
              const ExploreNotes(), // Change to StorageListScreen
        );

      case '/storageList':
        return MaterialPageRoute(
          builder: (context) =>
              const StorageListScreen(), // Change to StorageListScreen
        );

      //----- PROFILE PAGES NAVIGATION -----//
      case profilePage:
        return MaterialPageRoute(
          builder: (context) => const StudProfilePage(),
        );

      case profileEditPage:
        return MaterialPageRoute(
          builder: (context) => const StudProfileEdit(),
        );

      //----- CHAT PAGES NAVIGATION -----//
      case chatHomePage:
        return MaterialPageRoute(
          builder: (context) => const ChatHomePage(),
        );

      case groupInfoPage:
        return MaterialPageRoute(
          builder: (context) => const ChatInfoPage(
            groupId: '',
            groupName: '',
          ),
        );

      case groupChatPage:
        if (settings.arguments is Map) {
          final args = settings.arguments as Map<String, dynamic>;
          final groupId = args['groupId'] as String;
          final groupName = args['groupName'] as String;

          return MaterialPageRoute(
            builder: (context) => ChatMessagePage(
              groupId: groupId,
              groupName: groupName,
            ),
          );
        }
        throw const FormatException('Missing arguments for student chat page');

      case memberDetails:
        final args = settings.arguments as Map<String, dynamic>?;
        if (args != null &&
            args.containsKey('userId') &&
            args.containsKey('groupId')) {
          return MaterialPageRoute(
            builder: (context) => ChatMemberPage(
              userId: args['userId'] as String,
              groupId: args['groupId'] as String,
              groupName: args['groupName'],
            ),
          );
        }
        throw ArgumentError('Invalid arguments for MemberDetailsPage');

      case RouteManager.userReportPage:
        final args = settings.arguments as Map<String, dynamic>?;
        if (args != null &&
            args.containsKey('userId') &&
            args.containsKey('groupId') &&
            args.containsKey('groupName')) {
          final userId = args['userId'] as String;
          final groupId = args['groupId'] as String;
          final groupName = args['groupName'] as String;
          return MaterialPageRoute(
            builder: (context) => ChatReportPage(
                userId: userId, groupId: groupId, groupName: groupName),
          );
        }
        throw ArgumentError('Invalid arguments for ReportUserPage');

      //----- CALENDAR PAGES NAVIGATION -----//
      case calendarPage:
        return MaterialPageRoute(
          builder: (context) => const CalendarHomePage(),
        );

      //----- FLASHCARD PAGES NAVIGATION -----//
      case flashcardHomePage:
        return MaterialPageRoute(
          builder: (context) => const FlashcardHomePage(),
        );

      case flashcardCreatePage:
        return MaterialPageRoute(
          builder: (context) => const AddFlashcardPage(
            setId: '',
          ),
        );

      case flashcardAddPage:
        return MaterialPageRoute(
          builder: (context) => const CreateFlashcardPage(),
        );

      case flashcardPracticePage:
        return MaterialPageRoute(
          builder: (context) => const PracticeFlashcardPage(
            setId: '',
          ),
        );

      case flashcardResultPage:
        return MaterialPageRoute(
          builder: (context) => const FlashcardResultPage(
            flashcards: [],
          ),
        );

      default:
        throw const FormatException('Page does not exist.');
    }
  }
} //END OF RouteManager CLASS
