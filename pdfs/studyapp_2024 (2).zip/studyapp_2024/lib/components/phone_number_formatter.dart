import 'package:flutter/services.dart';

class PhoneFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    // Ensure that the user is not deleting characters from the middle of the text
    if (newValue.text.length < oldValue.text.length) {
      return newValue;
    }

    String formatted = _formatPhoneNumber(newValue.text);

    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  String _formatPhoneNumber(String input) {
    // Get only numbers from the input
    String clean = input.replaceAll(RegExp(r'[^0-9]'), '');

    // Ensure that the length of the phone number is less than or equal to 10 digits
    if (clean.length > 10) {
      clean = clean.substring(0, 10);
    }

    // Add space separators dynamically
    String formattedNumber = '';
    for (int i = 0; i < clean.length; i++) {
      if (i == 3 || i == 6) {
        formattedNumber += '-'; // Add space after the 3rd and 6th digit
      }
      formattedNumber += clean[i];
    }

    return formattedNumber;
  }
}
