//Package for email validator
import 'package:email_validator/email_validator.dart';

//Email Validation
String? validateEmail(String? email) {
  if (email == null || email.isEmpty) {
    return 'Please enter your email address';
  }

  if (!EmailValidator.validate(email)) {
    return 'Please enter a valid email address.';
  }

  return null;
} //end of validateEmail Function

//First Name Validation
String? validateFirstName(String? firstName) {
  if (firstName == null || firstName.isEmpty) {
    return "Please enter your First name";
  }
  return null;
} //end of validateFirstName Function

//Surname Validation
String? validateSurname(String? surname) {
  if (surname == null || surname.isEmpty) {
    return "Please enter your Surname";
  }
  return null;
} //end of validateSurname Function

//ID-Number Validation
String? validateIdNum(String? idNum) {
  if (idNum == null || idNum.isEmpty) {
    return "Please enter your RSA Identification Number.";
  }

  if (idNum.length < 13) {
    return "RSA Identification Number must be 13 digits long";
  }

  return null;
} //end of validateIdNum Function

//Phone Number Validation
String? validatePhoneNum(String? phoneNum) {
  if (phoneNum == null || phoneNum.isEmpty) {
    return "Please enter your Phone number.";
  }

  final hasPattern = RegExp(r'^0\d{2}-\d{3}-\d{4}$');

  if (!hasPattern.hasMatch(phoneNum)) {
    return 'Invalid phone number format. Phone number must start with 0 (e.g. 021 123 1234).';
  }
  return null;
} //end of validatePhoneNum Function

// Date of Birth Validation
String? validateDateOfBirth(String? dateOfBirth) {
  if (dateOfBirth == null || dateOfBirth.isEmpty) {
    return 'Please select a date';
  }
  final DateTime? date = parseDate(dateOfBirth);
  if (date == null) {
    return 'Invalid date format. Use dd/MM/yyyy';
  }
  if (date.isBefore(DateTime(1900)) || date.isAfter(DateTime.now())) {
    return 'Date must be between 01/01/1900 and today';
  }
  return null;
}

// Utility function to parse date in dd/MM/yyyy format
DateTime? parseDate(String dateStr) {
  try {
    final parts = dateStr.split('/');
    if (parts.length != 3) return null;
    final day = int.parse(parts[0]);
    final month = int.parse(parts[1]);
    final year = int.parse(parts[2]);
    return DateTime(year, month, day);
  } catch (e) {
    return null;
  }
} //end of validateDateOfBirth Function

//Password Validation
String? validatePassword(String? password) {
  if (password == null || password.isEmpty) {
    return 'Please enter your password';
  }

  //Password must only be 8 characters long
  if (password.length < 8) {
    return 'Your password is too short! \nPassword must be 8 characters long';
  }

  //Password should contain at least 1 special symbol
  final hasSymbol = RegExp(r'[!@#\$&*~]');
  if (!hasSymbol.hasMatch(password)) {
    return 'Your password must contain at least one special symbol.\n eg: "!@#\$&*~"';
  }

  //Password should contain at least 1 lowercase letter
  final hasLowercase = RegExp(r'[a-z]');
  if (!hasLowercase.hasMatch(password)) {
    return 'Your password must contain at least one lowercase letter';
  }

  //Password should contain at least 1 uppercase letter
  final hasUppercase = RegExp(r'[A-Z]');
  if (!hasUppercase.hasMatch(password)) {
    return 'Your password must contain at least one uppercase letter';
  }

  //Password should contain at least 1 number
  final hasNumber = RegExp(r'[0-9]');
  if (!hasNumber.hasMatch(password)) {
    return 'Your password must contain at least one digit';
  }
  return null;
} //end of validatePassword Function

//Validate existing password
String? validateConfirmPassword(String? password, String? confirmPassword) {
  if (confirmPassword == null || confirmPassword.isEmpty) {
    return 'Please confirm your password';
  }

  if (password != confirmPassword) {
    return 'Passwords do not match';
  }

  return null;
} //end of validateConfirmPassword
