import 'package:flutter/material.dart';

class MySnackbar {
  final String message;

  const MySnackbar({
    required this.message,
  });

  void showSnackBar(BuildContext context) {
    final snackBar = SnackBar(
      content: Text(
        message,
        style: const TextStyle(color: Colors.black),
      ),
      backgroundColor: const Color.fromARGB(255, 228, 228, 228),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }
}
