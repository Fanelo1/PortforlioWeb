import 'dart:math';
import 'package:flutter/services.dart';

class DateFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    // Allow deletion
    if (newValue.text.length < oldValue.text.length) {
      return newValue;
    }

    String formatted = _formatDate(newValue.text);
    return newValue.copyWith(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  String _formatDate(String input) {
    // Remove non-numeric characters
    String clean = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (clean.length > 8) {
      clean = clean.substring(0, 8); // Limit to 8 characters (DDMMYYYY)
    }

    String day = '';
    String month = '';
    String year = '';

    // Extract day, month, year parts
    if (clean.length >= 2) {
      day = clean.substring(0, 2);
    }
    if (clean.length >= 4) {
      month = clean.substring(2, 4);
    }
    if (clean.length > 4) {
      year = clean.substring(4, 8);
    }

    // Validate day
    if (day.isNotEmpty) {
      int dayValue = int.tryParse(day) ?? 0;
      int monthValue = int.tryParse(month) ?? 1;
      int yearValue = int.tryParse(year) ?? DateTime.now().year;
      int maxDay = _maxDaysInMonth(monthValue, yearValue);
      day = min(dayValue, maxDay).toString().padLeft(2, '0');
    }

    // Validate month
    if (month.isNotEmpty) {
      int monthValue = int.tryParse(month) ?? 0;
      month = min(monthValue, 12).toString().padLeft(2, '0');
    }

    // Validate year
    if (year.isNotEmpty) {
      int currentYear = DateTime.now().year;
      int yearValue = int.tryParse(year) ?? currentYear;
      year = min(yearValue, currentYear).toString();
    }

    // Construct the formatted date
    String formattedDate = day;
    if (month.isNotEmpty) formattedDate += '/$month';
    if (year.isNotEmpty) formattedDate += '/$year';

    return formattedDate;
  }

  // Get maximum days in a given month/year
  int _maxDaysInMonth(int month, int year) {
    if (month < 1 || month > 12) return 0;
    return DateTime(year, month + 1, 0).day;
  }
}
