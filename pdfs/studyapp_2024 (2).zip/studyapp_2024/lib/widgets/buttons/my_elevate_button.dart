// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyFloatingButton WIDGET CLASS (220024654, LK MAASDORP)
// PURPOSE: The custom button widget that is used throughout the entire application

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

enum ElevatedButtonType { filled, bordered }

class MyElevatedButton extends StatelessWidget {
  final String buttonTitle;
  final Function()? onTap;
  final Color color;
  final ElevatedButtonType elevatedButtonType;
  final IconData? icon;
  final IconData? fontAwesomeIcon;
  final double? fontSize;

  const MyElevatedButton({
    super.key,
    required this.buttonTitle,
    required this.onTap,
    required this.color,
    this.elevatedButtonType = ElevatedButtonType.filled,
    this.icon,
    this.fontAwesomeIcon,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    //----- ENSURING THE MY ELEVATEDBUTTON WIDGET IS RESPONSIVE ON ALL SCREENS -----//
    double screenWidth = MediaQuery.of(context).size.width;
    double defaultFontSize = screenWidth * 0.04;
    double iconSize = screenWidth * 0.05;
    double buttonHeight = screenWidth * 0.15;
    double paddingHorizontal = screenWidth * 0.04;
    double paddingVertical = screenWidth * 0.03;

    return SizedBox(
      height: buttonHeight,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: elevatedButtonType == ElevatedButtonType.filled
              ? color
              : Colors.white,
          foregroundColor: elevatedButtonType == ElevatedButtonType.filled
              ? Colors.white
              : color,
          padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal,
            vertical: paddingVertical,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: elevatedButtonType == ElevatedButtonType.bordered
                ? BorderSide(color: color, width: 2)
                : BorderSide.none,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //----- FORMATTING FOR MATERIAL & CUPERTINO ICONS -----//
            if (icon != null)
              Icon(
                icon,
                color: elevatedButtonType == ElevatedButtonType.filled
                    ? Colors.white
                    : color,
                size: iconSize,
              ),

            //----- FORMATTING FOR FONTAWESOME ICONS -----//
            if (fontAwesomeIcon != null)
              FaIcon(
                fontAwesomeIcon,
                color: elevatedButtonType == ElevatedButtonType.filled
                    ? Colors.white
                    : color,
                size: iconSize,
              ),
            if (icon != null || fontAwesomeIcon != null)
              const SizedBox(width: 8),

            //----- BUTTON FONT FORMATTING -----//
            Text(
              buttonTitle,
              style: TextStyle(
                color: elevatedButtonType == ElevatedButtonType.filled
                    ? Colors.white
                    : color,
                fontWeight: FontWeight.bold,
                fontSize: fontSize ?? defaultFontSize,
              ),
            ),
          ],
        ),
      ),
    );
  }
} // END OF MyElevatedButton WIDGET CLASS
