// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyButton WIDGET CLASS (220024654, LK MAASDORP)
// PURPOSE: The custom button widget that is used throughout the entire application

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

enum ButtonType { filled, bordered }

class MyButton extends StatelessWidget {
  final String buttonTitle;
  final Function()? onTap;
  final Color color;
  final ButtonType buttonType;
  final IconData? icon;
  final IconData? fontAwesomeIcon;
  final double? fontSize;

  const MyButton({
    super.key,
    required this.buttonTitle,
    required this.onTap,
    required this.color,
    this.buttonType = ButtonType.filled,
    this.icon,
    this.fontAwesomeIcon,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    //----- ENSURNG THE MYBUTTON WIDGET IS RESPONSIVE ON ALL SCREENS -----//
    double screenWidth = MediaQuery.of(context).size.width;
    double defaultFontSize = screenWidth * 0.04;
    double iconSize = screenWidth * 0.05;
    double buttonHeight = screenWidth * 0.15;
    double paddingHorizontal = screenWidth * 0.04;
    double paddingVertical = screenWidth * 0.03;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: buttonHeight,
        padding: EdgeInsets.symmetric(
            horizontal: paddingHorizontal, vertical: paddingVertical),
        decoration: BoxDecoration(
          color: buttonType == ButtonType.filled ? color : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color, width: 2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //----- FORMATTING FOR MATERIAL & CUPERTINO ICONS -----//
            if (icon != null)
              Icon(
                icon,
                color: buttonType == ButtonType.filled ? Colors.white : color,
                size: iconSize,
              ),

            //----- FORMATTING FOR FONTAWESOME ICONS -----//
            if (fontAwesomeIcon != null)
              FaIcon(
                fontAwesomeIcon,
                color: buttonType == ButtonType.filled ? Colors.white : color,
              ),
            if (icon != null || fontAwesomeIcon != null)
              const SizedBox(width: 8),

            //----- BUTTON FONT FORMATTING -----//
            Text(
              buttonTitle,
              style: TextStyle(
                color: buttonType == ButtonType.filled ? Colors.white : color,
                fontWeight: FontWeight.bold,
                fontSize: fontSize ?? defaultFontSize,
              ),
            ),
          ],
        ),
      ),
    );
  }
} //END OF MyButton WIDGET CLASS
