import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

enum FloatingActionButtonType { filled, bordered }

class MyFloatingActionButton extends StatelessWidget {
  final String buttonTitle;
  final Function()? onTap;
  final Color color;
  final FloatingActionButtonType floatingActionButtonType;
  final IconData? icon;
  final IconData? fontAwesomeIcon;
  final double? fontSize;

  const MyFloatingActionButton({
    super.key,
    required this.buttonTitle,
    required this.onTap,
    required this.color,
    this.floatingActionButtonType = FloatingActionButtonType.filled,
    this.icon,
    this.fontAwesomeIcon,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: onTap,
      backgroundColor:
          floatingActionButtonType == FloatingActionButtonType.filled
              ? color
              : Colors.white,
      foregroundColor:
          floatingActionButtonType == FloatingActionButtonType.filled
              ? Colors.white
              : color,
      label: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Material & Cupertino icons
          if (icon != null)
            Icon(
              icon,
              color: floatingActionButtonType == FloatingActionButtonType.filled
                  ? Colors.white
                  : color,
            ),

          // FontAwesome icons
          if (fontAwesomeIcon != null)
            FaIcon(
              fontAwesomeIcon,
              color: floatingActionButtonType == FloatingActionButtonType.filled
                  ? Colors.white
                  : color,
            ),
          if (icon != null || fontAwesomeIcon != null) const SizedBox(width: 8),

          // Button font formatting
          Text(
            buttonTitle,
            style: TextStyle(
              color: floatingActionButtonType == FloatingActionButtonType.filled
                  ? Colors.white
                  : color,
              fontWeight: FontWeight.bold,
              fontSize: fontSize ?? 16, // Default font size
            ),
          ),
        ],
      ),
      shape: floatingActionButtonType == FloatingActionButtonType.bordered
          ? RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
              side: BorderSide(color: color, width: 2),
            )
          : null,
    );
  }
}
