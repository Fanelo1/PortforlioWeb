// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyListTile CLASS (220024654 LK MAASDORP)
// PURPOSE: The custom list tile widget that is used throughout the entire application

import 'package:flutter/material.dart';

class MyListTile extends StatelessWidget {
  final String? title;
  final String? subtitle;
  final IconData? leadingIcon;
  final Color? leadingIconColor;
  final IconData? trailingIcon;
  final Color? trailingIconColor;
  final VoidCallback? onTap;
  final List<PopupMenuEntry<String>>? popupMenuItems;
  final void Function(String)? onSelected;
  final Color containerColor;

  const MyListTile({
    super.key,
    this.title,
    this.subtitle,
    this.leadingIcon,
    this.leadingIconColor,
    this.trailingIcon,
    this.trailingIconColor,
    this.onTap,
    this.popupMenuItems,
    this.onSelected,
    this.containerColor = Colors.blue,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Container(
          height: 85,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: InkWell(
            onTap: onTap,
            child: Row(
              children: <Widget>[
                if (leadingIcon != null)
                  Container(
                    decoration: BoxDecoration(
                      color: containerColor,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(10),
                        bottomLeft: Radius.circular(10),
                      ),
                    ),
                    width: 70,
                    height: double.infinity,
                    child: Icon(
                      leadingIcon,
                      color: leadingIconColor ?? Colors.white,
                    ),
                  ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      if (title != null)
                        Text(
                          title!,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      if (subtitle != null)
                        Text(
                          subtitle!,
                          style: const TextStyle(color: Colors.grey),
                        ),
                    ],
                  ),
                ),
                if (trailingIcon != null)
                  Positioned(
                    top: 10,
                    right: 10,
                    child: PopupMenuButton<String>(
                      icon: Icon(
                        trailingIcon,
                        color: trailingIconColor ?? Colors.blue,
                        size: 18,
                      ),
                      onSelected: onSelected,
                      itemBuilder: (context) => popupMenuItems ?? [],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
} //END OF MyListTile CLASS
