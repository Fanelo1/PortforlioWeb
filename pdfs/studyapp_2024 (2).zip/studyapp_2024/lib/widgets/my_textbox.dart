// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyTextbox CLASS (220024654, LK MAASDORP)
// PURPOSE: Custom widget for the text boxes in our application

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MyTextbox extends StatelessWidget {
  final Text dataField;
  const MyTextbox({super.key, required this.dataField});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(
                Radius.circular(10),
              ),
              border: Border.all(
                color: const Color.fromARGB(255, 145, 192, 239),
              ),
            ),
            padding: const EdgeInsets.all(15.0),
            child: dataField,
          ),
        ),
      ],
    );
  }
} //END OF MyTextbox CLASS
