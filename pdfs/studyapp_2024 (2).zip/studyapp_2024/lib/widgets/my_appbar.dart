// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyAppBar CLASS (220024654, LK MAASDORP)
// PURPOSE: The custom appbar widget that is used throughout the entire application

import 'package:flutter/material.dart';

class MyAppBar extends StatelessWidget implements PreferredSizeWidget {
  final Widget title;
  final IconData? leadingIcon;
  final VoidCallback? onLeadingIconPressed;
  final Future<void> Function()? onBackButtonPressed;
  final List<Widget>? actions;
  final double height;

  const MyAppBar({
    super.key,
    required this.title,
    this.leadingIcon,
    this.onLeadingIconPressed,
    this.onBackButtonPressed,
    this.actions,
    this.height = kToolbarHeight + 20,
  });

  @override
  Size get preferredSize => Size.fromHeight(height);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Colors.grey[300]!,
            width: 1.0,
          ),
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(10),
          bottomRight: Radius.circular(10),
        ),
      ),
      child: AppBar(
        title: DefaultTextStyle(
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
            color: Colors.black,
          ),
          child: title,
        ),
        leading: leadingIcon != null
            ? IconButton(
                icon: Icon(leadingIcon),
                onPressed: () async {
                  if (onBackButtonPressed != null) {
                    await onBackButtonPressed!();
                  } else if (onLeadingIconPressed != null) {
                    onLeadingIconPressed!();
                  }
                },
              )
            : null,
        actions: actions,
      ),
    );
  }
} //END OF MyAppBar WIDGET CLASS 
