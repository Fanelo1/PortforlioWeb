// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyDivider CLASS (220024654 LK MAASDORP)
// PURPOSE: Custom widget for the dividers in our forms

import 'package:flutter/material.dart';

class MyDivider extends StatelessWidget {
  final String dividerText;

  const MyDivider({
    super.key,
    required this.dividerText,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      child: Row(
        children: [
          const Expanded(
            child: Divider(
              thickness: 0.5,
              color: Colors.grey,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Text(
              dividerText,
              style: const TextStyle(
                color: Colors.grey,
              ),
            ),
          ),
          const Expanded(
            child: Divider(
              thickness: 0.5,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
}// END OF MyDivider CLASS
