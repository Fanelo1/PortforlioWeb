// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyLeftDivider CLASS (220024654 LK MAASDORP)
// PURPOSE: Custom widget for the left aligned dividers in our forms

import 'package:flutter/material.dart';

class MyLeftDivider extends StatelessWidget {
  final String dividerText;
  final double fontSize;

  const MyLeftDivider({
    super.key,
    required this.dividerText,
    required this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 10.0),
            child: Text(
              dividerText,
              style: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
          const Expanded(
            child: Divider(
              thickness: 0.5,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
} //END OF MyLeftDivider CLASS
