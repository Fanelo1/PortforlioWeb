// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: LoadingDialog CLASS (220024654, LK MAASDORP)
// PURPOSE: The custom loading circle indicator widget that is used throughout the entire application

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class LoadingDialog extends StatelessWidget {
  final String? message;
  final IconData? icon;
  final Color? iconColor;

  const LoadingDialog({
    super.key,
    this.message,
    this.icon = CupertinoIcons.person_crop_circle_badge_checkmark,
    this.iconColor = Colors.blue,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 20),
            if (message != null) Icon(icon, color: iconColor, size: 40),
            Text(
              message!,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
} //END OF LoadingDialog CLASS
