// ITC327W_B (GROUP A: Inteli-Ed, Student Study Application)
// NAME: MyDialogBox WIDGET CLASS (220024654, LK MAASDORP)
// PURPOSE: The custom alert dialog box widget that is used throughout the entire application

import 'package:flutter/material.dart';
import 'package:studyapp_2024/widgets/buttons/my_button.dart';

class MyDialogBox extends StatelessWidget {
  final IconData? icon;
  final Color? iconColor;
  final String? title;
  final Widget? content;
  final List<Widget>? buttons;
  final bool showProgressIndicator;
  final bool? hideCloseButton;
  final String? cancelButtonTitle;
  final String? confirmButtonTitle;
  final VoidCallback? cancelButtonOnPressed;
  final VoidCallback? confirmButtonOnPressed;
  final bool showButtonRow;
  final double? contentFontSize;
  final double? contentHorizontalPadding;
  final double? contentVerticalPadding;
  final Color? borderColor;
  final double borderWidth;

  const MyDialogBox({
    super.key,
    this.icon,
    this.iconColor,
    this.title,
    this.content,
    this.buttons,
    this.showProgressIndicator = false,
    this.hideCloseButton,
    this.cancelButtonTitle,
    this.confirmButtonTitle,
    this.cancelButtonOnPressed,
    this.confirmButtonOnPressed,
    this.showButtonRow = false,
    this.contentFontSize,
    this.contentHorizontalPadding,
    this.contentVerticalPadding,
    this.borderColor,
    this.borderWidth = 2.0,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double iconSize = screenWidth * 0.2;
    double titleFontSize = screenWidth * 0.05;
    double titleHorizontalPadding = screenWidth * 0.05;

    return Center(
      child: AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
            color: borderColor ?? const Color.fromARGB(255, 139, 139, 139),
            width: borderWidth,
          ),
        ),
        title: Stack(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(
                horizontal: titleHorizontalPadding,
              ),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null)
                      Icon(
                        icon,
                        size: iconSize,
                        color: iconColor ?? Colors.blue,
                      ),
                    if (title != null)
                      Text(
                        title!,
                        style: TextStyle(
                          fontSize: titleFontSize,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    if (showProgressIndicator)
                      const Padding(
                        padding: EdgeInsets.only(top: 20),
                        child: CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.green),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            if (hideCloseButton != true)
              Positioned(
                right: 0,
                top: 0,
                child: IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
          ],
        ),
        content: content,
        actions: buttons ??
            (showButtonRow
                ? [
                    if (cancelButtonOnPressed != null)
                      MyButton(
                        buttonTitle: cancelButtonTitle ?? 'Cancel',
                        onTap: cancelButtonOnPressed,
                        color: Colors.red,
                        buttonType: ButtonType.bordered,
                      ),
                    if (confirmButtonOnPressed != null)
                      MyButton(
                        buttonTitle: confirmButtonTitle ?? 'Confirm',
                        onTap: confirmButtonOnPressed,
                        color: Colors.green,
                        buttonType: ButtonType.filled,
                      ),
                  ]
                : []),
      ),
    );
  }
}
