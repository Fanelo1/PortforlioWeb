# studyapp_2024

A new Flutter project.
