package com.example.studyApp_wil

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
