﻿using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApps1.Models;

namespace WebApps1.Controllers
{
    public class HomeController : Controller
    {
        private const string DefaultName = "Admin User";
        private const string DefaultEmail = "admin@example.com";
        private const string DefaultPassword = "adminPassword123!";

        private readonly ILogger<HomeController> _logger;
        private readonly FirebaseAuth _firebaseAuth;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _firebaseAuth = FirebaseAuth.DefaultInstance;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GoogleLogin()
        {
            return View();
        }

        public IActionResult AppleLogin()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (model.Email == DefaultEmail && model.Password == DefaultPassword && model.Name == DefaultName)
                {
                    HttpContext.Session.SetString("UserRole", "Admin");
                    HttpContext.Session.SetString("UserEmail", model.Email);
                    HttpContext.Session.SetString("UserName", model.Name);
                    return RedirectToAction("Dashboard", "Admin");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid name, email or password.");
                    return View(model);
                }
            }
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VerifyToken([FromBody] string idToken)
        {
            try
            {
                FirebaseToken decodedToken = await _firebaseAuth.VerifyIdTokenAsync(idToken);
                string uid = decodedToken.Uid;
                string? email = decodedToken.Claims.TryGetValue("email", out object emailObj) ? emailObj.ToString() : null;
                string? name = decodedToken.Claims.TryGetValue("name", out object nameObj) ? nameObj.ToString() : null;

                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(name))
                {
                    return BadRequest("Unable to retrieve user email or name");
                }

                bool isAuthorized = IsAuthorizedUser(email);

                if (isAuthorized)
                {
                    HttpContext.Session.SetString("UserRole", "Admin");
                    HttpContext.Session.SetString("UserEmail", email);
                    HttpContext.Session.SetString("UserName", name);
                    return RedirectToAction("Dashboard", "Admin");
                }
                else
                {
                    return Unauthorized("User is not authorized");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Invalid token");
            }
        }

        private bool IsAuthorizedUser(string email)
        {
            var authorizedEmails = new List<string>
            {
                "mabasafanelo99@gmail.com",
                "leak.maasdorp@gmail.com",
                "17morake.apex@gmail.com",
                "likhayanete9@gmail.com",
                "mateboho06@gmail.com",
                DefaultEmail
                
            };

            return authorizedEmails.Contains(email.ToLower());
        }

        private bool AuthenticateUser(string email, string password)
        {
            
            // Return true if the user is authenticated, false otherwise
            return true; 
        }

        private async Task<bool> IsAdmin(string email)
        {            
            return email.StartsWith("admin");
        }
    }
}
