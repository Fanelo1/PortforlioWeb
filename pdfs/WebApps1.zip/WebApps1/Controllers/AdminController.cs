﻿using FirebaseAdmin.Auth;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using Microsoft.AspNetCore.Mvc;
using WebApps1.Services;
using WebApps1.Models;
using Microsoft.AspNetCore.Authorization;
using Google.Cloud.Firestore;
using Google.Cloud.Firestore.V1;
using Microsoft.Extensions.Configuration;
using System.Net.Mail;
using System.Net;
using SendGrid;
using SendGrid.Helpers.Mail;
using MailKit.Security;
using MimeKit;


namespace WebApps1.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly FirebaseUserService _userService;

        //constructor for dependency injection
        private readonly FirebaseUserService _firebaseUserService;
        private readonly FileUploadService _fileUploadService;
        private readonly IConfiguration _configuration;
        private readonly FirestoreDb _firestoreDb;
        private readonly ILogger<AdminController> _logger;

        public AdminController(IConfiguration configuration, FirebaseUserService firebaseUserService, FileUploadService fileUploadService, FirestoreDb firestoreDb, ILogger<AdminController> logger)
        {
            _firebaseUserService = firebaseUserService;
            _fileUploadService = fileUploadService;
            _firestoreDb = firestoreDb;
            _configuration = configuration;
            _logger = logger;

            // Initialize Firebase Admin SDK 
            if (FirebaseApp.DefaultInstance == null)
            {
                FirebaseApp.Create(new AppOptions()
                {
                    Credential = GoogleCredential.FromFile("C:\\Users\\FANELO\\Documents\\IT\\WIL\\WebApps1 (4)\\WebApps1\\Privatekey\\studyappfirebase-1698b-firebase-adminsdk-vq6p6-f00124054b.json"),
                });
            }
        }        

        public async Task<IActionResult> Dashboard()
        {
            var allUsers = await _firebaseUserService.GetFirebaseUsers();
            var today = DateTime.UtcNow.Date;

            var viewModel = new DashboardViewModel
            {
                TotalStudents = allUsers.Count,
                MaxStudents = 300,
                NewcomersToday = allUsers.Where(u => u.RegistrationDate.Date == today)
                                         .Select(u => new UserViewModel
                                         {
                                             DisplayName = u.DisplayName,
                                             Email = u.Email
                                         })
                                         .ToList()
            };

            return View(viewModel);
        }

        private bool IsUserAuthenticated()
        {
            return true; 
        }

        private string GetUserIdFromAuthToken()
        {
            return "oiwv63YcLZZ4I0snS9CSTsNCPXg2"; 
        }


        public async Task<IActionResult> Users()
        {
            var users = await _firebaseUserService.GetFirebaseUsers();
            _logger.LogInformation($"Retrieved {users.Count} users");
            foreach (var user in users)
            {
                _logger.LogInformation($"User in controller: {user.DisplayName}, Role: {user.Role}, Last Login: {user.LastLoginTimestamp}");
            }
            return View(users);
        }

        private async Task<List<UserRecord>> GetFirebaseUsers()
        {
            var users = new List<UserRecord>();
            var pagedEnumerable = FirebaseAuth.DefaultInstance.ListUsersAsync(null);
            var responses = pagedEnumerable.AsRawResponses().GetAsyncEnumerator();

            while (await responses.MoveNextAsync())
            {
                ExportedUserRecords response = responses.Current;
                users.AddRange(response.Users);
            }

            return users;
        }

        public async Task<IActionResult> FileUpload(string searchQuery, string orderBy = "Name", SortDirection orderDirection = SortDirection.Ascending)
        {
            var folderStructure = await _fileUploadService.GetFolderStructureAsync();

            var modules = folderStructure.SubFolders.Select(f => new ModuleViewModel
            {
                Year = "2024",
                Name = f.Name
            }).ToList();

            if (!string.IsNullOrEmpty(searchQuery))
            {
                modules = modules.Where(m => m.Name.Contains(searchQuery, StringComparison.InvariantCultureIgnoreCase)).ToList();
            }

            modules = modules.OrderBy(m => m, new ModuleComparer(orderDirection)).ToList();

            var viewModel = new FileUploadViewModel
            {
                Folders = folderStructure.SubFolders.Select(f => f.Name).ToList(),
                CurrentFolder = "Notes",
                FolderStructure = folderStructure,
                Modules = modules,
                SearchQuery = searchQuery,
                OrderBy = orderBy,
                OrderDirection = orderDirection
            };

            return View(viewModel);
        }

        public async Task<IActionResult> ViewDetails(string moduleName)
        {
            var files = await _fileUploadService.GetFilesInFolderAsync(moduleName);
            var viewModel = new ModuleDetailsViewModel
            {
                ModuleName = moduleName,
                Files = files
            };
            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file, string moduleName)
        {
            try
            {
                await _fileUploadService.UploadFileAsync(moduleName, file);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateModule(string moduleName)
        {
            try
            {
                await _fileUploadService.CreateFolderAsync(moduleName);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public async Task<IActionResult> ReportNotification(string searchQuery, string sortBy = "ReportedAt", string sortOrder = "desc")
        {
            try
            {
                var reports = await GetReportsFromFirestore();

                // Apply search filter
                if (!string.IsNullOrEmpty(searchQuery))
                {
                    reports = reports.Where(r =>
                        r.GroupName.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) ||
                        r.Reason.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) ||
                        r.ReportedBy.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) ||
                        r.ReportedUserId.Contains(searchQuery, StringComparison.OrdinalIgnoreCase)
                    ).ToList();
                }

                // Apply sorting
                reports = sortOrder.ToLower() == "asc"
                    ? reports.OrderBy(r => r.GetType().GetProperty(sortBy).GetValue(r, null)).ToList()
                    : reports.OrderByDescending(r => r.GetType().GetProperty(sortBy).GetValue(r, null)).ToList();

                ViewBag.CurrentSort = sortBy;
                ViewBag.SortOrder = sortOrder;
                ViewBag.SearchQuery = searchQuery;

                return View(reports);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching reports from Firestore");
                return View("Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteReport(string reportId)
        {
            try
            {
                await _firestoreDb.Collection("reports").Document(reportId).DeleteAsync();
                return RedirectToAction("ReportNotification");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting report {reportId}");
                return View("Error");
            }
        }

        private async Task<List<ReportViewModel>> GetReportsFromFirestore()
        {
            var reports = new List<ReportViewModel>();
            CollectionReference reportsRef = _firestoreDb.Collection("reports");
            QuerySnapshot snapshot = await reportsRef.GetSnapshotAsync();

            foreach (DocumentSnapshot document in snapshot.Documents)
            {
                var reportData = document.ToDictionary();
                _logger.LogInformation($"Processing report with ID: {document.Id}");

                string groupId = reportData.GetValueOrDefault("Group ID", "Unknown Group ID") as string;
                string groupName = reportData.GetValueOrDefault("Group Name", "Unknown Group Name") as string;

                string reporterId = reportData.GetValueOrDefault("Reported By UserID", "Unknown") as string;
                string reportedUserId = reportData.GetValueOrDefault("Reported User ID", "Unknown User") as string;

                DateTime reportedAt = (reportData["Reported At"] as Timestamp?)?.ToDateTime() ?? DateTime.UtcNow;

                var report = new ReportViewModel
                {
                    Id = document.Id,
                    GroupId = groupId,
                    GroupName = groupName,
                    Reason = reportData.GetValueOrDefault("Reason", "No reason provided") as string,
                    ReportedAt = reportedAt,
                    ReportedBy = reportData.GetValueOrDefault("Reported By", "Unknown") as string,
                    ReportedUserId = reportedUserId,
                    ReporterFirstName = reportData.GetValueOrDefault("Reported By", "Unknown").ToString().Split(' ')[0],
                    ReporterLastName = reportData.GetValueOrDefault("Reported By", "Unknown").ToString().Split(' ').Length > 1
                        ? reportData.GetValueOrDefault("Reported By", "Unknown").ToString().Split(' ')[1]
                        : "",
                    ReportedUserFirstName = reportData.GetValueOrDefault("Reported User", "Unknown").ToString().Split(' ')[0],
                    ReportedUserLastName = reportData.GetValueOrDefault("Reported User", "Unknown").ToString().Split(' ').Length > 1
                        ? reportData.GetValueOrDefault("Reported User", "Unknown").ToString().Split(' ')[1]
                        : ""
                };
                reports.Add(report);
                _logger.LogInformation($"Added report to list: {report.Id}, Group: {report.GroupName}, Reporter: {report.ReporterFirstName} {report.ReporterLastName}, Reported User: {report.ReportedUserFirstName} {report.ReportedUserLastName}");
            }

            return reports;
        }

        private async Task<string> GetGroupName(string groupId)
        {
            if (string.IsNullOrEmpty(groupId))
            {
                return "Unknown Group";
            }

            DocumentSnapshot groupDoc = await _firestoreDb.Collection("groups").Document(groupId).GetSnapshotAsync();
            if (groupDoc.Exists)
            {
                var groupData = groupDoc.ToDictionary();
                return groupData.GetValueOrDefault("Name", "Unknown Group") as string;
            }
            return "Unknown Group";
        }

        private async Task<(string FirstName, string LastName)> GetUserDetails(string userId)
        {
            _logger.LogInformation($"Getting user details for user ID: {userId}");
            if (string.IsNullOrEmpty(userId))
            {
                _logger.LogWarning("User ID is null or empty");
                return ("Unknown", "Unknown");
            }

            DocumentSnapshot userDoc = await _firestoreDb.Collection("users").Document(userId).GetSnapshotAsync();
            _logger.LogInformation($"User document exists: {userDoc.Exists}");
            if (userDoc.Exists)
            {
                var userData = userDoc.ToDictionary();
                _logger.LogInformation($"User data: {string.Join(", ", userData.Select(kvp => $"{kvp.Key}: {kvp.Value}"))}");

                string firstName = GetUserNameField(userData, new[] { "First Name", "FirstName", "firstname", "first_name" });
                string lastName = GetUserNameField(userData, new[] { "Last Name", "LastName", "lastname", "last_name" });

                _logger.LogInformation($"Retrieved user details: {firstName} {lastName}");
                return (firstName, lastName);
            }
            _logger.LogWarning($"User document not found for ID: {userId}");
            return ("Unknown", "Unknown");
        }

        private string GetUserNameField(IDictionary<string, object> userData, string[] possibleFieldNames)
        {
            foreach (var fieldName in possibleFieldNames)
            {
                if (userData.TryGetValue(fieldName, out var value) && value is string stringValue)
                {
                    return stringValue;
                }
            }
            return "Unknown";
        }

        private T GetFieldValueOrDefault<T>(IDictionary<string, object> data, string fieldName, T defaultValue)
        {
            if (data.TryGetValue(fieldName, out object value) && value is T typedValue)
            {
                return typedValue;
            }
            _logger.LogWarning($"Field '{fieldName}' not found or has incorrect type. Using default value.");
            return defaultValue;
        }

        [HttpPost]
        public async Task<IActionResult> DeleteUser(string uid)
        {
            if (string.IsNullOrEmpty(uid))
            {
                return BadRequest("Invalid user ID");
            }

            try
            {
                if (await _firebaseUserService.IsProjectOwner(uid))
                {
                    return BadRequest("Cannot delete a project owner.");
                }

                await _firebaseUserService.DeleteUser(uid);
                return RedirectToAction("Users");
            }
            catch (Exception ex)
            {
                return View("Error", ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> EditModule(string oldName, string newName)
        {
            try
            {
                await _fileUploadService.RenameFolderAsync(oldName, newName);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteModule(string moduleName)
        {
            try
            {
                await _fileUploadService.DeleteFolderAsync(moduleName);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteFile(string filePath)
        {
            try
            {
                await _fileUploadService.DeleteFileAsync(filePath);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewProfile(string uid)
        {
            if (string.IsNullOrEmpty(uid))
            {
                return NotFound();
            }

            try
            {
                var viewModel = await _firebaseUserService.GetUserById(uid);
                if (viewModel == null)
                {
                    return NotFound();
                }

                return View(viewModel);
            }
            catch (Exception ex)
            {
                return View("Error", ex.Message);
            }
        }

        private async Task<string> GetUserEmailFromFirestore(string uid)
        {
            try
            {
                var userDoc = await _firestoreDb.Collection("users").Document(uid).GetSnapshotAsync();
                if (userDoc.Exists)
                {
                    if (userDoc.TryGetValue("Email Address", out string email))
                    {
                        return email;
                    }
                    else
                    {
                        _logger.LogWarning($"Email field not found for user {uid}. Available fields: {string.Join(", ", userDoc.ToDictionary().Keys)}");
                        return null;
                    }
                }
                _logger.LogWarning($"User document not found for uid {uid}");
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving email for user {uid}");
                return null;
            }
        }

        private async Task<bool> SendEmailAsync(string email, string subject, string message)
        {
            try
            {
                var emailMessage = new MimeMessage();
                emailMessage.From.Add(new MailboxAddress("WebAsp.netweb", _configuration["Email:Username"]));
                emailMessage.To.Add(new MailboxAddress("", email));
                emailMessage.Subject = subject;
                emailMessage.Body = new TextPart("plain") { Text = message };

                using (var client = new MailKit.Net.Smtp.SmtpClient())
                {
                    await client.ConnectAsync(_configuration["Email:SmtpServer"],
                                              int.Parse(_configuration["Email:SmtpPort"]),
                                              SecureSocketOptions.StartTls);
                    await client.AuthenticateAsync(_configuration["Email:Username"], _configuration["Email:Password"]);
                    await client.SendAsync(emailMessage);
                    await client.DisconnectAsync(true);
                }

                _logger.LogInformation($"Email sent successfully to {email}. Subject: {subject}");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to send email to {email}. Subject: {subject}. Error: {ex.Message}");
                return false;
            }
        }

        [HttpPost]
        public async Task<IActionResult> SendFeedback(string reportId, string recipient, string message)
        {
            try
            {
                // Get the report from Firestore
                DocumentSnapshot reportSnapshot = await _firestoreDb.Collection("reports").Document(reportId).GetSnapshotAsync();

                if (!reportSnapshot.Exists)
                {
                    return Json(new { success = false, message = "Report not found" });
                }

                var reportData = reportSnapshot.ToDictionary();
                string recipientUid = recipient == "reporter"
                    ? reportData["Reported By"].ToString()
                    : reportData["Reported User ID"].ToString();

                // Get the recipient's email from Firestore
                string recipientEmail = await GetUserEmailFromFirestore(recipientUid);

                if (string.IsNullOrEmpty(recipientEmail))
                {
                    return Json(new { success = false, message = $"Recipient email not found for user ID: {recipientUid}" });
                }

                // Send the email
                bool emailSent = await SendEmailAsync(recipientEmail, "Feedback Regarding Your Report", message);

                if (emailSent)
                {
                    await reportSnapshot.Reference.UpdateAsync("feedbackSent", true);
                    return Json(new { success = true });
                }
                else
                {
                    return Json(new { success = false, message = "Failed to send email" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending feedback");
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}
