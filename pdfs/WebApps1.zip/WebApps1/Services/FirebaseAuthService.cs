﻿using FirebaseAdmin.Auth;

namespace WebApps1.Services
{
    public class FirebaseAuthService
    {
        public async Task<string> VerifyIdTokenAsync(string idToken)
        {
            FirebaseToken decodedToken = await FirebaseAuth.DefaultInstance.VerifyIdTokenAsync(idToken);
            return decodedToken.Uid;
        }
    }
}
