﻿using FirebaseAdmin.Auth;
using Google.Cloud.Firestore;
using WebApps1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApps1.Services
{
    public class FirebaseUserService
    {
        private readonly FirestoreDb _firestoreDb;
        private readonly ILogger<FirebaseUserService> _logger;

        public FirebaseUserService(FirestoreDb firestoreDb, ILogger<FirebaseUserService> logger)
        {
            _firestoreDb = firestoreDb;
            _logger = logger;
        }

        public async Task<List<UserViewModel>> GetFirebaseUsers()
        {
            var users = new List<UserViewModel>();
            var pagedEnumerable = FirebaseAuth.DefaultInstance.ListUsersAsync(null);

            await foreach (var userRecord in pagedEnumerable)
            {
                var firestoreUser = await GetFirestoreUserData(userRecord.Uid);

                var displayName = await GetDisplayName(userRecord, firestoreUser);

                DateTime? lastLoginTimestamp = await GetLastLoginTimestamp(userRecord, firestoreUser);

                string role = await DetermineUserRole(userRecord.Uid, userRecord.CustomClaims);

                var user = new UserViewModel
                {
                    DisplayName = displayName,
                    Email = userRecord.Email,
                    Uid = userRecord.Uid,
                    PhoneNumber = (string)firestoreUser.GetValueOrDefault("Contact Number", ""),
                    EmailVerified = userRecord.EmailVerified,
                    Disabled = userRecord.Disabled,
                    RegistrationDate = userRecord.UserMetaData.CreationTimestamp ?? DateTime.MinValue,
                    LastLoginTimestamp = lastLoginTimestamp,
                    Role = role
                };

                _logger.LogInformation($"User: {user.DisplayName}, Role: {user.Role}, Last Login: {user.LastLoginTimestamp}");

                users.Add(user);
            }
            return users;
        }

        private async Task<Dictionary<string, object>> GetFirestoreUserData(string uid)
        {
            try
            {
                var userDoc = await _firestoreDb.Collection("users").Document(uid).GetSnapshotAsync();
                if (userDoc.Exists)
                {
                    var data = userDoc.ToDictionary();
                    _logger.LogInformation($"Firestore data for user {uid}: {Newtonsoft.Json.JsonConvert.SerializeObject(data, Newtonsoft.Json.Formatting.Indented)}");
                    return data;
                }
                _logger.LogWarning($"No Firestore document found for user {uid}");
                return new Dictionary<string, object>();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error fetching Firestore data for user {uid}: {ex.Message}");
                return new Dictionary<string, object>();
            }
        }

        private async Task<string> DetermineUserRole(string uid, IReadOnlyDictionary<string, object> customClaims)
        {
            // Check Firebase Authentication custom claims for Admin role
            if (customClaims != null && customClaims.ContainsKey("admin") && (bool)customClaims["admin"])
            {
                return "Admin";
            }

            // Check if the user is a project owner (which should be considered an admin)
            if (await IsProjectOwner(uid))
            {
                return "Admin";
            }

            // Check Firestore for student role
            var firestoreUser = await GetFirestoreUserData(uid);
            if (firestoreUser.TryGetValue("User Role", out object userRole))
            {
                string role = userRole.ToString().ToLower();
                if (role == "student")
                {
                    return "Student";
                }
                else if (role == "admin")
                {
                    return "Admin";
                }
            }

            // Default role if not found
            return "User";
        }

        public async Task<bool> IsProjectOwner(string uid)
        {
            try
            {
                var userRecord = await FirebaseAuth.DefaultInstance.GetUserAsync(uid);
                string[] ownerEmails = { "mabasafanelo99@gmail.com", "leak.maasdorp@gmail.com", "17morake.apex@gmail.com", "likhayanete9@gmail.com", "mateboho06@gmail.com" };
                return ownerEmails.Contains(userRecord.Email);
            }
            catch
            {
                return false;
            }
        }

        public async Task DeleteUser(string uid)
        {
            try
            {
                await FirebaseAuth.DefaultInstance.DeleteUserAsync(uid);
                // Also delete user data from Firestore
                await _firestoreDb.Collection("users").Document(uid).DeleteAsync();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deleting user: {ex.Message}", ex);
            }
        }

        public async Task<UserProfileViewModel> GetUserById(string uid)
        {
            try
            {
                _logger.LogInformation($"Fetching user data for UID: {uid}");
                var userRecord = await FirebaseAuth.DefaultInstance.GetUserAsync(uid);
                var firestoreUser = await GetFirestoreUserData(uid);

                string role = await DetermineUserRole(uid, userRecord.CustomClaims);
                _logger.LogInformation($"Determined role for user {uid}: {role}");

                string firstName = firestoreUser.GetValueOrDefault("Firstname", "").ToString();
                string surname = firestoreUser.GetValueOrDefault("Surname", "").ToString();
                string displayName = $"{firstName} {surname}".Trim();

                if (string.IsNullOrEmpty(displayName))
                {
                    displayName = userRecord.DisplayName ?? "Name Not Available";
                }

                var viewModel = new UserProfileViewModel
                {
                    DisplayName = displayName,
                    FirstName = firstName,
                    Surname = surname,
                    Email = userRecord.Email,
                    Uid = userRecord.Uid,
                    LastLoginTimestamp = await GetLastLoginTimestamp(userRecord, firestoreUser),
                    CreationTimestamp = userRecord.UserMetaData.CreationTimestamp,
                    Role = role,
                    IsProjectOwner = await IsProjectOwner(uid)
                };

                _logger.LogInformation($"Created UserProfileViewModel for {uid}: {Newtonsoft.Json.JsonConvert.SerializeObject(viewModel)}");

                return viewModel;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error retrieving user {uid}: {ex.Message}");
                throw;
            }
        }

        private async Task<string> GetDisplayName(UserRecord userRecord, Dictionary<string, object> firestoreUser)
        {
            string displayName = userRecord.DisplayName;
            _logger.LogInformation($"Initial display name from Firebase Auth: {displayName}");

            if (string.IsNullOrEmpty(displayName))
            {
                _logger.LogInformation("Display name is empty, attempting to construct from Firestore data");
                var firstName = firestoreUser.GetValueOrDefault("Firstname", "").ToString();
                var surname = firestoreUser.GetValueOrDefault("Surname", "").ToString();
                _logger.LogInformation($"Firestore data: firstName = '{firstName}', surname = '{surname}'");
                displayName = $"{firstName} {surname}".Trim();
            }

            if (string.IsNullOrEmpty(displayName))
            {
                _logger.LogWarning("Display name is still empty after attempting to construct from Firestore");
                displayName = "Name Not Available";
            }
            else
            {
                _logger.LogInformation($"Final display name: {displayName}");
            }

            return displayName;
        }

        private async Task<DateTime?> GetLastLoginTimestamp(UserRecord userRecord, Dictionary<string, object> firestoreUser)
        {
            if (firestoreUser.TryGetValue("Last Sign-In", out object lastSignIn) && lastSignIn is Timestamp timestamp)
            {
                return timestamp.ToDateTime();
            }
            else if (userRecord.UserMetaData.LastSignInTimestamp.HasValue)
            {
                return userRecord.UserMetaData.LastSignInTimestamp.Value;
            }
            return null;
        }
    }
}