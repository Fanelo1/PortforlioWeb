﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Firebase.Storage;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using WebApps1.Models;

namespace WebApps1.Services
{
    public class FileUploadService
    {
        private readonly FirebaseStorage _firebaseStorage;
        private readonly StorageClient _storageClient;
        private readonly string _bucketName;
        private readonly GoogleCredential _credential;

        public FileUploadService(IConfiguration configuration)
        {
            var firebaseConfig = configuration.GetSection("Firebase");
            _bucketName = firebaseConfig["StorageBucket"];
            var credential = GoogleCredential.FromFile(firebaseConfig["CredentialFile"]);
            _storageClient = StorageClient.Create(credential);
            _firebaseStorage = new FirebaseStorage(_bucketName);
        }

        private async Task<string> GetAccessTokenAsync()
        {
            return await _credential.UnderlyingCredential.GetAccessTokenForRequestAsync();
        }

        public async Task UploadFileAsync(string folderPath, IFormFile file)
        {
            var filePath = Path.Combine(folderPath, file.FileName);
            using (var stream = file.OpenReadStream())
            {
                await _storageClient.UploadObjectAsync(_bucketName, filePath, null, stream);
            }
        }

        public async Task<List<FileViewModel>> GetFilesInFolderAsync(string folderPath)
        {
            var files = new List<FileViewModel>();
            var objects = await _storageClient.ListObjectsAsync(_bucketName, folderPath).ToListAsync();

            foreach (var obj in objects)
            {
                if (!obj.Name.EndsWith("/"))
                {
                    files.Add(new FileViewModel
                    {
                        Name = Path.GetFileName(obj.Name),
                        Path = obj.Name
                    });
                }
            }

            return files;
        }

        public async Task CreateFolderAsync(string folderPath)
        {
            await _storageClient.UploadObjectAsync(
                _bucketName,
                folderPath + "/.folder",
                "application/x-directory",
                new MemoryStream(new byte[0]));
        }

        public async Task<FolderViewModel> GetFolderStructureAsync(string rootFolder = "")
        {
            var folder = new FolderViewModel { Name = Path.GetFileName(rootFolder) };
            var objects = await _storageClient.ListObjectsAsync(_bucketName, rootFolder).ToListAsync();

            foreach (var obj in objects)
            {
                var relativePath = obj.Name.Substring(rootFolder.Length).TrimStart('/');
                var parts = relativePath.Split('/');

                if (parts.Length == 1 && !obj.Name.EndsWith("/.folder"))
                {
                    // It's a file in the current folder
                    folder.Files.Add(new FileViewModel { Name = parts[0], Path = obj.Name });
                }
                else if (parts.Length > 1 && !folder.SubFolders.Exists(f => f.Name == parts[0]))
                {
                    // It's a new subfolder
                    folder.SubFolders.Add(new FolderViewModel { Name = parts[0] });
                }
            }

            return folder;
        }

        public async Task RenameFolderAsync(string oldName, string newName)
        {
            var objects = await _storageClient.ListObjectsAsync(_bucketName, oldName).ToListAsync();
            foreach (var obj in objects)
            {
                var newPath = obj.Name.Replace(oldName, newName);
                await _storageClient.CopyObjectAsync(_bucketName, obj.Name, _bucketName, newPath);
                await _storageClient.DeleteObjectAsync(_bucketName, obj.Name);
            }
        }

        public async Task DeleteFolderAsync(string folderPath)
        {
            var objects = await _storageClient.ListObjectsAsync(_bucketName, folderPath).ToListAsync();
            foreach (var obj in objects)
            {
                await _storageClient.DeleteObjectAsync(_bucketName, obj.Name);
            }
        }

        public async Task DeleteFileAsync(string filePath)
        {
            await _storageClient.DeleteObjectAsync(_bucketName, filePath);
        }
    }
}