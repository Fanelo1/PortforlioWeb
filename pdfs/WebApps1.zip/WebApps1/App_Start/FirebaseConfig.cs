﻿using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;

namespace WebApps1.App_Start
{
    public class FirebaseConfig
    {
        public static void Initialize()
        {
            FirebaseApp.Create(new AppOptions()
            {
                Credential = GoogleCredential.FromFile(Path.Combine(Directory.GetCurrentDirectory(), "C:\\Users\\FANELO\\Documents\\IT\\WIL\\WebApps1 (4)\\WebApps1\\Privatekey\\studyappfirebase-1698b-firebase-adminsdk-vq6p6-f00124054b.json")),
            });
        }
    }
}
