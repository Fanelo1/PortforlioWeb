using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using System.IO;
using WebApps1.Services;
using WebApps1.Authorization;
using Microsoft.AspNetCore.Authorization;
using Google.Api;
using Google.Cloud.Firestore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddHttpContextAccessor();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
builder.Services.AddAuthentication();
builder.Services.AddAuthorization();

// Firebase and Firestore initialization
var pathToKey = Path.Combine(Directory.GetCurrentDirectory(), "Privatekey", "studyappfirebase-1698b-firebase-adminsdk-vq6p6-f00124054b.json");
GoogleCredential credential;
try
{
    credential = GoogleCredential.FromFile(pathToKey);
    FirebaseApp.Create(new AppOptions()
    {
        Credential = credential
    });

    // Initialize Firestore
    var projectId = "studyappfirebase-1698b";
    builder.Services.AddSingleton(_ => new FirestoreDbBuilder
    {
        ProjectId = projectId,
        Credential = credential
    }.Build());
}
catch (Exception ex)
{
    // Log the exception
    Console.WriteLine($"Error initializing Firebase/Firestore: {ex.Message}");
    throw; // Re-throw the exception to halt application startup
}
// Service registrations
builder.Services.AddScoped<FirebaseUserService>();
builder.Services.AddScoped<FileUploadService>();
builder.Services.AddSingleton<IAuthorizationHandler, AdminAuthorizationHandler>();

// Logging configuration
builder.Logging.AddConfiguration(builder.Configuration.GetSection("Logging"));
builder.Logging.AddConsole();
builder.Logging.AddDebug();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();