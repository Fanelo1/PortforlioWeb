﻿namespace WebApps1.Models
{
    public class UserProfileViewModel
    {
        public string DisplayName { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Uid { get; set; }
        public DateTime? LastLoginTimestamp { get; set; }
        public DateTime? CreationTimestamp { get; set; }
        public string Role { get; set; }
        public bool IsProjectOwner { get; set; }
    }
}