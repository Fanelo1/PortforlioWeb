﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace WebApps1.Models
{
    public class ModuleListViewModel
    {
        public List<ModuleViewModel> Modules { get; set; } = new List<ModuleViewModel>();
        public string SearchQuery { get; set; }
        public string SelectedModule { get; set; }
        public string SelectedStatus { get; set; }
    }

    public class ModuleViewModel
    {
        public string Year { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
    }

    public class ModuleComparer : IComparer<ModuleViewModel>
    {
        private readonly SortDirection _sortDirection;

        public ModuleComparer(SortDirection sortDirection)
        {
            _sortDirection = sortDirection;
        }

        public int Compare(ModuleViewModel x, ModuleViewModel y)
        {
            int result = string.Compare(x.Name, y.Name, StringComparison.InvariantCulture);
            return _sortDirection == SortDirection.Ascending ? result : -result;
        }
    }

    public class FileUploadViewModel
    {
        public List<string> Folders { get; set; } = new List<string>();
        public string CurrentFolder { get; set; }
        public IFormFile File { get; set; }
        public FolderViewModel FolderStructure { get; set; }
        public List<ModuleViewModel> Modules { get; set; } = new List<ModuleViewModel>();
        public string SearchQuery { get; set; }
        public string OrderBy { get; set; }
        public SortDirection OrderDirection { get; set; } = SortDirection.Ascending;
    }

    public enum SortDirection
    {
        Ascending,
        Descending
    }

    public class ModuleDetailsViewModel
    {
        public string ModuleName { get; set; }
        public List<FileViewModel> Files { get; set; } = new List<FileViewModel>();
    }

    public class FolderViewModel
    {
        public string Name { get; set; }
        public List<FolderViewModel> SubFolders { get; set; } = new List<FolderViewModel>();
        public List<FileViewModel> Files { get; set; } = new List<FileViewModel>();
    }

    public class FileViewModel
    {
        public string Name { get; set; }
        public string Path { get; set; }
    }
}