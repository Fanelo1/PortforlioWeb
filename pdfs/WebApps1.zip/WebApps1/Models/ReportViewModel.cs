﻿using System;

namespace WebApps1.Models
{
    public class ReportViewModel
    {
        public string Id { get; set; }
        public string GroupId { get; set; }
        public string GroupName { get; set; }
        public string Reason { get; set; }
        public DateTime ReportedAt { get; set; }
        public string ReportedBy { get; set; }
        public string ReportedUserId { get; set; }
        public string ReporterFirstName { get; set; }
        public string ReporterLastName { get; set; }
        public string ReportedUserFirstName { get; set; }
        public string ReportedUserLastName { get; set; }
    }
}