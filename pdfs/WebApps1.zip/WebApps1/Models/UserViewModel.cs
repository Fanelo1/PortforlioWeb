﻿namespace WebApps1.Models
{
    public class UserViewModel
    {
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public string Uid { get; set; }
        public string PhoneNumber { get; set; }
        public bool EmailVerified { get; set; }
        public bool Disabled { get; set; }
        public DateTime RegistrationDate { get; set; }
        public DateTime? LastLoginTimestamp { get; set; }
        public string Role { get; set; }
        public string Department { get; set; }
    }
}