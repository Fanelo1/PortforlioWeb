﻿namespace WebApps1.Models
{
    public class DashboardViewModel
    {
        public int TotalStudents { get; set; }
        public int MaxStudents { get; set; }
        public List<UserViewModel> NewcomersToday { get; set; }
    }
}
