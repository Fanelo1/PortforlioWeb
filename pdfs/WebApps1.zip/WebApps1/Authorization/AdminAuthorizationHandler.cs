﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.AspNetCore.Http;

namespace WebApps1.Authorization
{
    public class AdminAuthorizationHandler : AuthorizationHandler<RolesAuthorizationRequirement>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AdminAuthorizationHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, RolesAuthorizationRequirement requirement)
        {
            var userRole = _httpContextAccessor.HttpContext?.Session.GetString("UserRole");
            var userEmail = _httpContextAccessor.HttpContext?.Session.GetString("UserEmail");

            if (userRole == "Admin" && !string.IsNullOrEmpty(userEmail) && requirement.AllowedRoles.Contains("Admin"))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}